#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <pthread.h>
#include <sys/socket.h>
#include <event.h>
#include <signal.h>
#include <time.h>
#include <dirent.h>

#include "lightwanSafeStr.h"
#include "lightwanSerialConfig.h"
#include "lightwanEvent.h"
#include "lightwanDhcp.h"
#include "lightwanEcmMsg.h"
#include "lightwanUdev.h"
#include "lightwanErrno.h"
#include "lightwanEcmManager.h"

/* TM22C information */
#define LW_TM22C_ID_VENDOR                         "1782"
#define LW_TM22C_ID_PRODUCT                        "000c"

/* AT cmd */
#define LW_ATCMD_CFUN_DOWN                         "AT+CFUN=0\r\n"
#define LW_ATCMD_CFUN_UP                           "AT+CFUN=1\r\n"
#define LW_ATCMD_CFUN_STATUS                       "AT+CFUN?\r\n"
#define LW_ATCMD_CESQ                              "AT+CESQ\r\n"
#define LW_ATCMD_CCED01                            "AT+CCED=0,1\r\n"
#define LW_ATCMD_CIMI                              "AT+CIMI\r\n"
#define LW_ATCMD_CGACT                             "AT+CGACT?\r\n"
#define LW_ATCMD_CGMR                              "AT+CGMR\r\n"
#define LW_ATCMD_AT                                "AT\r\n"

/* AT cmd reply */
#define LW_ATCMD_REPLY_OK                          "OK"
#define LW_ATCMD_REPLY_ERROR                       "ERROR"
#define LW_ATCMD_REPLY_CFUN_UP                     "1"

typedef enum _LW_ATCMD_CALL_INIT_CMD
{
    LW_ATCMD_CALL_INIT_NONE,

    LW_ATCMD_CALL_INIT_AT,

    LW_ATCMD_CALL_INIT_MAX,
} LW_ATCMD_CALL_INIT_CMD;

typedef enum _LW_ATCMD_CALL_UP_CMD
{
    LW_ATCMD_CALL_UP_NONE,

    LW_ATCMD_CALL_UP_CFUN_STATUS,
    LW_ATCMD_CALL_UP_CFUN_UP,

    LW_ATCMD_CALL_UP_MAX,
} LW_ATCMD_CALL_UP_CMD;

typedef enum _LW_ATCMD_CALL_DOWN_CMD
{
    LW_ATCMD_CALL_DOWN_NONE,

    LW_ATCMD_CALL_DOWN_AT,

    LW_ATCMD_CALL_DOWN_MAX,
} LW_ATCMD_CALL_DOWN_CMD;

typedef enum _LW_ATCMD_CALL_STATUS_CMD
{
    LW_ATCMD_CALL_STATUS_NONE,

    LW_ATCMD_CALL_STATUS_CGMR,
    LW_ATCMD_CALL_STATUS_CESQ,
    LW_ATCMD_CALL_STATUS_CCED01,
    LW_ATCMD_CALL_STATUS_CIMI,
    LW_ATCMD_CALL_STATUS_CGACT,

    LW_ATCMD_CALL_STATUS_MAX,
} LW_ATCMD_CALL_STATUS_CMD;


#ifdef LW_ECM_FEATURE_SHOW_REPORT
#define LW_SERVICE_CELL_LTE     "LTE service cell"

/* index starts from 0 */
#define LW_ATCMD_CESQ_4G_RSRQ_INDEX                     4
#define LW_ATCMD_CESQ_4G_RSRP_INDEX                     5
#define LW_ATCMD_CCED01_MCC_INDEX                       0
#define LW_ATCMD_CCED01_MNC_INDEX                       1
#define LW_ATCMD_CCED01_LAC_INDEX                       2
#define LW_ATCMD_CCED01_CI_INDEX                        3
#define LW_ATCMD_CGACT_DIALSTATE_INDEX                  1
#define LW_ATCMD_CIMI_IMSI_INDEX                        0

/*******************************************************************************
 * NAME:  _LW_ShowInfoParseCesq
 *
 * DESCRIPTION:
 *      Parse "at+cgmr" reply content, returned module model
 * eg:
 *      1 4G
 *          reply:
 *              Platform Version:  
 *              STONEOIM_uis8310vs_csh56_01_p1_tm22g_pl_ssv_cc_64mb_lte_5m-cs_vsim_user_20221209160709_Release
 *              Software Version: 0.1902.16.00
 *              Hardware Version:V1.0
 *              Modem Model:modem_csh56-01
 *              Flash type:P
 *              Platform OEM:tuge
 *              FOTA     Version:V2.5
 *              Platform Name:vsim-csh56-tg-ssv-ptest01-tm22
 *              MAC Address:
 *              Serial Number:
 *              BASE     Version: FM_BASE_THIN_MODEM_TRUNK_W21.05.3
 *              HW       Version: UMS9117
 *              buildtime:12-09-2022 16:11:47
 * 
 *              OK
 *
 *          result:
 *              tm22g
 * 
 * INPUTS:
 *      ReplyContent:               [input] reply content
 *      WwanManagerInfo:            [output] Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void
_LW_ShowInfoParseCgmr(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    if (strstr(ReplyContent, LW_ATCMD_REPLY_TM22C))
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_TM22C;
    }
    else
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_NONE;
        LW_LOGI("cgmr reply invalid\n");
        goto CommonReturn;
    }

CommonReturn:
    return;
}

/*******************************************************************************
 * NAME:  _LW_ShowInfoParseCesq
 *
 * DESCRIPTION:
 *      Parse "at+cesq" reply content, returned rsrp
 * eg:
 *      1 4G
 *          reply:
 *              +CESQ: 99,99,255,255,17,46
 *              
 *              OK
 *          result:
 *              rsrp=46
 * 
 *      2 3G
 *          reply:
 *              +CESQ: 99,99,55,255,17,255
 *              
 *              OK
 *          result:
 *              rsrp=55
 * 
 * INPUTS:
 *      ReplyContent:               [input] reply content
 *      WwanManagerInfo:            [output] Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void 
_LW_ShowInfoParseCesq(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    char *pStart = NULL;
    int rsrp = 0;
    int rsrq = 0;

    pStart = strstr(ReplyContent, "+CESQ");
    if (pStart == NULL)
    {
        LW_LOGI("cesq reply invalid\n");
        goto CommonReturn;
    }

    if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_CESQ_4G_RSRQ_INDEX, &rsrq) < LW_SUCCESS)
    {
        LW_LOGI("get rsrq failed");
    }
    else
    {
        if (rsrq != 0 && rsrq != 255)
        {
            LW_LOGD("get rsrq %.1fdB", (double)rsrq / 2 - 19.5);
            WwanManagerInfo->ShowInfo.Rsrq = LW_SHOW_INFO_RSRQ_TO_PARAM((double)rsrq / 2 - 19.5);
        }
    }

    if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_CESQ_4G_RSRP_INDEX, &rsrp) < LW_SUCCESS)
    {
        LW_LOGI("get rsrp failed\n");
    }
    else
    {
        if (rsrp != 0 && rsrp != 255)
        {
            WwanManagerInfo->ShowInfo.NetworkType = LW_WWAN_NETWORK_LTE;
            LW_LOGI("%s\n", LW_SERVICE_CELL_LTE);

            rsrp = rsrp - 140;
            if (rsrp < 0)
            {
                LW_LOGD("get rsrp %ddBm\n", rsrp);
                WwanManagerInfo->ShowInfo.Rsrp = LW_SHOW_INFO_RSRP_TO_PARAM(rsrp);
            }
        }
    }

CommonReturn:
    return;
}

/*******************************************************************************
 * NAME:  _LW_ShowInfoParseCced01
 *
 * DESCRIPTION:
 *      Parse "at+cced=0,1" reply content, returned 1 mcc, 2 mnc, 3 lac, 4 ci
 *  eg:
 *      reply:
 *          +CCED: 460,01,47901,196612915,0,1650,46,17
 *          
 *          OK
 *      reply:
 *          mcc=460 mnc=04 lac=47901 ci=196612915
 * 
 * INPUTS:
 *      ReplyContent:               [input] reply content
 *      WwanManagerInfo:            [output] Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void 
_LW_ShowInfoParseCced01(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    char *pStart = NULL;
    int lac = 0;
    int ci = 0;
    size_t mncLen = 0;
    size_t mccLen = 0;
    
    pStart = strstr(ReplyContent, "+CCED:");
    if (pStart == NULL)
    {
        LW_LOGI("cced01 reply invalid\n");
        goto CommonReturn;
    }

    if (strstr(ReplyContent, LW_ATCMD_REPLY_OK) == NULL)
    {
        LW_LOGI("cced reply invalid\n");
        goto CommonReturn;
    }

    mccLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_CCED01_MCC_INDEX, WwanManagerInfo->ShowInfo.Mcc);
    if (mccLen == 0)
    {
        LW_LOGI("get mcc failed\n");
    }

    mncLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_CCED01_MNC_INDEX, WwanManagerInfo->ShowInfo.Mnc);
    if (mncLen == 0)
    {
        LW_LOGI("get mnc failed\n");
    }

    if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_CCED01_LAC_INDEX, &lac) < LW_SUCCESS)
    {
        LW_LOGI("get lac failed\n");
    }
    else
    {
        WwanManagerInfo->ShowInfo.Lac = (uint32_t)lac;
    }


    if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_CCED01_CI_INDEX, &ci) < LW_SUCCESS)
    {
        LW_LOGI("get ci failed\n");
    }
    else
    {
        WwanManagerInfo->ShowInfo.Ci = (uint64_t)ci;
    }

CommonReturn:
    return;
}
/*******************************************************************************
 * NAME:  _LW_ShowInfoParseCimi
 *
 * DESCRIPTION:
 *      Parse "at+cimi" reply content returned ci, eg:
 *      reply:
 *          460019059048947
 *
 *          OK
 *      
 *      result:
 *          imsi=460019059048947
 *
 * INPUTS:
 *      ReplyContent:               [input] reply content
 *      WwanManagerInfo:            [output] Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void 
_LW_ShowInfoParseCimi(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    size_t imsiLen = 0;

    if (ReplyContent == NULL)
    {
        LW_LOGI("cimi reply invalid\n");
        goto CommonReturn;
    }

    if (strstr(ReplyContent, LW_ATCMD_REPLY_OK) == NULL)
    {
        LW_LOGI("cimi reply invalid\n");
        goto CommonReturn;
    }

    imsiLen = LW_GetStringValAfterNthComma(ReplyContent, LW_ATCMD_CIMI_IMSI_INDEX, WwanManagerInfo->ShowInfo.Imsi);
    if (imsiLen == 0)
    {
        LW_LOGI("get imsi failed\n");
    }

CommonReturn:
    return;
}
/*******************************************************************************
 * NAME:  _LW_ShowInfoParseCgact
 *
 * DESCRIPTION:
 *      Parse "at+cgact?" reply content returned dialState
 *  eg:
 *      reply:
 *          +CGACT:1,1
 *          +CGACT:2,0
 *          +CGACT:3,0
 *          +CGACT:4,0
 *          +CGACT:5,0
 *          +CGACT:6,0
 *          +CGACT:7,0
 *          +CGACT:8,0
 *          +CGACT:9,0
 *          +CGACT:10,0
 *          +CGACT:11,0
 *          
 *          OK
 * 
 *      result:
 *          dialState=1
 *
 * INPUTS:
 *      ReplyContent:               [input] reply content
 *      WwanManagerInfo:            [output] Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void 
_LW_ShowInfoParseCgact(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    char *pStart = NULL;
    int dialState = 0;

    pStart = strstr(ReplyContent, "+CGACT:1");
    if (pStart == NULL)
    {
        LW_LOGI("cgact reply invalid\n");
        goto CommonReturn;
    }

    if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_CGACT_DIALSTATE_INDEX, &dialState) < LW_SUCCESS)
    {
        LW_LOGI("get dialState failed\n");
    }
    else
    {
        WwanManagerInfo->ShowInfo.DialState = (dialState == 1) ? 1 : 0;
    }

CommonReturn:
    return;
}
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

static LW_ERR_T
_LW_GetCallInitAtCmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_INIT_CMD ATcmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;

    switch (ATcmdIndex)
    {
        case LW_ATCMD_CALL_INIT_AT:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_AT);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GetCallUpAtCmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_UP_CMD ATcmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;

    switch (ATcmdIndex)
    {
        case LW_ATCMD_CALL_UP_CFUN_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CFUN_STATUS);
            break;
        }
        case LW_ATCMD_CALL_UP_CFUN_UP:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CFUN_UP);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GetCallDownAtCmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_DOWN_CMD ATcmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;

    switch (ATcmdIndex)
    {
        case LW_ATCMD_CALL_DOWN_AT:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_AT);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GetCallStatusAtCmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_STATUS_CMD ATcmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;
    switch (ATcmdIndex)
    {
        case LW_ATCMD_CALL_STATUS_CESQ:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CESQ);
            break;
        }
        case LW_ATCMD_CALL_STATUS_CCED01:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CCED01);
            break;
        }
        case LW_ATCMD_CALL_STATUS_CIMI:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CIMI);
            break;
        }
        case LW_ATCMD_CALL_STATUS_CGACT:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CGACT);
            break;
        }
        case LW_ATCMD_CALL_STATUS_CGMR:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CGMR);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }
    
CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_TugeGetATcmdFunc(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_TYPE ATcmdType,
    uint32_t ATcmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;

    switch (ATcmdType)
    {
        case LW_ATCMD_CALL_INIT:
        {
            ret = _LW_GetCallInitAtCmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        case LW_ATCMD_CALL_UP:
        {
            ret = _LW_GetCallUpAtCmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        case LW_ATCMD_CALL_DOWN:
        {
            ret = _LW_GetCallDownAtCmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        case LW_ATCMD_CALL_STATUS:
        {
            ret = _LW_GetCallStatusAtCmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

CommonReturn:
    return ret;
}

static BOOL
_LW_TugeATreplyHandlerFunc(
    const char * ATreply,
    LW_ATCMD_TYPE ATcmdType, 
    uint32_t *ATcmdIndex
    )
{
    BOOL isHandled = TRUE;

    switch (ATcmdType)
    {
        case LW_ATCMD_CALL_INIT:
        {
            *ATcmdIndex = *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_INIT_MAX)
            {
                LW_LOGI("Initializing successful! to call up\n");

                /* from call up to call status */
                LW_ATCallUp();
            }
            break;
        }
        case LW_ATCMD_CALL_UP:
        {
            if (*ATcmdIndex == LW_ATCMD_CALL_UP_CFUN_STATUS)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_CFUN_UP) == NULL)
                {
                    LW_SetDialState(FALSE);
                }
                else
                {
                    LW_SetDialState(TRUE);

                    /* skip "at+cfun=1" */
                    *ATcmdIndex = LW_ATCMD_CALL_UP_CFUN_UP;
                }
            }

            *ATcmdIndex = *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_UP_MAX)
            {
                LW_SetDialState(TRUE);
                LW_WWANDhcpup();
                LW_LOGI("Dialing successful! to call status\n");

                /* from call up to call status */
                LW_ATCallStatus();
            }
            break;
        }
        case LW_ATCMD_CALL_DOWN:
        {
            LW_WWANDhcpdown();
            LW_LOGI("Dhcp stopped\n");

            LW_EventStop();
        }
        case LW_ATCMD_CALL_STATUS:
        {
#ifdef LW_ECM_FEATURE_SHOW_REPORT
            if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_CESQ)
            {
                _LW_ShowInfoParseCesq(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_CCED01)
            {
                _LW_ShowInfoParseCced01(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_CGACT)
            {
                _LW_ShowInfoParseCgact(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_CIMI)
            {
                _LW_ShowInfoParseCimi(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_CGMR)
            {
                _LW_ShowInfoParseCgmr(ATreply, LW_GetShowInfoConf());
            }
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

            *ATcmdIndex = *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_MAX)
            {
                LW_LOGI("Dialing normally! to call status again\n");
                LW_ATCallStatus();
            }

            break;
        }
        case LW_ATCMD_CALL_MESSAGES:
        {
            (void)LW_SendToClientSuccess(ATreply);
            break;
        }
        default:
        {
            LW_LOGI("ATcmdType invalid\n");
            break;
        }
    }

    return isHandled;
}

static void _LW_TugeUdevInfoRegistFunc(LW_UDEV_INFO *UdevInfo)
{
    UdevInfo->MonitorCnt = 1;

    UdevInfo->MonitorInfo = malloc(sizeof(LW_UDEV_MONITOR_INFO) * UdevInfo->MonitorCnt);
    if (UdevInfo->MonitorInfo == NULL)
    {
        UdevInfo->MonitorCnt = 0;
        LW_LOGI("malloc failed\n");
        goto CommonReturn;
    }

    memset(UdevInfo->MonitorInfo, 0, sizeof(LW_UDEV_MONITOR_INFO) * UdevInfo->MonitorCnt);

    UdevInfo->MonitorInfo[0].Mode = LW_MODULE_MODEL_MODE_NORMAL;
    LW_SafeStrCopy(UdevInfo->MonitorInfo[0].DeviceAction, LW_UDEV_DEVICE_ACTION_STR_MAX, "add");
    LW_SafeStrCopy(UdevInfo->MonitorInfo[0].IdVendor, LW_VID_PID_LENGTH_MAX, LW_TM22C_ID_VENDOR);
    LW_SafeStrCopy(UdevInfo->MonitorInfo[0].IdProduct, LW_VID_PID_LENGTH_MAX, LW_TM22C_ID_PRODUCT);

CommonReturn:
    return;
}

static LW_ERR_T  _LW_TugeUdevMonitorFunc(LW_MODULE_MODEL_MODE Mode)
{
    LW_ERR_T ret = LW_SUCCESS;

    switch (Mode)
    {
        case LW_MODULE_MODEL_MODE_NORMAL:
        {
            memset(LW_GetCrashInfoConf(), 0, sizeof(LW_GetCrashInfoConf()->CrashInfo));
            LW_GetCrashInfoConf()->InfoType = LW_WWAN_MANAGER_INFO_CRASH;
            LW_GetCrashInfoConf()->WwanModule = LW_WWAN_MODULE_MODEL_NONE;

#ifdef LW_ECM_FEATURE_SHOW_REPORT
            if (LW_GetShowInfoConf()->WwanModule != LW_WWAN_MODULE_MODEL_NONE)
            {
                LW_GetCrashInfoConf()->WwanModule = LW_GetShowInfoConf()->WwanModule;
            }
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

            LW_GetCrashInfoConf()->CrashInfo.TimeStamp = time(NULL);
            LW_GetCrashInfoConf()->CrashInfo.CrashFileFlag = 0;

#ifdef LW_ECM_FEATURE_CRASH_ALERT
            ret = LW_SendMsgToAgent(LW_GetCrashInfoConf());
            if (ret < LW_SUCCESS)
            {
                goto CommonReturn;
            }
#endif /* LW_ECM_FEATURE_CRASH_ALERT */

            LW_LOGI("wait %us to redialing\n", LW_CRASH_WAIT_INTERVAL);
            sleep(LW_CRASH_WAIT_INTERVAL);

            if (LW_CheckIntfLoaded() == FALSE)
            {
                ret = -LW_ENXIO;
                goto CommonReturn;
            }

            ret = LW_RedialByUdevMonitor(
                                        TRUE, 
                                        &_LW_TugeGetATcmdFunc, 
                                        &_LW_TugeATreplyHandlerFunc, 
                                        &_LW_TugeUdevInfoRegistFunc,
                                        &_LW_TugeUdevMonitorFunc
                                        );
            if (ret < LW_SUCCESS)
            {
                LW_LOGI("Redial failed, exit...\n");
                goto CommonReturn;
            }
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            break;
        }
    }

CommonReturn:
    return ret;
}

static int _LW_TugeInit()
{
    int ret = 0;

    LW_RegistSignal();

    if (LW_EventInit(
                    FALSE, 
                    &_LW_TugeGetATcmdFunc, 
                    &_LW_TugeATreplyHandlerFunc, 
                    &_LW_TugeUdevInfoRegistFunc, 
                    &_LW_TugeUdevMonitorFunc
                    ) < LW_SUCCESS)
    {
        ret = -1;
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

int _LW_TugeProcessing(int DialType)
{
    return LW_EventHandleDispatch(DialType);
}

void _LW_TugeExit()
{
    LW_LOGI("Processing stopped\n");
}

LW_DIAL_DRIVER g_DialDriverTugeTM22C = 
{
    .Name = "TM22C",
    .IDVendor = "1782",
    .IDProduct = "000c",
    .TtyUSBPath = "/dev/ttyUSB0",
    .Init = _LW_TugeInit,
    .Exit = _LW_TugeExit,
    .Processing = _LW_TugeProcessing,
};

LW_DIAL_DRIVER* LW_GetDriverTM22C()
{
    return &g_DialDriverTugeTM22C;
}

