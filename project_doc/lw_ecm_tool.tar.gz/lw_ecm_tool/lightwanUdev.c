#include <string.h>
#include <sys/vfs.h>
#include <libudev.h>
#include <unistd.h>
#include <dirent.h>
#include "lightwanUdev.h"
#include "lightwanSafeStr.h"
#include "lightwanEcmMsg.h"

#define LW_FILE_MAX_LENGTH  1024

int g_UdevMonitorFd = -1;
struct udev * g_Udev = NULL;
static LW_UDEV_INFO * g_UdevInfo = NULL;
struct udev_monitor * g_UdevMonitor = NULL;
static struct event * g_UdevMonitorEvent = NULL;

void
LW_UdevMonitorCloseFd()
{
    if (g_UdevMonitorFd > 0)
    {
        close(g_UdevMonitorFd);
    }
    g_UdevMonitorFd = -1;
}

int 
LW_UdevMonitorGetFd()
{
    return g_UdevMonitorFd;
}

struct udev_monitor *
_LW_UdevMonitorGetObj()
{
    return g_UdevMonitor;
}

void
LW_UdevMonitorRelease()
{
    LW_UdevMonitorCloseFd();
    /* the object is destroyed and freed. */
    udev_monitor_unref(g_UdevMonitor);
    udev_unref(g_Udev);
    g_UdevMonitor = NULL;
    g_Udev = NULL;
}

/*******************************************************************************
 * NAME:    _LW_UdevMointorInitFd
 *
 * DESCRIPTION:
 *      Create new udev monitor and connect to a specified event source,
 *      and Retrieve the socket file descriptor associated with the monitor.
 *
 * INPUTS:
 *      Udev:           [in]udev object
 *      UdevMonitor     [in]udev monitor object
 * RETURN:
 *      SUCCESS     fd >= 0
 *      FAILED      fd < 0
 */
static int
_LW_UdevMointorInitFd(
    struct udev *Udev,
    struct udev_monitor *UdevMonitor
    )
{
    int ret = 0;

    /* filter usb device type */
    ret = udev_monitor_filter_add_match_subsystem_devtype(UdevMonitor, "usb", NULL);
    if (ret < 0)
    {
        LW_LOGI("udev monitor add filter failed, ret %d \n", ret);
        goto CommonReturn;
    }

    /* monitor enable recv */
    ret = udev_monitor_enable_receiving(UdevMonitor);
    if (ret < 0)
    {
        LW_LOGI("udev monitor enable recv failed, ret %d \n", ret);
        goto CommonReturn;
    }

    g_UdevMonitorFd = udev_monitor_get_fd(UdevMonitor);
    if (g_UdevMonitorFd < 0)
    {
        ret = -1;
        LW_LOGI("udev monitoe get fd failed\n");
        goto CommonReturn;
    }

CommonReturn:
    if (ret < 0)
    {
        g_UdevMonitorFd = -1;
    }

    return ret;
}

int
LW_UdevMonitorInit(int EventSrc)
{
    int ret = 0;

    if (EventSrc != LW_Monitor_Event_Source_Udev && 
        EventSrc != LW_Monitor_Event_Source_Kernel)
    {
        ret = -LW_EINVAL;
        LW_LOGI("event source error\n");
        goto CommonReturn;
    }
    /* allocates a new udev context object and returns a pointer to it */
    g_Udev = udev_new();
    if (g_Udev == NULL)
    {
        ret = -LW_EINVAL;
        LW_LOGI("create udev failed\n");
        goto CommonReturn;
    }

    /*  returns a pointer to the allocated udev monitor */
    if (EventSrc == LW_Monitor_Event_Source_Udev)
    {
        g_UdevMonitor  = udev_monitor_new_from_netlink(g_Udev, "udev");
    }
    else if (EventSrc == LW_Monitor_Event_Source_Kernel)
    {
        g_UdevMonitor  = udev_monitor_new_from_netlink(g_Udev, "kernel");
    }
    if (g_UdevMonitor == NULL)
    {
        ret = -1;
        LW_LOGI("create udev monitor failed\n");
        goto CommonReturn;
    }

    ret = _LW_UdevMointorInitFd(g_Udev, g_UdevMonitor);
    if (ret < 0)
    {
        LW_LOGI("udev checking init failed\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

unsigned long long
LW_GetPathDiskFree(
    const char * DiskPath
    )
{
    int ret = 0;
    struct statfs diskInfo;
    unsigned long long blockSize = 0;
    unsigned long long freeSize = 0;

    memset(&diskInfo, 0, sizeof(diskInfo));
    ret = statfs("/var/log/", &diskInfo);
    if (ret < 0)
    {
        LW_LOGI("Get disk information failed!\n");
        goto CommonReturn;
    }
    /* Total data blocks in filesystem, byte */
    blockSize = diskInfo.f_bsize; 
    /* Available blocks in filesystem, byte */
    freeSize = blockSize * diskInfo.f_bavail; 

    /* 1MB = 1024 * 1024 byte */
    freeSize = freeSize >> 20;
    LW_LOGI("Path:%s freeSize:%lluMB\n", DiskPath, freeSize);

CommonReturn:
    return freeSize;
}
/*******************************************************************************
 * NAME:    LW_CheckIntfLoaded
 *
 * DESCRIPTION:
 *      Check the interface is restored
 *
 * INPUTS:
 *      NONE.
 * 
 * RETURN:
 *      TRUE    Interface recovery
 *      FALSE   Not recovered
 */
BOOL 
LW_CheckIntfLoaded()
{
    BOOL isLoaded = FALSE;
    uint32_t i = 1;

    for (; ; i ++)
    {
        /* wait interface loading */
        sleep(1);
        if (access("/sys/class/net/ppp15", F_OK) == 0)
        {
            isLoaded = TRUE;
            LW_LOGI("Interface(ppp15) exist, to dial\n");
            break;
        }

        if (i % (60 * 5) == 0)    /* 5 minute */
        {
            LW_LOGI("Interface(ppp15) does not exist in %u minutes\n", i / 60);
        }
    }

    if (system("ifconfig ppp15 up") < 0)
    {
        LW_LOGI("system failed(cmd:ifconfig ppp15 up)\n");
    }

    return isLoaded;
}

/*******************************************************************************
 * NAME:    LW_UdevMonitorTarget
 *
 * DESCRIPTION:
 *      Compare udev with device action, pid and vid.
 *      action bind event happened back in Linux 4.12, issue #38172.
 *
 * INPUTS:
 *      UdevInfo:       [in] action, pid and vid from udev
 *      Mode:           [out] Module model mode
 * 
 * RETURN:
 *      LW_SUCCESS:         Monitor a target
 *      -LW_EINVAL:         invalid target
 *      Others:             occur exception
 */
LW_ERR_T LW_UdevMonitorTarget(LW_UDEV_INFO *UdevInfo,LW_MODULE_MODEL_MODE *Mode)
{
    LW_ERR_T ret = LW_SUCCESS;
    struct udev_device * device = NULL;
    const char *deviceAction = NULL;
    const char *deviceVid = NULL;
    const char *devicePid = NULL;
    int loop = 0;

    if (_LW_UdevMonitorGetObj() == NULL)
    {
        ret = -LW_ENODEV;
        LW_LOGI("UdevMonitor is NULL\n");
        goto CommonReturn;
    }

    device = udev_monitor_receive_device(_LW_UdevMonitorGetObj());
    if (device == NULL)
    {
        ret = -LW_EINVAL;
        LW_LOGI("Receive device is NULL\n");
        goto CommonReturn;
    }
    deviceAction = udev_device_get_action(device);
    deviceVid = udev_device_get_sysattr_value(device, "idVendor");
    devicePid = udev_device_get_sysattr_value(device, "idProduct");

    /* Filter null device */
    if (!deviceAction || !deviceVid || !devicePid)
    {
        ret = -LW_EINVAL;
        goto CommonReturn;
    }

    for (; loop < UdevInfo->MonitorCnt; loop ++)
    {
        *Mode =  UdevInfo->MonitorInfo[loop].Mode;

        if (!LW_SafeStrCmp(UdevInfo->MonitorInfo[loop].DeviceAction, deviceAction, sizeof(deviceAction)) &&
            !LW_SafeStrCmp(UdevInfo->MonitorInfo[loop].IdVendor, deviceVid, sizeof(deviceVid)) &&
            !LW_SafeStrCmp(UdevInfo->MonitorInfo[loop].IdProduct, devicePid, sizeof(devicePid)))
        {
            ret = LW_SUCCESS;
            LW_LOGI("Udev monitor a target(action:%s vid:%s pid:%s)", deviceAction, deviceVid, devicePid);
            goto CommonReturn;
        }
    }

    ret = -LW_EINVAL;

CommonReturn:
    (void)udev_device_unref(device);
    return ret;
}

/*******************************************************************************
 * NAME:    LW_RemovemFileOrDir
 *
 * DESCRIPTION:
 *      remove file or directory, include non-empty directory
 *
 * INPUTS:
 *      Path:           [input] the file or dir path
 * 
 * RETURN:
 *      0               remove success
 *      -1              remove failed
 */
int LW_RemovemFileOrDir(const char *Path)
{
    int ret = 0;
    DIR *dir = NULL;
    struct dirent *entry = NULL;
    char nextPath[LW_FILE_MAX_LENGTH] = {0};

    /* Open directory */ 
    if ((dir = opendir(Path)) == NULL)
    {
        /* If it is a file, remove it directly */
        if (remove(Path) != 0) 
        {
            ret = -1;
            LW_LOGI("remove file error");
            goto CommonReturn;
        }
        /* file does not exist */
        goto CommonReturn;
    }

    /* Traverse files in the directory */
    while ((entry = readdir(dir)) != NULL) 
    {
        if (LW_SafeStrCmp(entry->d_name, ".", sizeof(entry->d_name)) == 0 ||
            LW_SafeStrCmp(entry->d_name, "..", sizeof(entry->d_name)) == 0)
        {
            continue;
        }
        /* Construct the sub-path */
        LW_SNPrintf(nextPath, sizeof(nextPath), "%s/%s", Path, entry->d_name);
        /* Recursively remove sub-directory or file */
        if (LW_RemovemFileOrDir(nextPath) != 0) 
        {
            ret = -1;
            LW_LOGI("remove file error");
            goto CommonReturn;
        }
    }

    // Remove directory
    if (rmdir(Path) != 0) 
    {
        ret = -1;
        LW_LOGI("remove directory error");
        goto CommonReturn;
    }

CommonReturn:
    if (dir != NULL)
    {
        closedir(dir);
    }
    return ret;
}

static LW_ERR_T _LW_UdevInfoInit()
{
    LW_ERR_T ret = LW_SUCCESS;

    g_UdevInfo = malloc(sizeof(LW_UDEV_INFO));
    if (g_UdevInfo == NULL)
    {
        ret = -LW_ENOMEM;
        goto CommonReturn;
    }
    memset(g_UdevInfo, 0, sizeof(LW_UDEV_INFO));

CommonReturn:
    return ret;
}

static void _LW_UdevInfoFree()
{

    if (g_UdevInfo == NULL)
    {
        goto CommonReturn;
    }

    memset(g_UdevInfo, 0, sizeof(LW_UDEV_INFO));

    if (g_UdevInfo->MonitorInfo) 
    {
        free(g_UdevInfo->MonitorInfo);
        g_UdevInfo->MonitorInfo = NULL;
    }

    if (g_UdevInfo) 
    {
        free(g_UdevInfo);
        g_UdevInfo = NULL;
    }

CommonReturn:
    return;
}

void LW_UdevMonitorEventAdd()
{
    event_add(g_UdevMonitorEvent, NULL);

    LW_LOGI("Begin to monitor udev\n");
}

void LW_UdevMonitorEvent(
    int SockCtl,
    short EventTrigger,
    void* Arg
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    LW_MODULE_MODEL_MODE mode = LW_MODULE_MODEL_MODE_NONE;
    _LW_UdevMonitorFunc LW_UdevMonitorFunc = Arg;

    ret = LW_UdevMonitorTarget(g_UdevInfo, &mode);
    if ((ret < LW_SUCCESS) && (ret == -LW_ENODEV))
    {
        goto CommonReturn;
    }
    else if ((ret < LW_SUCCESS) && (ret == -LW_EINVAL))
    {
        ret = LW_SUCCESS;
        goto CommonReturn;
    }
    else if (ret < LW_SUCCESS)
    {
        goto CommonReturn;
    }

    ret = LW_UdevMonitorFunc(mode);
    if (ret < LW_SUCCESS)
    {
        LW_LOGI("Monitor handler failed\n");
        goto CommonReturn;
    }

CommonReturn:
    if (ret < LW_SUCCESS)
    {
        LW_LOGI("An exception occurred in udev checking, ret %d\n", ret);
        event_del(g_UdevMonitorEvent);
    }

    return;
}

LW_ERR_T
LW_UdevMonitorEventInit(
    struct event_base * EventBase,
    _LW_UdevInfoRegistFunc LW_UdevInfoRegistFunc,
    _LW_UdevMonitorFunc _LW_UdevMonitorFunc
    )
{
    LW_ERR_T ret = LW_SUCCESS;

    ret = _LW_UdevInfoInit();
    if (ret < LW_SUCCESS)
    {
        goto CommonReturn;
    }

    (void)LW_UdevInfoRegistFunc(g_UdevInfo);

#ifndef  LW_OPENWRT_UDEV_KERNEL
    ret = LW_UdevMonitorInit(LW_Monitor_Event_Source_Udev);
#else
    ret = LW_UdevMonitorInit(LW_Monitor_Event_Source_Kernel);
#endif
    if (ret < LW_SUCCESS)
    {
        LW_LOGI("udev monitor init failed\n");
        goto CommonReturn;
    }

    g_UdevMonitorEvent = event_new(
                                    EventBase, 
                                    LW_UdevMonitorGetFd(), 
                                    EV_PERSIST | EV_READ, 
                                    LW_UdevMonitorEvent, 
                                    _LW_UdevMonitorFunc
                                    );
    if (g_UdevMonitorEvent == NULL)
    {
        ret = -ENOMEM;
        LW_LOGI("new udev check event failed\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

void LW_UdevMonitorEventFree()
{
    if (g_UdevMonitorEvent)
    {
        event_free(g_UdevMonitorEvent);
        g_UdevMonitorEvent = NULL;

        LW_UdevMonitorRelease();
    }

    _LW_UdevInfoFree();
}
