#!/bin/bash
set -e -x
#PLATFORMList=(centos centos_arm64 openwrt__18.06__4.14.22__aarch64_cortex-a53 openwrt_mt7621)
#./build.sh TAG_PLATFORM=centos
WORK_ABSPATH=../
echo $WORK_ABSPATH
function build()
{
    #psbc
    pushd ${WORK_ABSPATH}/psbc/linux-uspace
    make clean
    make platform=$1 -B
    popd

    #lw_ecm_tool
    pushd ${WORK_ABSPATH}/lw_ecm_tool
    make clean
    make platform=$1 -B
    popd
}

tag_args()
{
# Limit the arguments.
    ARGS="TAG_PLATFORM"

    SAVED_ARGS=""

#    echo "Arguments:"
    for i in "$@"; do
        for j in $ARGS; do
        case $i in
            $j=*)
#            echo $j="${i#*=}"
            eval export $j="${i#*=}"
            SAVED_ARGS="$SAVED_ARGS $j=${i#*=}"
            ;;
        esac
        done
    done
}

tag_args $@

if [ -n "$TAG_PLATFORM" ]; then
    build $TAG_PLATFORM
else
    echo "build failed!"
fi
