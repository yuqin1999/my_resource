#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <errno.h>
#include <fcntl.h>
#include "lightwanSerialConfig.h"
#include "lightwanEvent.h"
#include "lightwanDhcp.h"
#include "lightwanEcmManager.h"

#define LW_ECM_NAME     "ECM_DEMO"

int _LW_EcmClient(
    const char *Msg
    )
{
    int ret = 0;
    int flags = 0;
    int clientSock = -1;
    socklen_t len = 0;
    fd_set writefds;
    fd_set readfds;
    struct timeval timeout;
    char replyStr[512] = {0};

    memset(replyStr, 0, sizeof(replyStr));

    clientSock = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (clientSock == -1) 
    {
        fprintf(stderr, "create socket failed: %s\n", strerror(ret));
        goto CommonReturn;
    }

    flags = fcntl(clientSock, F_GETFL, 0);
    if (flags == -1)
    {
        fprintf(stderr, "fcntl failed: %s\n", strerror(ret));
        goto CommonReturn;
    }

    if (fcntl(clientSock, F_SETFL, flags | O_NONBLOCK) == -1) 
    {
        fprintf(stderr, "fcntl failed: %s\n", strerror(ret));
        goto CommonReturn;
    }

    struct sockaddr_un serverAddr = 
    {
        .sun_family = AF_UNIX,
        .sun_path = LW_ECM_SERVER_SOCKET_PATH
    };

    timeout.tv_sec = 5;     /* 5 seconds*/
    timeout.tv_usec = 0;

    if (connect(clientSock, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) 
    {
        if (errno != EINPROGRESS)
        {
            fprintf(stderr, "connect failed: %s\n", strerror(errno));
            goto CommonReturn;
        }

        FD_ZERO(&writefds);
        FD_SET(clientSock, &writefds);

        ret = select(clientSock + 1, NULL, &writefds, NULL, &timeout);
        if (ret == -1) 
        {
            fprintf(stderr, "Select error: %s\n", strerror(ret));
            goto CommonReturn;
        } 
        else if (ret == 0) 
        {
            fprintf(stderr, "Connection timed out\n");
            goto CommonReturn;
        } 
        else 
        {
            len = sizeof(ret);
            if (getsockopt(clientSock, SOL_SOCKET, SO_ERROR, &ret, &len) < 0)
            {
                fprintf(stderr, "Getsockopt error: %s\n", strerror(ret));
                goto CommonReturn;
            }
            if (ret != 0)
            {
                fprintf(stderr, "Connection error: %s\n", strerror(ret));
                goto CommonReturn;
            }
        }
    }

    if (send(clientSock, Msg, strlen(Msg), 0) == -1)
    {
        fprintf(stderr, "Send failed: %s\n", strerror(errno));
        goto CommonReturn;
    }

    if (fcntl(clientSock, F_SETFL, flags) == -1)
    {
        fprintf(stderr, "Fcntl failed: %s\n", strerror(ret));
        goto CommonReturn;
    }

    FD_ZERO(&readfds);
    FD_SET(clientSock, &readfds);

    ret = select(clientSock + 1, &readfds, NULL, NULL, &timeout);
    if (ret == -1) 
    {
        fprintf(stderr, "Select error: %s\n", strerror(ret));
        goto CommonReturn;
    } 
    else if (ret == 0) 
    {
        fprintf(stderr, "Receive timed out\n");
        goto CommonReturn;
    } 
    else 
    {
        ret = recv(clientSock, replyStr, sizeof(replyStr) - 1, 0);
        if (ret < 0) 
        {
            fprintf(stderr, "Recv failed: %s\n", strerror(ret));
            goto CommonReturn;
        } 
        else if (ret == 0) 
        {
            fprintf(stderr, "Connection closed by peer\n");
            goto CommonReturn;
        }
    }

    fprintf(stderr, "Server reply:\r\n%s", replyStr);

CommonReturn:
    if (clientSock >= 0) close(clientSock);
    return 0;
}

void _LW_SetDaemon()
{
    pid_t pid;
    pid = fork();
    
    if (pid < 0) 
    {
        LW_LOGI("pid: error");
        exit(-1);
    }

    if (pid > 0) 
    {   
        exit(0);
    }

    umask(0);

    if (setsid() < 0)
    {
        LW_LOGI("setsid: error");
        exit(-1);
    }

    if (chdir("/") < 0)
    {
        LW_LOGI("chdir: ");
        exit(-1);
    }

    return;
}

static void _LW_Version()
{
    fprintf(stderr,
            "\n"
            "%s version: %s\n"
            "Issue: %s \n"
            "Git commit id: %s\n"
            "Build time: %s \n"
            "Update content:\n"
            "       1. Support roaming network(FM150)\n"
            "\n",
            LW_ECM_NAME, LW_ECM_TOOL_VERSION, LW_PROJECT_ISSUE_ID, GIT_COMMIT_ID, BUILD_TIME);
    return;
}

static void _LW_Usage()
{
    fprintf(stderr,
            "\n"
            "%s  usage:\n"
            "      [-t up|down]                             :start or down %s\n"
            "      [-a APN]                                 :configure apn\n"
            "      [-p serialPath]                          :set serial path\n"
            "      [-D]                                     :open debug log\n"
            "      [-h]                                     :%s usage.\n"
            "      [-c opendebug|closedebug|ATcmd]          :open or close debug, and configure manual AT cmd"
            "\n",
            LW_ECM_NAME, LW_ECM_NAME, LW_ECM_NAME);
    return;
}

int main(int argc, char* argv[])
{
    int c = -1;
    int ret = 0;
    int callType = LW_ECM_CALL_NONE;

    if (argc == 1)
    {
        _LW_Usage();
        goto CommonReturn;
    }

    LW_LOGInit();
    _LW_SetDaemon();

    while ((c = getopt(argc, argv, "vhc:a:t:p:D")) != -1)
    {
        switch(c)
        {
            case 'a':
            {
                LW_SetApn(optarg);
                break;
            }
            case 't':
            {
                if (strstr(optarg, "up"))
                {
                    callType = LW_ECM_CALL_UP;
                    LW_LOGI("ECM_DEMO Call up start...\n");
                }
                else if (strstr(optarg, "down"))
                {
                    callType = LW_ECM_CALL_DOWN;
                    LW_LOGI("ECM_DEMO Call down start...\n");
                }
                else
                {
                    _LW_Usage();
                    goto CommonReturn;
                }
                break;
            }
            case 'p':
            {
                LW_SetSerialPath(optarg);
                break;
            }
            case 'D':
            {
                LW_SetDebug();
                break;
            }
            case 'c':
            {
                _LW_EcmClient(optarg);
                goto CommonReturn;
            }
            case 'v':
            {
                _LW_Version();
                goto CommonReturn;
            }
            case 'h':
            {
                _LW_Usage();
                goto CommonReturn;
            }
            default:
            {
                _LW_Usage();
                goto CommonReturn;
            }
        }
    }

    if (callType == LW_ECM_CALL_NONE)
    {
        _LW_Usage();
        goto CommonReturn;
    }

    ret = LW_LockFile();
    if (ret != 0)
    {
        ret = -1;
        goto CommonReturn;
    }
    
    ret = LW_DialStarting(callType);
    LW_ReleaseFile();

CommonReturn:
    LW_LOGExit();

    return ret;
}