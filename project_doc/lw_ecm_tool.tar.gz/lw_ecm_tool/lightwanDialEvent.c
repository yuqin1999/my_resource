#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <pthread.h>
#include <sys/socket.h>
#include <event.h>
#include <signal.h>
#include <sys/types.h>
#include <dirent.h>
#include "lightwanSerialConfig.h"
#include "lightwanEvent.h"
#include "lightwanPlatformDefs.h"
#include "lightwanUdev.h"
#include "lightwanEcmManager.h"

/* AT cmd for call up & call down */
#define LW_SUPPORTED_DRIVER_MAX                         (16)

#define LW_SYS_USB_PATH                                 "/sys/bus/usb/devices/"

#define LW_USB_CHECK_INTERVAL                           (5)

#define LW_USB_CHECK_MAXTIMES                           (4)

LW_DIAL_DRIVER* g_driver[LW_SUPPORTED_DRIVER_MAX] = {NULL};

/*******************************************************************************
 * MODULE: driver probe
 *
 * DESCRIPTION:
 *      
 *      
 *
 *
 *
 */

void LW_DialDriverInit()
{
    int i = 0;

    g_driver[0] = LW_GetDriverGM500();
    g_driver[1] = LW_GetDriverME3630();
    g_driver[2] = LW_GetDriverFM150();
    g_driver[3] = LW_GetDriverEC20();
    g_driver[4] = LW_GetDriverTM22C();
    g_driver[5] = LW_GetDriverFM650();

    for (i = 0; i < LW_SUPPORTED_DRIVER_MAX && g_driver[i] != NULL; i++)
    {
        LW_LOGI("Supported vid=%s, pid=%s\n", g_driver[i]->IDVendor, g_driver[i]->IDProduct);
    }
}

int LW_GetUSBId(char *Path, char *Content, size_t Size)
{
    int ret;
    FILE *f;

    f = fopen(Path, "r");

    if (f == NULL)
    {
        return -1;
    }

    ret = fread(Content, 1, Size, f);

    fclose(f);

    return ret;
}

int LW_USBVidPidisEqual(LW_DIAL_DRIVER* Driver, const char *VID, const char *PID)
{
    unsigned int ret = 0;
    long pvid = 0xffff;
    long ppid = 0xffff;    
    long t_vid;
    long t_pid;

    if ((NULL == Driver) || (NULL == VID) || (NULL == PID))
    {
        goto CommonReturn;
    }

    t_vid = strtol(Driver->IDVendor, NULL, 16);
    t_pid = strtol(Driver->IDProduct, NULL, 16);
    pvid =  strtol(VID, NULL, 16);
    ppid =  strtol(PID, NULL, 16);

    if ((t_vid == pvid) && (t_pid == ppid))
    {
        ret = 1;
    }
    else
    {
        ret = 0;
    }

CommonReturn:
    return ret;
}

LW_DIAL_DRIVER* LW_USBVidPidMatch(int DialType)
{
    int ret = 0;
    struct dirent        *dent    = NULL;
    DIR                  *usbdir  = NULL;
    LW_DIAL_DRIVER* driver = NULL;
    char                  idvendor[64] = {0};
    char                  idproduct[64] = {0};
    char                  str_temp_path[512] = {0};
    int                   i   = 0;
    int                   j   = 0;

    do 
    {

        if (j > 0)
        {
            sleep(LW_USB_CHECK_INTERVAL);
        }

        usbdir = opendir(LW_SYS_USB_PATH);
        if (NULL == usbdir) 
        {
            ret = -1;
            LW_LOGI("open usb dir failed %s, %s\n", LW_SYS_USB_PATH, strerror(errno));
            break;
        }
        LW_LOGI("Check USB VendorId ProductId %d times\n", j);
        while (NULL != (dent = readdir(usbdir)) && driver == NULL)
        {
            if (strcmp(dent->d_name, ".") == 0 || strcmp(dent->d_name, "..") == 0)
            {
                continue;
            }
            
            memset(idvendor, 0, sizeof(idvendor));
            memset(idproduct, 0, sizeof(idproduct));

            memset(str_temp_path, 0, sizeof(str_temp_path));
            sprintf(str_temp_path, "%s%s%s", LW_SYS_USB_PATH, dent->d_name, "/idVendor");
            ret = LW_GetUSBId(str_temp_path, idvendor, 4);
            if ((ret <= 0) && (4 != ret))
            {
                continue;
            }

            memset(str_temp_path, 0, sizeof(str_temp_path));
            sprintf(str_temp_path, "%s%s%s", LW_SYS_USB_PATH, dent->d_name, "/idProduct");
            ret = LW_GetUSBId(str_temp_path, idproduct, 4);
            if ((ret <= 0) && (4 != ret))
            {
                continue;
            }

            LW_LOGI("Checking vid=%s, pid=%s\n", idvendor, idproduct);

            for (i = 0, driver = NULL; i < LW_SUPPORTED_DRIVER_MAX && g_driver[i] != NULL; i++)
            {
                if (LW_USBVidPidisEqual(g_driver[i], idvendor, idproduct))
                {
                    driver = g_driver[i];
                    break;
                }
            }
        }

        closedir(usbdir);
        if (driver != NULL)
        {
            break;
        }
        else
        {
            if (DialType == LW_ECM_CALL_DOWN)
            {
                break;
            }
            j++;
        }
        
    } while (j < LW_USB_CHECK_MAXTIMES);

    if (driver)
    {
        LW_LOGI("Match Driver %s\n", driver->Name);
    }
    else
    {
        LW_LOGI("Non Matched Driver, exiting...\n");

    }
    
    return driver;
}

static void _LW_SigpipeHandler()
{
    LW_LOGI("recv sigpipe and ignore\n");
}

static void* 
_LW_EcmServerThread() 
{
    int serverSock = -1;
    int clientSock = -1;
    char buffer[256] = {0};
    ssize_t len = 0;
    int opt = 1;

    serverSock = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (serverSock == -1) 
    {
        LW_LOGI("create socket failed\n");
        goto CommonReturn;
    }

    struct sockaddr_un serverAddr = 
    {
        .sun_family = AF_UNIX,
        .sun_path = LW_ECM_SERVER_SOCKET_PATH
    };

    if (setsockopt(serverSock, SOL_SOCKET, SO_REUSEADDR, (const void*)&opt, sizeof (opt)) == -1)
    {
        LW_LOGI("set SO_REUSEADDR failed\n");
        goto CommonReturn;
    }

    if (bind(serverSock, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) 
    {
        LW_LOGI("bind socket failed\n");
        goto CommonReturn;
    }

    if (listen(serverSock, 1) == -1) 
    {
        LW_LOGI("listen socket failed\n");
        goto CommonReturn;
    }

    LW_LOGI("Server begin listening\n");

    while (1)
    {
        clientSock = accept(serverSock, NULL, NULL);
        if (clientSock == -1)
        {
            LW_LOGI("accept socket failed\n");
            continue;
        }
    
        memset(buffer, 0, sizeof(buffer));
        len = recv(clientSock, buffer, sizeof(buffer), 0);
        if (len == -1) 
        {
            LW_LOGI("recv buffer failed\n");
            continue;
        }

        LW_LOGI("Received message from client: %.*s\n", (int)len, buffer);

        (void)LW_RecvMsg(clientSock, buffer);
    }

CommonReturn:
    if (clientSock >= 0) close(clientSock);
    if (serverSock >= 0) close(serverSock);

    pthread_exit(NULL);
    return NULL;
}

/*******************************************************************************
 * MODULE: start dial
 *
 * DESCRIPTION:
 *      
 *      
 *
 *
 *
 */
int LW_DialStarting(int DialType)
{
    int ret = 0;
    pthread_t serverThread = 0;
    pthread_attr_t attr;
    LW_DIAL_DRIVER* drv = NULL;
    BOOL isAttrInited = FALSE;

    if (LW_CheckIntfLoaded() == FALSE)
    {
        ret = ENXIO;
        goto CommonReturn;
    }

    LW_DialDriverInit();

    /* kill pid */
    if (signal(SIGPIPE, _LW_SigpipeHandler) == SIG_ERR)
    {
        LW_LOGI("Occur error.\n");
    }

    drv = LW_USBVidPidMatch(DialType);
    if (drv == NULL)
    {
        ret = -1;
        goto CommonReturn;
    }

    LW_SetSerialPath(drv->TtyUSBPath);

    ret = LW_SerialInitFd();
    if (ret < 0)
    {
        LW_LOGI("Get serial fd error\n");
        goto CommonReturn;
    }

    ret = drv->Init();
    if (ret < 0)
    {
        goto CommonReturn;
    }

    if (DialType == LW_ECM_CALL_UP)
    {
        if(pthread_attr_init(&attr) != 0)
        {
            ret = -1;
            LW_LOGI("thread attr init failed\n");
            goto CommonReturn;
        }

        isAttrInited = TRUE;

        if (pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED) != 0)
        {
            ret = -1;
            LW_LOGI("thread set detach failed\n");
            goto CommonReturn;
        }
    
        if (pthread_create(&serverThread, &attr, _LW_EcmServerThread, NULL) != 0)
        {
            ret = -1;
            LW_LOGI("thread create failed\n");
            goto CommonReturn;
        }

        isAttrInited = FALSE;

        if (pthread_attr_destroy(&attr) != 0) 
        {
            ret = -1;
            LW_LOGI("thread attr destroy failed\n");
            goto CommonReturn;
        }
    }

    drv->Processing(DialType);

    drv->Exit();

CommonReturn:
    if (isAttrInited)
    {
        (void)pthread_attr_destroy(&attr);
    }

    return ret;
}

