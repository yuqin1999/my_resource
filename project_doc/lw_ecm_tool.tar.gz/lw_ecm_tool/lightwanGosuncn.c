#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <pthread.h>
#include <sys/socket.h>
#include <event.h>
#include <signal.h>
#include <time.h>
#include <dirent.h>

#include "lightwanSafeStr.h"
#include "lightwanSerialConfig.h"
#include "lightwanErrno.h"
#include "lightwanEvent.h"
#include "lightwanDhcp.h"
#include "lightwanEcmMsg.h"
#include "lightwanUdev.h"
#include "lightwanEcmManager.h"

/* ME3630 pvid */
#define LW_ME3630_ID_VENDOR                         "19d2"
#define LW_ME3630_ID_PRODUCT                        "1476"

/* GM500 pvid */
#define LW_GM500_ID_VENDOR                          "305a"
#define LW_GM500_ID_PRODUCT                         "1406"

/* AT cmd */
#define LW_ATCMD_ATI                                "ATI\r\n"
#define LW_ATCMD_CPIN                               "AT+CPIN?\r\n"
#define LW_ATCMD_ZSNT_800                           "AT+ZSNT=8,0,3\r\n"         /* LTE prefer */
#define LW_ATCMD_ZDATACFG_PREFIX                    "AT+ZDATACFG=1,\"IP\",\""
#define LW_ATCMD_ZDATACFG_SUFFIX                    "\",0,\"\",\"\"\r\n"
#define LW_ATCMD_ZDATACFG_STATUS                    "AT+ZDATACFG?\r\n"
#define LW_ATCMD_COPS_FORMAT_ADAPT                  "AT+COPS=3,2\r\n"
#define LW_ATCMD_COPS                               "AT+COPS?\r\n"
#define LW_ATCMD_ZECMCALL_UP                        "AT+ZECMCALL=1\r\n"
#define LW_ATCMD_ZECMCALL_DOWN                      "AT+ZECMCALL=0\r\n"
#define LW_ATCMD_ZECMCALL_STATUS                    "AT+ZECMCALL?\r\n"
#define LW_ATCMD_CGREG_STATUS                       "AT+CGREG?\r\n"
#define LW_ATCMD_CIMI                               "AT+CIMI\r\n"
#define LW_ATCMD_ZPAS                               "AT+ZPAS?\r\n"           /* network format */
#define LW_ATCMD_ZCDS                               "AT+ZCDS?\r\n"           /* mcc/mnc/lac/cid */
#define LW_ATCMD_CGMM                               "AT+CGMM\r\n"
#define LW_ATCMD_ZSRVRSP                            "AT+ZSRVRSP?\r\n"        /* rsrp/rsrq/sinr */

/* AT cmd reply */
#define LW_ATCMD_REPLY_OK                          "OK"
#define LW_ATCMD_REPLY_ZECMCALL_STATUS_TYPE1       ",,"
#define LW_ATCMD_REPLY_ZECMCALL_STATUS_TYPE2       ", ,"
#define LW_ATCMD_REPLY_CGREG_STATUS                "0,1"
#define LW_ATCMD_REPLY_LTE                         "LTE"

#define LW_ATCMD_REPLY_READY                       "READY"
#define LW_ATCMD_REPLY_ERROR                       "ERROR"
#define LW_ATCMD_REPLY_CONNECT                     "CONNECT"
#define LW_ATCMD_REPLY_CONNECTED                   "Connected"
#define LW_ATCMD_REPLY_CS_PS                       "CS_PS"
#define LW_ATCMD_REPLY_PS_ONLY                     "PS_ONLY"

typedef enum _LW_ATCMD_CALL_INIT_CMD
{
    LW_ATCMD_CALL_INIT_NONE,

    LW_ATCMD_CALL_INIT_ZSNT_800,
    LW_ATCMD_CALL_INIT_ZDATACFG,

    LW_ATCMD_CALL_INIT_MAX,
} LW_ATCMD_CALL_INIT_CMD;

typedef enum _LW_ATCMD_CALL_UP_CMD
{
    LW_ATCMD_CALL_UP_NONE,

    LW_ATCMD_CALL_UP_ATI,
    LW_ATCMD_CALL_UP_CPIN,
    LW_ATCMD_CALL_UP_ZDATACFG_STATUS,
    LW_ATCMD_CALL_UP_CGREG_STATUS,
    LW_ATCMD_CALL_UP_COPS_FORMAT_ADAPT,
    LW_ATCMD_CALL_UP_COPS,
    LW_ATCMD_CALL_UP_ZECMCALL_DOWN,
    LW_ATCMD_CALL_UP_ZECMCALL_UP,
    LW_ATCMD_CALL_UP_ZECMCALL_STATUS,

    LW_ATCMD_CALL_UP_MAX,
} LW_ATCMD_CALL_UP_CMD;

typedef enum _LW_ATCMD_CALL_DOWN_CMD
{
    LW_ATCMD_CALL_DOWN_NONE,

    LW_ATCMD_CALL_DOWN_ZECMCALL_DOWN,
    LW_ATCMD_CALL_DOWN_ZECMCALL_STATUS,

    LW_ATCMD_CALL_DOWN_MAX,
} LW_ATCMD_CALL_DOWN_CMD;

typedef enum _LW_ATCMD_CALL_STATUS_CMD
{
    LW_ATCMD_CALL_STATUS_NONE,
    
    LW_ATCMD_CALL_STATUS_CGREG,
    LW_ATCMD_CALL_STATUS_ZPAS,
    LW_ATCMD_CALL_STATUS_COPS,
    LW_ATCMD_CALL_STATUS_ZCDS,
    LW_ATCMD_CALL_STATUS_ATI,
    LW_ATCMD_CALL_STATUS_ZSRVRSP,
    LW_ATCMD_CALL_STATUS_CIMI,
    LW_ATCMD_CALL_STATUS_ZECMCALL_STATUS,

    LW_ATCMD_CALL_STATUS_MAX,
} LW_ATCMD_CALL_STATUS_CMD;

#ifdef LW_ECM_FEATURE_SHOW_REPORT
/* index starts from 0 */
#define LW_ATCMD_ZCDS_TAC_INDEX                     3
#define LW_ATCMD_ZCDS_CI_INDEX                      4
#define LW_ATCMD_ZSRVRSP_RSRP_INDEX                 0
#define LW_ATCMD_ZSRVRSP_RSRQ_INDEX                 1
#define LW_ATCMD_ZSRVRSP_SINR_INDEX                 2
#define LW_ATCMD_CGACT_DIALSTATE_INDEX              1
#define LW_ATCMD_CIMI_IMSI_INDEX                    0

#define LW_ATCMD_COPS_MCC_MNC_INDEX                 2
#define LW_ATCMD_COPS_MCC_INDEX                     1
#define LW_ATCMD_COPS_MNC_INDEX                     4
#define LW_ATCMD_COPS_MCC_OR_MNC_MAX_LEN            4  /* include null-terminator */
/*******************************************************************************
 * NAME:  _LW_ShowInfoParseZpas
 *
 * DESCRIPTION:
 *      Parse reply content to get param, eg:
 * 
 *      
 *      reply:
 *         
 *          +ZPAS: "LTE","CS_PS","FDD"
 *
 *          OK
 *          
 *      result:
 *          networktype = lte
 * 
 *
 * INPUTS:
 *      ReplyContent:               reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void
_LW_ShowInfoParseZpas(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    if (strstr(ReplyContent, "+ZPAS") == NULL)
    {
        LW_LOGI("zpas reply incalid\n");
        goto CommonReturn;
    }

    if (strstr(ReplyContent, LW_ATCMD_REPLY_LTE))
    {
        WwanManagerInfo->ShowInfo.NetworkType = LW_WWAN_NETWORK_LTE;
        LW_LOGI("zpas reply LTE\n");
    }
    else
    {
        WwanManagerInfo->ShowInfo.NetworkType = LW_WWAN_NETWORK_NONE;
        LW_LOGI("zpas reply others network type, %s\n", ReplyContent);
    }

CommonReturn:
    return;
}
/*******************************************************************************
 * NAME:  _LW_ShowInfoParseCops
 *
 * DESCRIPTION:
 *      Parse reply content to get param, eg:
 *      
 *      reply:
 *
 *          +COPS: 0,2,"46011",7
 *
 *          OK
 * 
 *      result:
 *          mcc=460
 *          mnc=11
 * 
 * INPUTS:
 *      ReplyContent:               reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void
_LW_ShowInfoParseCops(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    size_t len = 0;
    char *pStart = NULL;
    char mccmnc[LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN] = {0};

    pStart = strstr(ReplyContent, "+COPS");
    if (pStart == NULL)
    {
        LW_LOGI("cops reply invalid\n");
        goto CommonReturn;
    }

    /* such as "46001" or "316010" */
    len = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_COPS_MCC_MNC_INDEX, mccmnc);
    if (len == 0)
    {
        LW_LOGI("get mcc mnc failed\n");
        goto CommonReturn;
    }

    LW_SafeStrCopy(WwanManagerInfo->ShowInfo.Mcc, LW_ATCMD_COPS_MCC_OR_MNC_MAX_LEN, &mccmnc[LW_ATCMD_COPS_MCC_INDEX]);
    LW_SafeStrCopy(WwanManagerInfo->ShowInfo.Mnc, LW_ATCMD_COPS_MCC_OR_MNC_MAX_LEN, &mccmnc[LW_ATCMD_COPS_MNC_INDEX]);

    if (WwanManagerInfo->ShowInfo.Mnc[2] == '\"')
    {
        WwanManagerInfo->ShowInfo.Mnc[2] = 0;
    }

CommonReturn:
    return;
}

/*******************************************************************************
 * NAME:  _LW_ShowInfoParseZcds
 *
 * DESCRIPTION:
 *      Parse reply content to get param, eg:
 * 
 *      
 *      reply:
 *         
 *          +ZCDS:100,460,11,1016,E48ED01,-122,99,2,-11,321,-11,460015471018438
 *
 *          OK
 *
 *      result:
 *          lac=1016
 *          ci=E48ED01
 * 
 * INPUTS:
 *      ReplyContent:               reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void
_LW_ShowInfoParseZcds(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    size_t ciLen = 0;
    size_t lacLen = 0;
    char *pStart = NULL;
    char ci[LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN] = {0};
    char lac[LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN] = {0};

    pStart = strstr(ReplyContent, "+ZCDS");
    if (pStart == NULL)
    {
        LW_LOGI("zcds reply invalid\n");
        goto CommonReturn;
    }

    lacLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_ZCDS_TAC_INDEX, lac);
    if (lacLen == 0)
    {
        LW_LOGI("get lac failed\n");
    }
    else
    {
        WwanManagerInfo->ShowInfo.Lac = strtol(lac , NULL, LW_PARAM_NUM_FORMAT_HEX);
    }

    ciLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_ZCDS_CI_INDEX, ci);
    if (ciLen == 0)
    {
        LW_LOGI("get ci failed\n");
    }
    else
    {
        WwanManagerInfo->ShowInfo.Ci = (uint64_t)strtoll(ci , NULL, LW_PARAM_NUM_FORMAT_HEX);
    }

CommonReturn:
    return;
}
/*******************************************************************************
 * NAME:  _LW_ShowInfoParseCimi
 *
 * DESCRIPTION:
 *      Parse reply content to get param, eg:
 * 
 *      reply:
 *          460015471018438
 * 
 *          OK
 * 
 *      result:
 *          imsi=460015471018438
 *
 * INPUTS:
 *      ReplyContent:               reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void
_LW_ShowInfoParseCimi(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    size_t imsiLen = 0;

    if (ReplyContent == NULL)
    {
        LW_LOGI("cimi reply invalid\n");
        goto CommonReturn;
    }

    imsiLen = LW_GetStringValAfterNthComma(ReplyContent, LW_ATCMD_CIMI_IMSI_INDEX, WwanManagerInfo->ShowInfo.Imsi);
    if (imsiLen == 0)
    {
        LW_LOGI("get imsi failed\n");
    }

CommonReturn:
    return;
}

/*******************************************************************************
 * NAME:  _LW_ShowInfoParseAti
 *
 * DESCRIPTION:
 *      Parse reply content to get param, eg:
 * 
 *      reply:
 *          Manufacturer: GOSUNCNWELINK
 *          Model: ME3630-W
 *          Revision: ME3630C3BV2.0B10
 *          IMEI: 866871052862080
 *          OK
 * 
 *      result:
 *          moduleModel=ME3630
 *
 * INPUTS:
 *      ReplyContent:               reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void
_LW_ShowInfoParseAti(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    if (strstr(ReplyContent, LW_ATCMD_REPLY_ME3630))
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_ME3630;
    }
    else if (strstr(ReplyContent, LW_ATCMD_REPLY_GM500))
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_GM500;
    }
    else
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_NONE;
        LW_LOGI("ati reply invalid\n");
        goto CommonReturn;
    }

CommonReturn:
    return;
}

/*******************************************************************************
 * NAME:  _LW_ShowInfoParseZsrvrsp
 *
 * DESCRIPTION:
 *      Parse reply content to get param, eg:
 * 
 *      reply:
 *          +ZSRVRSP:"-122","-10",2
 * 
 *          OK
 * 
 *      result:
 *          rsrp=-122
 *          rsrq=-10
 *          sinr=2
 *
 * INPUTS:
 *      ReplyContent:               reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void
_LW_ShowInfoParseZsrvrsp(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    int rsrp = 0;
    int rsrq = 0;
    int sinr = 0;
    char *pStart = NULL;

    pStart = strstr(ReplyContent, "+ZSRVRSP");
    if (pStart == NULL)
    {
        LW_LOGI("zsrvrsp reply invalid\n");
        goto CommonReturn;
    }

    if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_ZSRVRSP_RSRP_INDEX, &rsrp) < LW_SUCCESS)
    {
        LW_LOGI("get rsrp failed\n");
    }
    else
    {
        if (rsrp < 0)
        {
            LW_LOGD("get rsrp %ddBm\n", rsrp);
            WwanManagerInfo->ShowInfo.Rsrp = LW_SHOW_INFO_RSRP_TO_PARAM(rsrp);
        }
    }

    if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_ZSRVRSP_RSRQ_INDEX, &rsrq) < LW_SUCCESS)
    {
        LW_LOGI("get rsrq failed\n");
    }
    else
    {
        if (rsrq < 0)
        {
            LW_LOGD("get rsrq %ddB\n", rsrq);
            WwanManagerInfo->ShowInfo.Rsrq = LW_SHOW_INFO_RSRQ_TO_PARAM(rsrq);
        }
    }

    if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_ZSRVRSP_SINR_INDEX, &sinr) < LW_SUCCESS)
    {
        LW_LOGI("get sinr failed\n");
    }
    else
    {
        LW_LOGD("get sinr %ddB\n", sinr);
        WwanManagerInfo->ShowInfo.Sinr = LW_SHOW_INFO_SINR_TO_PARAM(sinr);
    }

CommonReturn:
    return;
}

#endif /* LW_ECM_FEATURE_SHOW_REPORT */

static LW_ERR_T
_LW_GetCallInitAtCmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_UP_CMD AtCmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;

    switch (AtCmdIndex)
    {
        case LW_ATCMD_CALL_INIT_ZSNT_800:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ZSNT_800);
            break;
        }
        case LW_ATCMD_CALL_INIT_ZDATACFG:
        {
            LW_LOGI("Set Apn %s\n", LW_GetApn());
            len = LW_SNPrintf(ATcmd, ATcmdLen, "%s%s%s", LW_ATCMD_ZDATACFG_PREFIX, LW_GetApn(), LW_ATCMD_ZDATACFG_SUFFIX);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GetCallUpAtCmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_UP_CMD AtCmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;

    switch (AtCmdIndex)
    {
        case LW_ATCMD_CALL_UP_ATI:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ATI);
            break;
        }
        case LW_ATCMD_CALL_UP_CPIN:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CPIN);
            break;
        }
        case LW_ATCMD_CALL_UP_ZDATACFG_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ZDATACFG_STATUS);
            break;
        }
        case LW_ATCMD_CALL_UP_CGREG_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CGREG_STATUS);
            break;
        }
        case LW_ATCMD_CALL_UP_COPS_FORMAT_ADAPT:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_COPS_FORMAT_ADAPT);
            break;
        }
        case LW_ATCMD_CALL_UP_COPS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_COPS);
            break;
        }
        case LW_ATCMD_CALL_UP_ZECMCALL_DOWN:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ZECMCALL_DOWN);
            break;
        }
        case LW_ATCMD_CALL_UP_ZECMCALL_UP:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ZECMCALL_UP);
            break;
        }
        case LW_ATCMD_CALL_UP_ZECMCALL_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ZECMCALL_STATUS);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GetCallDownAtCmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_DOWN_CMD AtCmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;

    switch (AtCmdIndex)
    {
        case LW_ATCMD_CALL_DOWN_ZECMCALL_DOWN:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ZECMCALL_DOWN);
            break;
        }
        case LW_ATCMD_CALL_DOWN_ZECMCALL_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ZECMCALL_STATUS);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GetCallStatusAtCmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_STATUS_CMD AtCmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;
    switch (AtCmdIndex)
    {
        case LW_ATCMD_CALL_STATUS_CGREG:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CGREG_STATUS);
            break;
        }
        case LW_ATCMD_CALL_STATUS_ZPAS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ZPAS);
            break;
        }
        case LW_ATCMD_CALL_STATUS_COPS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_COPS);
            break;
        }
        case LW_ATCMD_CALL_STATUS_ZCDS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ZCDS);
            break;
        }
        case LW_ATCMD_CALL_STATUS_ATI:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ATI);
            break;
        }
        case LW_ATCMD_CALL_STATUS_ZSRVRSP:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ZSRVRSP);
            break;
        }
        case LW_ATCMD_CALL_STATUS_CIMI:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CIMI);
            break;
        }
        case LW_ATCMD_CALL_STATUS_ZECMCALL_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ZECMCALL_STATUS);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }
    
CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GosGetATcmdFunc(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_TYPE ATcmdType,
    uint32_t ATcmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;

    switch (ATcmdType)
    {
        case LW_ATCMD_CALL_INIT:
        {
            ret = _LW_GetCallInitAtCmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        case LW_ATCMD_CALL_UP:
        {
            ret = _LW_GetCallUpAtCmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        case LW_ATCMD_CALL_DOWN:
        {
            ret = _LW_GetCallDownAtCmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        case LW_ATCMD_CALL_STATUS:
        {
            ret = _LW_GetCallStatusAtCmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

CommonReturn:
    return ret;
}

static BOOL
_LW_IsValidReply(
    const char * ATreply,
    LW_ATCMD_TYPE ATcmdType, 
    uint32_t *ATcmdIndex
    )
{
    BOOL isValidReply = FALSE;

    if (strstr(ATreply, LW_ATCMD_REPLY_OK))
    {
        isValidReply = TRUE;
    }

    switch (ATcmdType)
    {
        case LW_ATCMD_CALL_UP:
        {
            if (*ATcmdIndex == LW_ATCMD_CALL_UP_CPIN)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_READY) == NULL)
                {
                    isValidReply = FALSE;
                }
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_UP_CGREG_STATUS)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_CGREG_STATUS) == NULL)
                {
                    isValidReply = FALSE;
                }
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_UP_ZECMCALL_DOWN)
            {
                /* ignore reply */
                LW_LOGI("Ignore AT zecmcall down reply\n");
                isValidReply = TRUE;
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_UP_ZECMCALL_UP)
            {
                /* ignore reply */
                LW_LOGI("Ignore AT zecmcall up reply\n");
                isValidReply = TRUE;
            }

            break;
        }
        case LW_ATCMD_CALL_DOWN:
        {
            /* ignore reply */
            LW_LOGI("Ignore call down reply\n");
            isValidReply = TRUE;
            break;
        }
        case LW_ATCMD_CALL_STATUS:
        {
            /* ignore reply */
            isValidReply = TRUE;
            break;
        }
        case LW_ATCMD_CALL_MESSAGES:
        {
            /* ignore reply */
            isValidReply = TRUE;
            break;
        }
        default:
        {
            break;
        }
    }

    return isValidReply;
}

static BOOL
_LW_GosATreplyHandlerFunc(
    const char * ATreply,
    LW_ATCMD_TYPE ATcmdType, 
    uint32_t *ATcmdIndex
    )
{
    BOOL isHandled = FALSE;

    if (!_LW_IsValidReply(ATreply, ATcmdType, ATcmdIndex)) 
    {
        goto CommonReturn;
    }

    isHandled = TRUE;

    switch (ATcmdType)
    {
         case LW_ATCMD_CALL_INIT:
        {
            *ATcmdIndex =  *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_INIT_MAX)
            {
                LW_LOGI("Initializing successful! to call up\n");

                /* from call up to call status */
                LW_ATCallUp();
            }
            break;
        }
        case LW_ATCMD_CALL_UP:
        {
            if (*ATcmdIndex == LW_ATCMD_CALL_UP_ZECMCALL_STATUS)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_ZECMCALL_STATUS_TYPE1)|| 
                    strstr(ATreply, LW_ATCMD_REPLY_ZECMCALL_STATUS_TYPE2))
                {
                    LW_SetDialState(FALSE);
                }
                else
                {
                    LW_SetDialState(TRUE);
                }
            }

            *ATcmdIndex =  *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_UP_MAX)
            {
                if (LW_GetDialState())
                {
                    LW_WWANDhcpup();
                    LW_LOGI("Dialing successful! to call status\n");
                }
                else
                {
                    LW_LOGI("Dialing exception! to call status\n"); 
                }

                /* from call up to call status */
                LW_ATCallStatus();
            }
            break;
        }
        case LW_ATCMD_CALL_DOWN:
        {
            *ATcmdIndex =  *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_DOWN_MAX)
            {
                LW_WWANDhcpdown();
                LW_LOGI("Dhcp stopped\n");

                LW_EventStop();
            }
            break;
        }
        case LW_ATCMD_CALL_STATUS:
        {
            if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_ZECMCALL_STATUS)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_ZECMCALL_STATUS_TYPE1)|| 
                    strstr(ATreply, LW_ATCMD_REPLY_ZECMCALL_STATUS_TYPE2))
                {
                    LW_SetDialState(FALSE);
                }
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_CGREG)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_CGREG_STATUS) == NULL)
                {
                    LW_SetDialState(FALSE);
                }
            }
#ifdef LW_ECM_FEATURE_SHOW_REPORT
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_ZPAS)
            {
                _LW_ShowInfoParseZpas(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_COPS)
            {
                _LW_ShowInfoParseCops(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_ZCDS)
            {
                _LW_ShowInfoParseZcds(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_CIMI)
            {
                _LW_ShowInfoParseCimi(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_ATI)
            {
                _LW_ShowInfoParseAti(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_ZSRVRSP)
            {
                _LW_ShowInfoParseZsrvrsp(ATreply, LW_GetShowInfoConf());
            }
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

            *ATcmdIndex =  *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_MAX)
            {
#ifdef LW_ECM_FEATURE_SHOW_REPORT
                if (!LW_GetDialState())
                {
                    LW_GetShowInfoConf()->ShowInfo.DialState = 0;
                }
                else
                {
                    LW_GetShowInfoConf()->ShowInfo.DialState = 1;
                }
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

                if (!LW_GetDialState())
                {
                    LW_LOGI("Dialing exception! to redial\n");
                    LW_ATCallUp();
                    goto CommonReturn;
                }

                LW_LOGI("Dialing normally! to call status again\n");
                LW_ATCallStatus();
            }

            break;
        }
        case LW_ATCMD_CALL_MESSAGES:
        {
            (void)LW_SendToClientSuccess(ATreply);
            break;
        }
        default:
        {
            LW_LOGI("ATcmdType invalid\n");
            break;
        }
    }

CommonReturn:
    return isHandled;
}

static void _LW_GosUdevInfoRegistFunc(LW_UDEV_INFO *UdevInfo)
{
    UdevInfo->MonitorCnt = 2;

    UdevInfo->MonitorInfo = malloc(sizeof(LW_UDEV_MONITOR_INFO) * UdevInfo->MonitorCnt);
    if (UdevInfo->MonitorInfo == NULL)
    {
        UdevInfo->MonitorCnt = 0;
        LW_LOGI("malloc failed\n");
        goto CommonReturn;
    }

    memset(UdevInfo->MonitorInfo, 0, sizeof(LW_UDEV_MONITOR_INFO) * UdevInfo->MonitorCnt);

    UdevInfo->MonitorInfo[0].Mode = LW_MODULE_MODEL_MODE_NORMAL;
    LW_SafeStrCopy(UdevInfo->MonitorInfo[0].DeviceAction, LW_UDEV_DEVICE_ACTION_STR_MAX, "add");
    LW_SafeStrCopy(UdevInfo->MonitorInfo[0].IdVendor, LW_VID_PID_LENGTH_MAX, LW_ME3630_ID_VENDOR);
    LW_SafeStrCopy(UdevInfo->MonitorInfo[0].IdProduct, LW_VID_PID_LENGTH_MAX, LW_ME3630_ID_PRODUCT);

    UdevInfo->MonitorInfo[1].Mode = LW_MODULE_MODEL_MODE_NORMAL;
    LW_SafeStrCopy(UdevInfo->MonitorInfo[1].DeviceAction, LW_UDEV_DEVICE_ACTION_STR_MAX, "add");
    LW_SafeStrCopy(UdevInfo->MonitorInfo[1].IdVendor, LW_VID_PID_LENGTH_MAX, LW_GM500_ID_VENDOR);
    LW_SafeStrCopy(UdevInfo->MonitorInfo[1].IdProduct, LW_VID_PID_LENGTH_MAX, LW_GM500_ID_PRODUCT);

CommonReturn:
    return;
}

static LW_ERR_T  _LW_GosUdevMonitorFunc(LW_MODULE_MODEL_MODE Mode)
{
    LW_ERR_T ret = LW_SUCCESS;

    switch (Mode)
    {
        case LW_MODULE_MODEL_MODE_NORMAL:
        {
            memset(LW_GetCrashInfoConf(), 0, sizeof(LW_GetCrashInfoConf()->CrashInfo));
            LW_GetCrashInfoConf()->InfoType = LW_WWAN_MANAGER_INFO_CRASH;
            LW_GetCrashInfoConf()->WwanModule = LW_WWAN_MODULE_MODEL_NONE;

#ifdef LW_ECM_FEATURE_SHOW_REPORT
            if (LW_GetShowInfoConf()->WwanModule != LW_WWAN_MODULE_MODEL_NONE)
            {
                LW_GetCrashInfoConf()->WwanModule = LW_GetShowInfoConf()->WwanModule;
            }
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

            LW_GetCrashInfoConf()->CrashInfo.TimeStamp = time(NULL);
            LW_GetCrashInfoConf()->CrashInfo.CrashFileFlag = 0;

#ifdef LW_ECM_FEATURE_CRASH_ALERT
            ret = LW_SendMsgToAgent(LW_GetCrashInfoConf());
            if (ret < LW_SUCCESS)
            {
                goto CommonReturn;
            }
#endif /* LW_ECM_FEATURE_CRASH_ALERT */

            if (LW_CheckIntfLoaded() == FALSE)
            {
                ret = -LW_ENXIO;
                goto CommonReturn;
            }

            ret = LW_RedialByUdevMonitor(
                                        TRUE, 
                                        &_LW_GosGetATcmdFunc, 
                                        &_LW_GosATreplyHandlerFunc, 
                                        &_LW_GosUdevInfoRegistFunc,
                                        &_LW_GosUdevMonitorFunc
                                        );
            if (ret < LW_SUCCESS)
            {
                LW_LOGI("Redial failed, exit...\n");
                goto CommonReturn;
            }
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            break;
        }
    }

CommonReturn:
    return ret;
}

static int _LW_GosInit()
{
    int ret = 0;

    LW_RegistSignal();

    if (LW_EventInit(
                    FALSE, 
                    &_LW_GosGetATcmdFunc, 
                    &_LW_GosATreplyHandlerFunc, 
                    &_LW_GosUdevInfoRegistFunc, 
                    &_LW_GosUdevMonitorFunc
                    ) < LW_SUCCESS)
    {
        ret = -1;
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static int _LW_GosProcessing(int DialType)
{
    return LW_EventHandleDispatch(DialType);
}

static void _LW_GosExit()
{
    LW_LOGI("Processing stopped\n");
}

LW_DIAL_DRIVER g_DialDriverGM500 = 
{
    .Name = "GM500",
    .IDVendor = "305a",
    .IDProduct = "1406",
    .TtyUSBPath = "/dev/ttyUSB2",
    .Init = _LW_GosInit,
    .Exit = _LW_GosExit,
    .Processing = _LW_GosProcessing,
};

LW_DIAL_DRIVER g_DialDriverME3630 = 
{
    .Name = "ME3630",
    .IDVendor = "19D2",
    .IDProduct = "1476",
    .TtyUSBPath = "/dev/ttyUSB2",
    .Init = _LW_GosInit,
    .Exit = _LW_GosExit,
    .Processing = _LW_GosProcessing,
};

LW_DIAL_DRIVER* LW_GetDriverGM500()
{
    return &g_DialDriverGM500;
}

LW_DIAL_DRIVER* LW_GetDriverME3630()
{
    return &g_DialDriverME3630;
}
