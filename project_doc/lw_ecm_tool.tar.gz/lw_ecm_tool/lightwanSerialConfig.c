
#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdarg.h>
#include <dirent.h>
#include <termios.h>
#include <unistd.h>
#include <sys/file.h>
#include <errno.h>
#include "lightwanSerialConfig.h"
#include "lightwanEvent.h"

#define TTYUSB_BAUDRATE                         B115200
#define SERIAL_PATH_DEFAULT                     "/dev/ttyUSB2"
#define SERIAL_PATH_LEN                         (256)

int g_SerialFd = -1;

char g_serialpath[SERIAL_PATH_LEN] = {0};


void LW_SetSerialPath(const char* Path)
{
    strncpy(g_serialpath, Path, SERIAL_PATH_LEN);
    g_serialpath[SERIAL_PATH_LEN - 1] = 0;
}

void LW_LOGInit()
{
	openlog("ECM", LOG_CONS | LOG_PID, LOG_USER);
}

void LW_LOGExit()
{
	closelog();
}

int LW_SerialGetFd()
{
    return g_SerialFd;
}

void LW_SerialConfigInit(struct termios * Config)
{
    bzero((void*)(Config),sizeof(struct termios));

    /*config to raw mode*/
    cfmakeraw(Config);

    cfsetispeed(Config, TTYUSB_BAUDRATE);
    cfsetospeed(Config, TTYUSB_BAUDRATE);

    Config->c_cflag |= CLOCAL |CREAD ;
    Config->c_cflag &= ~CSIZE;
    Config->c_cflag |= CS8;
    Config->c_cflag &= ~PARENB;/*No Parity func*/
    Config->c_iflag &= ~INPCK; /*Disable parity*/
    Config->c_cflag &= ~CSTOPB;/*1 bit stopbits*/
    Config->c_lflag &= ~(ICANON | ISIG);  /*Input*/
    Config->c_oflag &= ~OPOST;   /*Output*/

    /* VTIME and VMIN require 1 byte return while BLOCK mode, otherwise block */
    //Config->c_cc[VTIME] = 1;
    //Config->c_cc[VMIN] = 255;
}

int LW_SerialInitFd()
{
    int ret = -1;
    int fd = 0;
    struct termios attr;

    LW_SerialConfigInit(&attr);
    if (strlen(g_serialpath) != 0)
    {
        fd = open(g_serialpath, O_RDWR | O_NOCTTY | O_CLOEXEC | O_NONBLOCK);
    }
    else
    {
        fd = open(SERIAL_PATH_DEFAULT, O_RDWR | O_NOCTTY | O_CLOEXEC | O_NONBLOCK);
    }

    if (fd < 0)
    {
        LW_LOGI("fd open failed , %s\n", strerror(errno));
        goto CommonReturn;
    }
    tcsetattr(fd, TCSANOW, &attr);

    tcflush(fd, TCIOFLUSH);

    ret = fcntl(fd, F_GETFL, 0);
    if (ret < 0)
    {
        close(fd);
        LW_LOGI("fd fcntl failed , %s\n", strerror(errno));
        goto CommonReturn;
    }

    ret = 0;
    g_SerialFd = fd;

CommonReturn:
    return ret;
}

void LW_SerialFdFlush()
{
    tcflush(g_SerialFd, TCIOFLUSH);
}

void LW_SerialCloseFd()
{
    if (g_SerialFd >= 0) 
    {
        close(g_SerialFd);
        g_SerialFd = -1;
    }
}
