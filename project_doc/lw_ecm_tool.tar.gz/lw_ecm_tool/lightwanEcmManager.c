#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <pthread.h>
#include <sys/socket.h>
#include <event.h>
#include <signal.h>
#include <time.h>
#include <dirent.h>

#include "lightwanEcmManager.h"
#include "lightwanSerialConfig.h"
#include "lightwanSafeStr.h"
#include "lightwanEvent.h"
#include "lightwanDhcp.h"
#include "lightwanUdev.h"
#include "lightwanEcmMsg.h"

/* global variable */ 
static int g_ReplyTimeOutTimes = 0;
static int g_ReplyInvalidTimes = 0;
static struct event_base *g_EventBase = NULL;
static struct event* g_EventWrite = NULL;
static struct event* g_EventRead = NULL;
struct timeval g_ATcmdInterval;
static uint32_t g_ATcmdIndex = 0;
static LW_ATCMD_TYPE g_ATcmdType = LW_ATCMD_TYPE_NONE;
static LW_ATCMD_TYPE g_ATcmdTypeBak = LW_ATCMD_TYPE_NONE;
static int g_ATcmdMsgFd = -1;
static char g_ATcmdMsg[LW_ATCMD_MAX_LEN] = {0};
static size_t g_ATreplyLen = 0;
static char g_ATreply[LW_ATCMD_REPLY_MAX_LEN] = {0};
static BOOL g_DialState = FALSE;
static char g_Apn[LW_APN_LEN] = {0};
static int g_DebugFlag = 0;

/*******************************************************************************
 * MODULE:  global param handler modules
 */
static int _LW_TimeoutReplyCntGet()
{
    return g_ReplyTimeOutTimes;
}
static void _LW_TimeoutReplyCntAdd()
{
    g_ReplyTimeOutTimes = g_ReplyTimeOutTimes + 1;
}
static void _LW_TimeoutReplyCntClear()
{
    g_ReplyTimeOutTimes = 0;
}
static int _LW_TimeoutReplyCntIsMax()
{
    if (g_ReplyTimeOutTimes >= LW_REPLY_TIMEOUT_TIMES_MAX)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
static int _LW_InvalidReplyCntGet()
{
    return g_ReplyInvalidTimes;
}
static void _LW_InvalidReplyCntAdd()
{
    g_ReplyInvalidTimes = g_ReplyInvalidTimes + 1;
}
static void _LW_InvalidReplyCntClear()
{
    g_ReplyInvalidTimes = 0;
}
static int _LW_InvalidReplyCntIsMax()
{
    if (g_ReplyInvalidTimes >= LW_REPLY_INVALID_TIMES_MAX)
    {    
        return 1;
    }
    else
    {    
        return 0;
    }
}
void LW_ATcmdTypeBackup(LW_ATCMD_TYPE Type)
{
    g_ATcmdTypeBak = g_ATcmdType;
    g_ATcmdType = Type;
}
void LW_ATcmdTypeRestore()
{
    g_ATcmdType = g_ATcmdTypeBak;
    g_ATcmdTypeBak = LW_ATCMD_TYPE_NONE;
}
int LW_GetMsgFd()
{
    return g_ATcmdMsgFd;
}
void LW_SetMsgFd(int Fd)
{
    g_ATcmdMsgFd = Fd;
}
void LW_CloseMsgFd()
{
    if (g_ATcmdMsgFd >= 0)
    {
        close(g_ATcmdMsgFd);
    }

    g_ATcmdMsgFd = -1;
}
static void _LW_ATreplyClear()
{
    memset(g_ATreply, 0, sizeof(g_ATreply));
    g_ATreplyLen = 0;
}
static BOOL _LW_IsComplateATreply(const char *ATreply, size_t ATreplyLen)
{
    BOOL isComplate = FALSE;

    if (strstr(ATreply, LW_ATCMD_REPLY_OK) == NULL && strstr(ATreply, LW_ATCMD_REPLY_ERROR) == NULL)
    {
        /* ATreply string is not complate */
        goto CommonReturn;
    }

    if (ATreplyLen >= LW_ATCMD_REPLY_MAX_LEN)
    {
        /* ATreply string is invalid */
        _LW_ATreplyClear();
        goto CommonReturn;
    }

    isComplate = TRUE;

CommonReturn:
    return isComplate;
}
BOOL LW_GetDialState()
{
    return g_DialState;
}
void LW_SetDialState(BOOL DialState)
{
    g_DialState = DialState;
}
void LW_SetDebug()
{
    g_DebugFlag = 1;
}

void LW_CloseDebug()
{
    g_DebugFlag = 0;
}

int LW_GetDebug()
{
    return g_DebugFlag;
}
void LW_SetApn(const char* Path)
{
    strncpy(g_Apn, Path, LW_APN_LEN);
    g_Apn[LW_APN_LEN - 1] = 0;
}

const char * LW_GetApn()
{
    return g_Apn;
}

/*******************************************************************************
 * MODULE:  Dialing process management modules
 */
void LW_ATCallInit()
{
    g_ATcmdType = LW_ATCMD_CALL_INIT;
    g_ATcmdTypeBak = LW_ATCMD_TYPE_NONE;
    g_ATcmdIndex = LW_ATCMD_INDEX_NONE + 1;
    g_ATcmdInterval.tv_sec = LW_ATCMD_WRITE_INTERVAL_DEFAULT;
    g_ATcmdInterval.tv_usec = 0;

    event_add(g_EventRead, NULL);
    event_add(g_EventWrite, &g_ATcmdInterval);
    LW_UdevMonitorEventAdd();
#ifdef LW_ECM_FEATURE_SHOW_REPORT
    LW_ShowInfoEventAdd();
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

    _LW_TimeoutReplyCntClear();
    _LW_InvalidReplyCntClear();

    LW_LOGI("Call init, AT write interval %u seconds\n", LW_ATCMD_WRITE_INTERVAL_DEFAULT);
}
void LW_ATCallUp()
{
    event_del(g_EventWrite);

    g_ATcmdType = LW_ATCMD_CALL_UP;
    g_ATcmdIndex = LW_ATCMD_INDEX_NONE + 1;
    g_ATcmdInterval.tv_sec = LW_ATCMD_WRITE_INTERVAL_DEFAULT;
    g_ATcmdInterval.tv_usec = 0;

    event_add(g_EventWrite, &g_ATcmdInterval);
    LW_LOGI("Call up, AT write interval %u seconds\n", LW_ATCMD_WRITE_INTERVAL_DEFAULT);
}
void LW_ATCallDown()
{
    g_ATcmdType = LW_ATCMD_CALL_DOWN;
    g_ATcmdIndex = LW_ATCMD_INDEX_NONE + 1;
    g_ATcmdInterval.tv_sec = LW_ATCMD_WRITE_INTERVAL_DEFAULT;
    g_ATcmdInterval.tv_usec = 0;

    event_add(g_EventRead, NULL);
    event_add(g_EventWrite, &g_ATcmdInterval);

    LW_LOGI("Call down, AT write interval %u seconds\n", LW_ATCMD_WRITE_INTERVAL_DEFAULT);
}
void LW_ATCallStatus()
{
    event_del(g_EventWrite);

    g_ATcmdType = LW_ATCMD_CALL_STATUS;
    g_ATcmdIndex = LW_ATCMD_INDEX_NONE + 1;

    g_ATcmdInterval.tv_usec = 0;
    if (LW_GetDialState())
    {
        g_ATcmdInterval.tv_sec = LW_ATCMD_WRITE_INTERVAL_CALL_STATUS;
    }
    else
    {
        /* redial faster */
        g_ATcmdInterval.tv_sec = LW_ATCMD_WRITE_INTERVAL_DEFAULT;
    }

    event_add(g_EventWrite, &g_ATcmdInterval);
    LW_LOGI("Call status, AT write interval %u seconds\n", (uint32_t)g_ATcmdInterval.tv_sec);
}
/*******************************************************************************
 * MODULE:  Events handler modules
 */
static void _LW_ReadEvent(int SockCtl, short EventTrigger, void* Arg)
{
    ssize_t ret = 0;
    _LW_ATreplyHandlerFunc LW_ATreplyHandlerFunc = Arg;

    /* 1. clear timeout cnt */
    _LW_TimeoutReplyCntClear();

    /* 2. read AT reply */
    ret = read(SockCtl, g_ATreply + g_ATreplyLen, sizeof(g_ATreply) - g_ATreplyLen);
    if (ret < 0 && errno == EAGAIN)
    {
        _LW_InvalidReplyCntAdd();
        LW_LOGI("Read tty error, try again(errno:%d)\n", errno);
        goto CommonReturn;
    }
    else if (ret < 0 && errno != EAGAIN)
    {
        LW_LOGI("Read tty error, module maybe exception(errno:%d)\n", errno);
        goto CommonReturn;
    }
    else if (ret == 0)
    {
        LW_LOGI("Read tty empty content, module maybe crash(errno:%d)", errno);

        /* keep udev event to handle crash */
        LW_EventFree(TRUE);

        goto CommonReturn;
    }

    /* 3: check complate reply  */
    g_ATreplyLen += (size_t)ret;
    if (!_LW_IsComplateATreply(g_ATreply, g_ATreplyLen))
    {
        goto CommonReturn;
    }

    /* 4: printf log */
    if (g_ATcmdType != LW_ATCMD_CALL_STATUS)
    {
        LW_LOGI(
                "AT read:%s(g_ATcmdType:%d g_ATcmdIndex:%d)\n",
                g_ATreply, 
                g_ATcmdType, 
                g_ATcmdIndex
                );
    }
    else
    {
        LW_LOGD(
                "AT read:%s(g_ATcmdType:%d g_ATcmdIndex:%d)\n",
                g_ATreply, 
                g_ATcmdType, 
                g_ATcmdIndex
                );
    }

    /* 5: check invalid reply */
    if (!LW_ATreplyHandlerFunc(g_ATreply, g_ATcmdType, &g_ATcmdIndex))
    {
        _LW_ATreplyClear();
    
        _LW_InvalidReplyCntAdd();
        LW_LOGI("Invalid reply times:%u\n", _LW_InvalidReplyCntGet());
        
        if (_LW_InvalidReplyCntIsMax() && g_ATcmdType != LW_ATCMD_CALL_INIT)
        { 
            /* reach max cnt */
            LW_LOGI("ATreply invalid reach max cnt:%d, to call status\n", LW_ATCMT_READ_INVALID_REPLY_MAX);
            _LW_InvalidReplyCntClear();

            /* while there are too many invalid replies, call status except for init stage */
            LW_ATCallStatus();
            goto CommonReturn;
        }
    }
    else
    {
        _LW_ATreplyClear();
        _LW_InvalidReplyCntClear();
    }

CommonReturn:
    return;
}

static void _LW_WriteEvent(int SockCtl, short EventTrigger, void* Arg)
{
    ssize_t ret = 0;
    char atCmd[LW_ATCMD_MAX_LEN] = {0};
    int loop = 0;
    _LW_GetATcmdFunc LW_GetATcmdFunc = Arg;

    memset(atCmd, 0, sizeof(atCmd));

    /* 1. check timeout */
    if (_LW_TimeoutReplyCntGet() > 0)
    {
        if (_LW_TimeoutReplyCntIsMax())
        {
            /* timeout */
            LW_LOGI("ATreply timeout reach its maximum: %d, module maybe exception!!!\n", _LW_TimeoutReplyCntGet());
            _LW_TimeoutReplyCntClear();

            /* contunue resend current AT */
        }
        else
        {
            /* waiting reply */
            LW_LOGI("Waiting reply %u seconds (g_ATcmdType:%d g_ATcmdIndex:%d))\n", 
                    _LW_TimeoutReplyCntGet(),
                    g_ATcmdType,
                    g_ATcmdIndex);
            goto CommonReturn;
        }
    }

    /* 2. write AT */
    if (g_ATcmdMsg[0] != '\0')
    {
        LW_SafeStrCopy(atCmd, sizeof(atCmd), g_ATcmdMsg);
        memset(g_ATcmdMsg, 0, sizeof(g_ATcmdMsg));
        LW_ATcmdTypeBackup(LW_ATCMD_CALL_MESSAGES);
    }
    else
    {
        if (LW_GetATcmdFunc(atCmd, sizeof(atCmd), g_ATcmdType, g_ATcmdIndex) < LW_SUCCESS)
        {
            LW_LOGI("Get AT cmd failed, to exit...(g_ATcmdType:%d g_ATcmdIndex:%d)\n", g_ATcmdType, g_ATcmdIndex);
            (void)LW_EventStop();
            goto CommonReturn;
        }
    }

    ret = write(SockCtl, atCmd, strlen(atCmd));
    if (ret < 0 || ret != strlen(atCmd))
    {
        LW_LOGI("Write AT cmd failed(atCmd:%s errno:%d)\n", atCmd, errno);
        goto CommonReturn;
    }

    /* 3. print log */
    if (g_ATcmdType != LW_ATCMD_CALL_STATUS)
    {
        LW_LOGI("AT write:%s(g_ATcmdType:%d g_ATcmdIndex:%d)\n",
                atCmd, 
                g_ATcmdType, 
                g_ATcmdIndex
                );
    }
    else
    {
        LW_LOGD("AT write:%s(g_ATcmdType:%d g_ATcmdIndex:%d)\n",
                atCmd, 
                g_ATcmdType, 
                g_ATcmdIndex
                );
    }

CommonReturn:
    for (loop = 0; loop < (int)g_ATcmdInterval.tv_sec; loop ++)
    {
        _LW_TimeoutReplyCntAdd();
    }
    return;
}

int LW_EventHandleDispatch(int EventType)
{
    int ret = 0;

    if (EventType != LW_ECM_CALL_UP && EventType != LW_ECM_CALL_DOWN)
    {
        ret = -1;
        LW_LOGI("Call type error\n");
        goto CommonReturn;
    }

    if (EventType == LW_ECM_CALL_UP)
    {
        LW_ATCallInit();
    }
    else
    {
        LW_ATCallDown();
    }

    LW_LOGI("Dialing started\n");
    event_base_dispatch(g_EventBase);

    LW_EventFree(FALSE);
    LW_LOGI("Dialing stopped\n");

CommonReturn:
    return ret;
}

LW_ERR_T LW_RedialByUdevMonitor(
    BOOL IsCrash,
    _LW_GetATcmdFunc LW_GetATcmdFunc,
    _LW_ATreplyHandlerFunc LW_ATreplyHandlerFunc,
    _LW_UdevInfoRegistFunc LW_UdevInfoRegistFunc,
    _LW_UdevMonitorFunc LW_UdevMonitorFunc
    )
{
    LW_ERR_T ret = LW_SUCCESS;

    LW_LOGI("wait %us to redialing\n", LW_CRASH_WAIT_INTERVAL);
    sleep(LW_CRASH_WAIT_INTERVAL);

    /* prevent crash continuously */
    LW_EventFree(TRUE);

    if (LW_SerialInitFd() < 0)
    {
        ret = -LW_EIO;
        LW_LOGI("Init Serial fd failed %d\n", ret);
        goto CommonReturn;
    }

    ret = LW_EventInit(TRUE, LW_GetATcmdFunc, LW_ATreplyHandlerFunc, LW_UdevInfoRegistFunc, LW_UdevMonitorFunc);
    if (ret < LW_SUCCESS)
    {
        LW_LOGI("event init failed %d\n", ret);
        goto CommonReturn;
    }

    LW_ATCallInit();

CommonReturn:
    return ret;
}

/*******************************************************************************
 * MODULE:  Events management modules
 */
void LW_EventFree(BOOL IsCrash)
{
    if (g_EventRead)
    {
        event_free(g_EventRead);
        g_EventRead = NULL;
    }

    if (g_EventWrite)
    {
        event_free(g_EventWrite);
        g_EventWrite = NULL;
    }

#ifdef LW_ECM_FEATURE_SHOW_REPORT
    LW_ShowInfoEventFree();
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

    if (!IsCrash)
    {
        LW_UdevMonitorEventFree();

        if (g_EventBase)
        {
            event_base_free(g_EventBase);
            g_EventBase = NULL;
        }
    }

    LW_SerialCloseFd();
}

LW_ERR_T LW_EventInit(
    BOOL IsCrash,
    _LW_GetATcmdFunc LW_GetATcmdFunc,
    _LW_ATreplyHandlerFunc LW_ATreplyHandlerFunc,
    _LW_UdevInfoRegistFunc LW_UdevInfoRegistFunc,
    _LW_UdevMonitorFunc LW_UdevMonitorFunc
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    
    if (!IsCrash)
    {
        g_EventBase = event_base_new();
        if (g_EventBase == NULL)
        {
            ret = -LW_ENOMEM;
            LW_LOGI("new event base failed\n");
            goto CommonReturn;
        }

        ret = LW_UdevMonitorEventInit(g_EventBase, LW_UdevInfoRegistFunc, LW_UdevMonitorFunc);
        if (ret < LW_SUCCESS)
        {
            goto CommonReturn;
        }
    }

    g_EventRead = event_new(g_EventBase, LW_SerialGetFd(), EV_PERSIST | EV_READ, _LW_ReadEvent, LW_ATreplyHandlerFunc);
    if (g_EventRead == NULL)
    {
        ret = -LW_ENOMEM;
        LW_LOGI("new read event failed\n");
        goto CommonReturn;
    }

    g_EventWrite = event_new(g_EventBase, LW_SerialGetFd(), EV_PERSIST, _LW_WriteEvent, LW_GetATcmdFunc);
    if (g_EventWrite == NULL)
    {
        ret = -ENOMEM;
        LW_LOGI("new write event failed\n");
        goto CommonReturn;
    }

#ifdef LW_ECM_FEATURE_SHOW_REPORT
    ret = LW_ShowInfoEventInit(g_EventBase);
    if (ret < LW_SUCCESS)
    {
        goto CommonReturn;
    }
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

CommonReturn:
    if (ret < LW_SUCCESS)
    {
        LW_EventFree(FALSE);
    }
    return ret;
}

void LW_EventStop()
{
    if (g_EventBase)
    {
        event_base_loopexit(g_EventBase, NULL);
    }
}

/*******************************************************************************
 * MODULE:  Client handler modules
 */
void LW_SendToClientSuccess(const char* ATreply)
{
    if (LW_GetMsgFd() < 0)
    {
        goto CommonReturn;
    }

    if (write(LW_GetMsgFd(), ATreply, strlen(ATreply)) == -1)
    {
        LW_LOGI("Send to client failed (errno:%d)\n", errno);
        goto CommonReturn;
    }
    LW_LOGI("%s(ATreply:%s)\n", LW_ECM_SERVER_HANDLER_SUCCESS, ATreply);

CommonReturn:
    LW_CloseMsgFd();
    (void)LW_ATcmdTypeRestore();
    return;
}

static void _LW_SendToClientFailed()
{
    if (LW_GetMsgFd() < 0)
    {
        goto CommonReturn;
    }

    if (write(LW_GetMsgFd(), LW_ECM_SERVER_HANDLER_FAILED, sizeof(LW_ECM_SERVER_HANDLER_FAILED)) == -1)
    {
        LW_LOGI("Send to client failed (errno:%d)\n", errno);
        goto CommonReturn;
    }
    LW_LOGI("%s\n", LW_ECM_SERVER_HANDLER_FAILED);

CommonReturn:
    LW_CloseMsgFd();
    return;
}

static void _LW_SendToClientTimeout()
{
    if (LW_GetMsgFd() < 0)
    {
        goto CommonReturn;
    }

    if (write(LW_GetMsgFd(), LW_ECM_SERVER_HANDLER_TIMEOUT, sizeof(LW_ECM_SERVER_HANDLER_TIMEOUT)) == -1)
    {
        LW_LOGI("Send to client failed (errno:%d)\n", errno);
        goto CommonReturn;
    }
    LW_LOGI("%s\n", LW_ECM_SERVER_HANDLER_TIMEOUT);

CommonReturn:
    LW_CloseMsgFd();
    return;
}

static void _LW_SendToClientDebugSet(BOOL IsOpen)
{
    if (LW_GetMsgFd() < 0)
    {
        goto CommonReturn;
    }

    if (IsOpen)
    {
        LW_SetDebug();
        if (write(LW_GetMsgFd(), LW_ECM_SERVER_OPEN_DEBUG, sizeof(LW_ECM_SERVER_OPEN_DEBUG)) == -1)
        {
            LW_LOGI("Send to client failed (errno:%d)\n", errno);
            goto CommonReturn;
        }
        LW_LOGI("%s\n", LW_ECM_SERVER_OPEN_DEBUG);
    }
    else
    {
        LW_CloseDebug();
        if (write(LW_GetMsgFd(), LW_ECM_SERVER_CLOSE_DEBUG, sizeof(LW_ECM_SERVER_CLOSE_DEBUG)) == -1)
        {
            LW_LOGI("Send to client failed (errno:%d)\n", errno);
            goto CommonReturn;
        }
        LW_LOGI("%s\n", LW_ECM_SERVER_CLOSE_DEBUG);
    }

CommonReturn:
    LW_CloseMsgFd();
    return;
}
static void _LW_SendToClientNotSupport()
{
    if (LW_GetMsgFd() < 0)
    {
        goto CommonReturn;
    }

    if (write(LW_GetMsgFd(), LW_ECM_SERVER_NOT_SUPPORT, sizeof(LW_ECM_SERVER_NOT_SUPPORT)) == -1)
    {
        LW_LOGI("Send to client failed (errno:%d)\n", errno);
        goto CommonReturn;
    }
    LW_LOGI("%s\n", LW_ECM_SERVER_NOT_SUPPORT);

CommonReturn:
    LW_CloseMsgFd();
    return;
}

static void _LW_SendToClientWait()
{
    if (LW_GetMsgFd() < 0)
    {
        goto CommonReturn;
    }

    if (write(LW_GetMsgFd(), LW_ECM_CLIENT_WAIT, sizeof(LW_ECM_CLIENT_WAIT)) == -1)
    {
        LW_LOGI("Send to client failed (errno:%d)\n", errno);
        goto CommonReturn;
    }
    LW_LOGI("%s\n", LW_ECM_CLIENT_WAIT);

CommonReturn:
    LW_CloseMsgFd();
    return;
}

void LW_RecvMsg(int Fd, const char* Buffer)
{
    size_t len = 0;

    LW_SetMsgFd(Fd);

    if (strstr(Buffer, "opendebug"))
    {
        (void)_LW_SendToClientDebugSet(TRUE);
        goto CommonReturn;

    }
    else if (strstr(Buffer, "closedebug"))
    {
        (void)_LW_SendToClientDebugSet(FALSE);
        goto CommonReturn;
    }

    if (g_ATcmdMsg[0] != '\0')
    {
        (void)_LW_SendToClientWait();
        goto CommonReturn;
    }

    len = LW_SNPrintf(g_ATcmdMsg, sizeof(g_ATcmdMsg), "%s\r\n", Buffer);
    if (len >= sizeof(g_ATcmdMsg))
    {
        LW_LOGI("Msg overflow\n");
        (void)_LW_SendToClientFailed();
        goto CommonReturn;
    }

    /* Events handle msg, this thread exit */

CommonReturn:
    return;
}

/*******************************************************************************
 * MODULE:  signal handler modules
 */
static void _LW_SighupHandler()
{
    LW_LOGI("recv sighup, restore by udev\n");
}

static void _LW_SigtermHandler()
{
    LW_LOGI("recv sigterm, exit...\n");
    LW_EventStop();
}

void LW_RegistSignal()
{
    /* crash */
    if (signal(SIGHUP, _LW_SighupHandler) == SIG_ERR)
    {
        LW_LOGI("Occur error.");
    }
    /* kill pid */
    if (signal(SIGTERM, _LW_SigtermHandler) == SIG_ERR)
    {
        LW_LOGI("Occur error.");
    }
}
