#ifndef LW_ECM_MSG_H
#define LW_ECM_MSG_H
#include <event.h>
#include <time.h>
#include "lightwanEcmMsg.h"
#include "lightwanErrno.h"

#define LW_WWAN_MANAGER_CRASH_FILE_NAME_MAX 64
#define LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN 16
#define LW_PARAM_NUM_FORMAT_HEX 16
#define LW_SHOW_INFO_REPORT_INTERVAL 60  /* seconds */
            
#define LW_SHOW_INFO_RSRP_TO_PARAM(_rsrp_)  (uint32_t)(- (_rsrp_))
#define LW_SHOW_INFO_PARAM_TO_RSRP(_param_)  ((int)- (_param_))
#define LW_SHOW_INFO_RSRQ_TO_PARAM(_rsrq_)  (uint32_t)((_rsrq_) * 2 + 255)
#define LW_SHOW_INFO_PARAM_TO_RSRQ(_param_)  (((double)(_param_) - 255) / 2)
#define LW_SHOW_INFO_SINR_TO_PARAM(_sinr_)  (uint32_t)((_sinr_) * 2 + 255)
#define LW_SHOW_INFO_PARAM_TO_SINR(_param_)  (((double)(_param_) - 255) / 2)

/* Fibocom module model */
#define LW_ATCMD_REPLY_FM150_AE                         "FM150-AE"
#define LW_ATCMD_REPLY_FM160_CN                         "FM160-CN"
#define LW_ATCMD_REPLY_FM160_EAU                        "FM160-EAU"
#define LW_ATCMD_REPLY_FM650_CN                         "FM650-CN"
#define LW_ATCMD_REPLY_FM160_JK                         "FM160-JK"
#define LW_ATCMD_REPLY_FM160_NA                         "FM160-NA"
#define LW_ATCMD_REPLY_TM22C                            "tm22g"
#define LW_ATCMD_REPLY_ME3630                           "ME3630"
#define LW_ATCMD_REPLY_GM500                            "GM500"
#define LW_ATCMD_REPLY_EC20                             "EC20"
#define LW_ATCMD_REPLY_EM05                             "EM05"
#define LW_ATCMD_REPLY_EC25                             "EC25"
#define LW_ATCMD_REPLY_EG25                             "EG25"

typedef enum _LW_WWAN_MODULE_MODEL_TYPE
{
    LW_WWAN_MODULE_MODEL_NONE            = 0,      
    LW_WWAN_MODULE_MODEL_TM21C           = 1,      /* tuge esim module TM21C */
    LW_WWAN_MODULE_MODEL_TM22C           = 2,      /* tuge esim module TM22C */
    LW_WWAN_MODULE_MODEL_FM150           = 3,      /* Fibocom Wireless module FM150 */
    LW_WWAN_MODULE_MODEL_FM160_CN        = 4,      /* Fibocom Wireless module FM160-CN  */
    LW_WWAN_MODULE_MODEL_FM160_EAU       = 5,      /* Fibocom Wireless module FM160-EAU */
    LW_WWAN_MODULE_MODEL_FM650_CN        = 6,      /* Fibocom Wireless module FM650-CN */
    LW_WWAN_MODULE_MODEL_FM160_JK        = 7,      /* Fibocom Wireless module FM160-JK */
    LW_WWAN_MODULE_MODEL_FM160_NA        = 8,      /* Fibocom Wireless module FM160-NA */
    LW_WWAN_MODULE_MODEL_ME3630          = 9,      /* Gosuncn Wireless module ME3630 */
    LW_WWAN_MODULE_MODEL_GM500           = 10,     /* Gosuncn Wireless module GM500 */
    LW_WWAN_MODULE_MODEL_EC20            = 11,     /* Quectel Wireless module EC20 */
    LW_WWAN_MODULE_MODEL_EM05            = 12,     /* Quectel Wireless module EM05 */
    LW_WWAN_MODULE_MODEL_EC25            = 13,     /* Quectel Wireless module EC25 */
    LW_WWAN_MODULE_MODEL_EG25            = 14,     /* Quectel Wireless module EG25 */

    LW_WWAN_MODULE_MODEL_MAX
}
LW_WWAN_MODULE_MODEL_TYPE;

typedef enum _LW_WWAN_MANAGER_INFO_TYPE
{
    LW_WWAN_MANAGER_INFO_NONE    = 0,
    LW_WWAN_MANAGER_INFO_CRASH   = 1,
    LW_WWAN_MANAGER_INFO_SHOW    = 2,

    LW_WWAN_MANAGER_INFO_TYPE_MAX
}
LW_WWAN_MANAGER_INFO_TYPE;

typedef enum _LW_WWAN_NETWORK_TYPE
{
    LW_WWAN_NETWORK_NONE         = 0,      
    LW_WWAN_NETWORK_3G           = 1,      /* network type 3g */
    LW_WWAN_NETWORK_LTE          = 2,      /* network type 4g/lte */
    LW_WWAN_NETWORK_NR           = 3,      /* network type 5g/nr */

    LW_WWAN_NETWORK_MAX 
}
LW_WWAN_NETWORK_TYPE;

typedef struct _LW_WWAN_MANAGER_CRASH_INFO
{
    time_t  TimeStamp;          /* second */
    int     CrashFileFlag;      /* 0 means no need to collect, 1 means log collection succee,  2 means fail */
    char    CrashFileName[LW_WWAN_MANAGER_CRASH_FILE_NAME_MAX];     /* crash file name */
}
LW_WWAN_MANAGER_CRASH_INFO;

typedef struct _LW_WWAN_MANAGER_SHOW_INFO
{
    LW_WWAN_NETWORK_TYPE  NetworkType;
    uint32_t       DialState;           /* 0:close, 1: open */
    uint32_t       Lac;                 /* Location Area code */
    uint64_t       Ci;                  /* Cell Identifier */
    uint32_t       Rsrp;                /* Reference Signal Receiving Power */
    uint32_t       Rsrq;                /* Reference Signal Receiving Quality */
    uint32_t       Sinr;                /* Signal to Interference plus Noise Ratio */

    char Mcc[LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN];   /* Mobile Country code */
    char Mnc[LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN];   /* Mobile Network code */
    char Imsi[LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN];  /* International Mobile Subscriber Identity */
}
LW_WWAN_MANAGER_SHOW_INFO;

typedef struct _LW_WWAN_MANAGER_INFO
{
    LW_WWAN_MANAGER_INFO_TYPE       InfoType;
    LW_WWAN_MODULE_MODEL_TYPE       WwanModule;

    LW_WWAN_MANAGER_CRASH_INFO      CrashInfo;
    LW_WWAN_MANAGER_SHOW_INFO       ShowInfo;
}
LW_WWAN_MANAGER_INFO;


LW_ERR_T
LW_SendMsgToAgent(
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    );

LW_WWAN_MANAGER_INFO  * LW_GetShowInfoConf();
LW_WWAN_MANAGER_INFO * LW_GetCrashInfoConf();

struct event * LW_GetShowInfoEvent();

LW_ERR_T
LW_ShowInfoEventInit(
    struct event_base * EventBase
    );

void LW_ShowInfoEventAdd();
void LW_ShowInfoEventFree();

void
LW_ShowInfoEvent(
    int SockCtl,
    short EventTrigger,
    void* Arg
    );


/*******************************************************************************
 * NAME:    LW_GetIntValAfterNthComma
 *
 * DESCRIPTION:
 *      Parse AT cmd reply content to get an integer value, include the first digit or an int value after nth ',';  
 *
 *      Example 1:
 *          AtContent: "1,4,460,11,18A1,1940D11,994,21,105,50,20,66,66,24"
 *          N: 2
 *          output IntVal: 460
 *
 *      Example 2:
 *          AtContent: "\"-125\",\"-12\",-3"
 *          N: 0
 *          output IntVal: -125
 *
 * INPUTS:
 *      AtContent:      [input] at cmd reply content
 *      N:              [input] the nth ','
 *      IntVal:         [output] return val of int type
 *
 * RETURN:
 *      SUCCESS:     LW_SUCCESS
 *      FAILED:      < LW_SUCCESS
 * 
 */
LW_ERR_T
LW_GetIntValAfterNthComma(
    const char *AtContent,
    int N,
    int * IntVal
    );

/*******************************************************************************
 * NAME:    LW_GetStringValAfterNthComma
 *
 * DESCRIPTION:
 *      Parse AT cmd reply content to get an string value after nth ','
 *      eg:
 *      
 *      AtContent: 
 *          "1,4,460,11,18A1,1940D11,994,21,105,50,20,66,66,24"
 *      
 *      while N = 5, return "1940D11"
 * 
 * INPUTS:
 *      AtContent:      [input] at cmd reply content
 *      N:              [input] the nth ','
 *      StringVal:      [output] the string val
 * 
 * RETURN:
 *      Returns the size of string value, or 0 when not found
 * 
 */
size_t
LW_GetStringValAfterNthComma(
    const char *AtContent,
    int N,
    char * StringVal
    );
#endif /* LW_ECM_MSG_H */