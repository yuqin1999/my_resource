#ifndef LWSERIALCONFIG
#define LWSERIALCONFIG
#include <syslog.h>

//#define DEBUG_PRINT

#define LW_ECM_TOOL_VERSION         "v1.4.4_debug"            /* update _LW_Version() func*/
#define LW_PROJECT_ISSUE_ID         "#52871"

void LW_CloseDebug();
int LW_GetDebug();

#ifdef DEBUG_PRINT

#define LW_LOGI( fmt, args... )     \
do { \
    fprintf(stderr, "[%s %s-%d]"fmt, LW_ECM_TOOL_VERSION, __FUNCTION__, __LINE__, ##args);  \
    fflush(stderr);  \
}while(0)

#else /* DEBUG_PRINT */

#define LW_LOGI( fmt, args... )     \
do { \
    syslog(LOG_WARNING, "<INFO>[%s %s-%d]"fmt, LW_ECM_TOOL_VERSION, __FUNCTION__, __LINE__, ##args);  \
}while(0)

#define LW_LOGD( fmt, args... )     \
if (LW_GetDebug())      \
{           \
    do {        \
        syslog(LOG_WARNING, "<DEBUG>[%s %s-%d]"fmt, LW_ECM_TOOL_VERSION, __FUNCTION__, __LINE__, ##args);  \
    }while(0);   \
}
#endif /* DEBUG_PRINT */

void LW_SetSerialPath(const char* Path);

int LW_SerialGetFd();

int LW_SerialInitFd();

void LW_SerialFdFlush();

void LW_SerialCloseFd();

void LW_LOGInit();

void LW_LOGExit();

void LW_TimeoutReplyCntAdd();

void LW_TimeoutReplyCntClear();

int LW_TimeoutReplyCntIsMax();

int LW_TimeoutReplyGetCount();

void LW_AddResetRetryTimes();

void LW_ClearResetRetryTimes();

int LW_IsResetRetryTimesMax();

void LW_InvalidReplyCntAdd();
void LW_InvalidReplyCntClear();
int LW_InvalidReplyCntIsMax();
int LW_InvalidReplyCntGet();

#endif
