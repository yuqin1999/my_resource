#ifndef LW_WWAN_DHCP
#define LW_WWAN_DHCP
void LW_WWANDhcpup();
void LW_WWANDhcpdown();
int LW_LockFile();
void LW_ReleaseFile();

#endif
