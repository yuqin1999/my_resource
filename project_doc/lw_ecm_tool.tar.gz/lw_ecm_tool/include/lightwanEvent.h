#ifndef LWEVENT
#define LWEVENT
#include "lightwanPlatformDefs.h"

#define LW_ECM_SERVER_SOCKET_PATH                   "\0ECM_DEMO.sock"
#define LW_FILE_NAME_MAX_LEN                        (128)
#define LW_ATCMD_MAX_LEN                            (128)
#define LW_ATCMD_REPLY_MAX_LEN                      (1024)
#define LW_ATCMD_WRITE_INTERVAL_DEFAULT             (1)
#define LW_ATCMD_WRITE_INTERVAL_CALL_STATUS         (5)
#define LW_ATCMT_READ_INVALID_REPLY_MAX             (10)
#define LW_CRASH_WAIT_INTERVAL                      (10)

enum LW_ECM_CALL_TYPE
{
    LW_ECM_CALL_NONE,
    LW_ECM_CALL_UP,
    LW_ECM_CALL_DOWN,
};

int LW_DialStarting(int DialType);

typedef struct _LW_DIAL_DRIVER 
{
	const char *Name;

    const char* IDProduct;

    const char* IDVendor;

    const char* TtyUSBPath;

	int (*Init) ();

	void (*Exit) ();

	int (*Processing) (int DialType);
} 
LW_DIAL_DRIVER;

LW_DIAL_DRIVER* LW_GetDriverGM500();

LW_DIAL_DRIVER* LW_GetDriverME3630();

LW_DIAL_DRIVER* LW_GetDriverFM150();

LW_DIAL_DRIVER* LW_GetDriverMe909();

LW_DIAL_DRIVER* LW_GetDriverEC20();

LW_DIAL_DRIVER* LW_GetDriverTM22C();

LW_DIAL_DRIVER* LW_GetDriverFM650();
#endif
