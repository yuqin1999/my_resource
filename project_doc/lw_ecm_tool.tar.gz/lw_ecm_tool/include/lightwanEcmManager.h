#ifndef LW_ECM_MANAGER
#define LW_ECM_MANAGER
#include "lightwanUdev.h"

#define LW_ECM_SERVER_HANDLER_SUCCESS               "Server handler message success\n"
#define LW_ECM_SERVER_HANDLER_FAILED                "Server handler message failed\n"
#define LW_ECM_SERVER_HANDLER_TIMEOUT               "Server handler message timeout\n"
#define LW_ECM_SERVER_OPEN_DEBUG                    "Server open debug success\n"
#define LW_ECM_SERVER_CLOSE_DEBUG                   "Server close debug success\n"
#define LW_ECM_SERVER_NOT_SUPPORT                   "Server not support"
#define LW_ECM_CLIENT_WAIT                          "Client send too fast, please waiting\n"
#define LW_ATCMD_REPLY_OK                           "OK"
#define LW_ATCMD_REPLY_ERROR                        "ERROR"
#define LW_ATCMD_INDEX_NONE                             (0)
#define LW_APN_LEN                                      (32)
/* some times the module is silent or broken, we have to deal with it. when reply-timeout/reply-invalid times reach its maximum, we need to exit and log this sitituation */
#define LW_REPLY_TIMEOUT_TIMES_MAX                      (10)
#define LW_REPLY_INVALID_TIMES_MAX                      (10)

typedef enum _LW_ATCMD_TYPE
{
    LW_ATCMD_TYPE_NONE,

    LW_ATCMD_CALL_INIT,
    LW_ATCMD_CALL_UP,
    LW_ATCMD_CALL_DOWN,
    LW_ATCMD_CALL_STATUS,
    LW_ATCMD_CALL_MESSAGES,

    LW_ATCMD_TYPE_MAX,
}
LW_ATCMD_TYPE;

typedef BOOL (* _LW_ATreplyHandlerFunc) (const char* ATreply, LW_ATCMD_TYPE ATcmdType, uint32_t *ATcmdIndex);
typedef LW_ERR_T (* _LW_GetATcmdFunc) (char* ATcmd, size_t ATcmdLen, LW_ATCMD_TYPE ATcmdType, uint32_t ATcmdIndex);

/*******************************************************************************
 * MODULE:  global param handler modules
 */
void LW_SetApn(const char* Path);
const char * LW_GetApn();
void LW_SetDebug();
BOOL LW_GetDialState();
void LW_SetDialState(BOOL DialState);
int LW_GetMsgFd();
void LW_SetMsgFd(int Fd);
void LW_CloseMsgFd();
void LW_ATcmdTypeBackup(LW_ATCMD_TYPE Type);
/*******************************************************************************
 * MODULE:  Dialing process management modules
 */
void LW_ATCallInit();
void LW_ATCallUp();
void LW_ATCallDown();
void LW_ATCallStatus();
/*******************************************************************************
 * MODULE:  Events management modules
 */
void LW_EventStop();
void LW_EventFree(BOOL IsCrash);
LW_ERR_T LW_EventInit(
    BOOL IsCrash,
    _LW_GetATcmdFunc LW_GetATcmdFunc,
    _LW_ATreplyHandlerFunc LW_ATreplyHandlerFunc,
    _LW_UdevInfoRegistFunc LW_UdevInfoRegistFunc,
    _LW_UdevMonitorFunc LW_UdevMonitorFunc
    );
/*******************************************************************************
 * MODULE:  Events handler modules
 */
int LW_EventHandleDispatch(int EventType);
LW_ERR_T LW_RedialByUdevMonitor(
    BOOL IsCrash,
    _LW_GetATcmdFunc LW_GetATcmdFunc,
    _LW_ATreplyHandlerFunc LW_ATreplyHandlerFunc,
    _LW_UdevInfoRegistFunc LW_UdevInfoRegistFunc,
    _LW_UdevMonitorFunc LW_UdevMonitorFunc
    );
/*******************************************************************************
 * MODULE:  Client handler modules
 */
void LW_RecvMsg(int Fd, const char* ATcmdMsg);
void LW_SendToClientSuccess(const char* ATreply);
/*******************************************************************************
 * MODULE:  signal handler modules
 */
void LW_RegistSignal();


#endif /* LW_ECM_MANAGER */