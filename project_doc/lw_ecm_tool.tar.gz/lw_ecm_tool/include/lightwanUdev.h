#ifndef LW_UDEV_H
#define LW_UDEV_H

#include <event.h>
#include "lightwanErrno.h"
#include "lightwanSerialConfig.h"
#include "lightwanPlatformDefs.h"

#define LW_VID_PID_LENGTH_MAX  16
#define LW_UDEV_DEVICE_ACTION_STR_MAX  16

enum _LW_Monitor_Event_Source_Type
{
    LW_Monitor_Event_Source_Udev,
    LW_Monitor_Event_Source_Kernel
} 
LW_Monitor_Event_Source_Type;

typedef enum _LW_MODULE_MODEL_MODE
{
    LW_MODULE_MODEL_MODE_NONE,

    LW_MODULE_MODEL_MODE_NORMAL,
    LW_MODULE_MODEL_MODE_DUMP,

    LW_MODULE_MODEL_MODE_MAX,
}
LW_MODULE_MODEL_MODE;

typedef struct _LW_UDEV_MONITOR_INFO
{
    LW_MODULE_MODEL_MODE Mode;
    char DeviceAction[LW_UDEV_DEVICE_ACTION_STR_MAX];
    char IdVendor[LW_VID_PID_LENGTH_MAX];
    char IdProduct[LW_VID_PID_LENGTH_MAX];
}
LW_UDEV_MONITOR_INFO;

typedef struct _LW_UDEV_INFO
{
    int MonitorCnt;
    LW_UDEV_MONITOR_INFO *MonitorInfo;
}
LW_UDEV_INFO;

typedef LW_ERR_T (* _LW_UdevMonitorFunc) (LW_MODULE_MODEL_MODE);
typedef void (* _LW_UdevInfoRegistFunc) (LW_UDEV_INFO *);

int LW_UdevMonitorInit(int EventSrc);
int LW_UdevMonitorGetFd(void);
void LW_UdevMonitorCloseFd(void);
void LW_UdevMonitorRelease(void);
BOOL LW_CheckIntfLoaded(void);

unsigned long long
LW_GetPathDiskFree(
    const char * DiskPath
    );

/*******************************************************************************
 * NAME:    LW_UdevMonitorTarget
 *
 * DESCRIPTION:
 *      Compare udev with device action, pid and vid.
 *      action bind event happened back in Linux 4.12, issue #38172.
 *
 * INPUTS:
 *      UdevInfo:       [in] action, pid and vid from udev
 *      Mode:           [out] Module model mode
 * 
 * RETURN:
 *      LW_SUCCESS:         Monitor a target
 *      -LW_EINVAL:         invalid target
 *      Others:             occur exception
 */
LW_ERR_T LW_UdevMonitorTarget(LW_UDEV_INFO *UdevInfo,LW_MODULE_MODEL_MODE *Mode);

int
LW_RemovemFileOrDir(
    const char *Path
    );

LW_ERR_T 
LW_UdevMonitorEventInit(
    struct event_base * EventBase,
    _LW_UdevInfoRegistFunc LW_UdevInfoRegistFunc,
    _LW_UdevMonitorFunc LW_UdevMonitorFunc
    );

void LW_UdevMonitorEventFree();
void LW_UdevMonitorEventAdd();

#endif /* LW_UDEV_H */
