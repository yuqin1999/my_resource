#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <pthread.h>
#include <sys/socket.h>
#include <event.h>
#include <signal.h>
#include <sys/file.h>
#include "lightwanSerialConfig.h"

#define FILE_NAME "/tmp/ECM_DEMO_Lock"
int g_lock_fd = -1;

#ifdef LW_OPENWRT_UDHCPC

void LW_WWANDhcpup()
{
    int ret = 0;
    ret = system("kill -9 $(ps | grep \"udhcpc -i ppp15 -s /etc/appex/apx-udhcpc.script\" | grep -v grep | awk '{print $1}')");
    if (ret != 0)
        LW_LOGI("[info] system kill -9 udhcpc error:%d %d %s", ret, errno, strerror(errno));
    
    ret = system("udhcpc -i ppp15 -s /etc/appex/apx-udhcpc.script -S &");
    if (ret != 0)
        LW_LOGI("[info] system udhcpc error:%d %d %s", ret, errno, strerror(errno));
}
void LW_WWANDhcpdown()
{
    int ret = 0;
    ret = system("kill -9 $(ps | grep \"udhcpc -i ppp15 -s /etc/appex/apx-udhcpc.script\" | grep -v grep | awk '{print $1}')");
    if (ret != 0)
        LW_LOGI("[info] system kill -9 udhcpc error:%d %d %s", ret, errno, strerror(errno));
}
#else
void LW_WWANDhcpup()
{
    int ret = 0;
    ret = system("dhclient ppp15 -pf /var/run/dhclient-wwan.pid -lf /var/lib/dhclient/ppp15.leases -x");
    if (ret != 0)
        LW_LOGI("[info] system dhcliet -x error:%d %d %s", ret, errno, strerror(errno));
    
    ret = system("dhclient ppp15 -pf /var/run/dhclient-wwan.pid -lf /var/lib/dhclient/ppp15.leases -nw");
    if (ret != 0)
        LW_LOGI("[info] system dhclient -nw error:%d %d %s", ret, errno, strerror(errno));
}
void LW_WWANDhcpdown()
{
    int ret = 0;
    ret = system("dhclient ppp15 -pf /var/run/dhclient-wwan.pid -lf /var/lib/dhclient/ppp15.leases -x");
    if (ret != 0)
        LW_LOGI("[info] system dhcliet -x error:%d %d %s", ret, errno, strerror(errno));
}
#endif

int _Lockfile (const int Fd)
{       
    struct flock filelock;
    struct stat buf;

    memset(&filelock, 0, sizeof(filelock));
    memset(&buf, 0, sizeof(buf));

    fstat(Fd,&buf);

    filelock.l_type = F_WRLCK;      
    filelock.l_start = 0;    
    filelock.l_whence = SEEK_SET;   
    filelock.l_len = buf.st_size;        
        
    return fcntl(Fd, F_SETLK, &filelock);
}
int _releasefile(const int Fd)
{       
    struct flock filelock;
    struct stat buf;

    memset(&filelock, 0, sizeof(filelock));
    memset(&buf, 0, sizeof(buf));

    fstat(Fd, &buf);

    filelock.l_type = F_UNLCK;      
    filelock.l_start = 0;    
    filelock.l_whence = SEEK_SET;   
    filelock.l_len = buf.st_size;        
        
    return fcntl(Fd, F_SETLK, &filelock);
}
int LW_LockFile()
{
    int ret = -1;

    struct stat buf = {0};
    struct flock lock = {0};

    g_lock_fd = open(FILE_NAME, O_CREAT | O_RDWR, 0666);
    if (g_lock_fd == -1)
    {
        LW_LOGI("Open file lock error, %d, %s\n", errno, strerror(errno));
        goto CommonReturn;
    }
    fstat(g_lock_fd,&buf);
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = 0;
    lock.l_len = buf.st_size;

    LW_LOGI("Get File lock...\n");
    if (fcntl(g_lock_fd,F_SETLK,&lock))
    {
        sleep(10);
	if (fcntl(g_lock_fd,F_SETLK,&lock))
        {
            LW_LOGI("GetLock error, %d, %s\n", errno, strerror(errno));
            ret = -1;
            goto CommonReturn;
        }
    }
    LW_LOGI("Get lock Success\n");
    ret = 0;

CommonReturn:
    if (ret < 0 && g_lock_fd >=0)
    {
        close(g_lock_fd);
    }
    return ret;
}



void LW_ReleaseFile()
{
    if (g_lock_fd >=0)
    {
        (void)_releasefile(g_lock_fd);
        close(g_lock_fd);
    }
    return;
}
