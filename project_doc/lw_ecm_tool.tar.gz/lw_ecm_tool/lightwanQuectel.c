#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <pthread.h>
#include <sys/socket.h>
#include <event.h>
#include <signal.h>
#include <time.h>
#include <dirent.h>

#include "lightwanSafeStr.h"
#include "lightwanSerialConfig.h"
#include "lightwanEvent.h"
#include "lightwanDhcp.h"
#include "lightwanEcmMsg.h"
#include "lightwanUdev.h"
#include "lightwanErrno.h"
#include "lightwanEcmManager.h"

/* EC20 pvid */
#define LW_EC20_ID_VENDOR                           "2c7c"
#define LW_EC20_ID_PRODUCT                          "0125"

/* AT cmd */
#define LW_ATCMD_ATE0                               "ATE0\r\n"
#define LW_ATCMD_ATI                                "ATI\r\n"
#define LW_ATCMD_CPIN                               "AT+CPIN?\r\n"
#define LW_ATCMD_CGDCONT_PREFIX                     "AT+CGDCONT=1,\"IP\",\""
#define LW_ATCMD_CGDCONT_SUFFIX                     "\"\r\n"
#define LW_ATCMD_CGDCONT_STATUS                     "AT+CGDCONT?\r\n"
#define LW_ATCMD_COPS_FORMAT_ADAPT                  "AT+COPS=3,2\r\n"
#define LW_ATCMD_COPS                               "AT+COPS?\r\n"
#define LW_ATCMD_QCRMCALL_DOWN                      "AT$QCRMCALL=0,1,1\r\n"
#define LW_ATCMD_QCRMCALL_UP                        "AT$QCRMCALL=1,1,1\r\n"
#define LW_ATCMD_QCRMCALL_STATUS                    "AT$QCRMCALL?\r\n"
#define LW_ATCMD_QENG_SERVING_CELL                  "AT+QENG=\"servingcell\"\r\n"
#define LW_ATCMD_CIMI                               "AT+CIMI\r\n"
#define LW_ATCMD_CGREG_STATUS                       "AT+CGREG?\r\n"

/* AT cmd reply */
#define LW_ATCMD_REPLY_OK                           "OK"
#define LW_ATCMD_REPLY_READY                        "READY"
#define LW_ATCMD_REPLY_QCRMCALL_UP                  "1,V4"
#define LW_ATCMD_REPLY_CGREG_STATUS                 "0,1"

typedef enum _LW_ATCMD_CALL_INIT_CMD
{
    LW_ATCMD_CALL_INIT_NONE,

    LW_ATCMD_CALL_INIT_ATE0,
    LW_ATCMD_CALL_INIT_CGDCONT,

    LW_ATCMD_CALL_INIT_MAX,
} LW_ATCMD_CALL_INIT_CMD;

typedef enum _LW_ATCMD_CALL_UP_CMD
{
    LW_ATCMD_CALL_UP_NONE,

    LW_ATCMD_CALL_UP_ATE0,
    LW_ATCMD_CALL_UP_ATI,
    LW_ATCMD_CALL_UP_CPIN,
    LW_ATCMD_CALL_UP_CGDCONT_STATUS,
    LW_ATCMD_CALL_UP_CGREG_STATUS,
    LW_ATCMD_CALL_UP_COPS_FORMAT_ADAPT,
    LW_ATCMD_CALL_UP_COPS,
    LW_ATCMD_CALL_UP_QCRMCALL_DOWN,
    LW_ATCMD_CALL_UP_QCRMCALL_UP,

    LW_ATCMD_CALL_UP_MAX,
} LW_ATCMD_CALL_UP_CMD;

typedef enum _LW_ATCMD_CALL_DOWN_CMD
{
    LW_ATCMD_CALL_DOWN_NONE,

    LW_ATCMD_CALL_DOWN_QCRMCALL_DOWN,
    LW_ATCMD_CALL_DOWN_QCRMCALL_STATUS,

    LW_ATCMD_CALL_DOWN_MAX,
} LW_ATCMD_CALL_DOWN_CMD;

typedef enum _LW_ATCMD_CALL_STATUS_CMD
{
    LW_ATCMD_CALL_STATUS_NONE,

    LW_ATCMD_CALL_STATUS_CGREG,
    LW_ATCMD_CALL_STATUS_COPS,
    LW_ATCMD_CALL_STATUS_ATI,
    LW_ATCMD_CALL_STATUS_CIMI,
    LW_ATCMD_CALL_STATUS_QENG_SERVING_CELL,
    LW_ATCMD_CALL_STATUS_QCRMCALL_STATUS,

    LW_ATCMD_CALL_STATUS_MAX,
} LW_ATCMD_CALL_STATUS_CMD;

#ifdef LW_ECM_FEATURE_SHOW_REPORT

/* index starts from 0 */
#define LW_ATCMD_QENG_SERVING_CELL_LTE                          "LTE"
#define LW_ATCMD_QENG_SERVING_CELL_CI_INDEX                     6
#define LW_ATCMD_QENG_SERVING_CELL_TAC_INDEX                    12       /* lac param */
#define LW_ATCMD_QENG_SERVING_CELL_RSRP_INDEX                   13
#define LW_ATCMD_QENG_SERVING_CELL_RSRQ_INDEX                   14
#define LW_ATCMD_QENG_SERVING_CELL_SINR_INDEX                   16
#define LW_ATCMD_CIMI_IMSI_INDEX                                0

#define LW_ATCMD_COPS_MCC_MNC_INDEX                             2
#define LW_ATCMD_COPS_MCC_INDEX                                 1
#define LW_ATCMD_COPS_MNC_INDEX                                 4
#define LW_ATCMD_COPS_MCC_OR_MNC_MAX_LEN                        4  /* include null-terminator */
/*******************************************************************************
 * NAME:  _LW_ShowInfoParseCimi
 *
 * DESCRIPTION:
 *      Parse reply content to get param, eg:
 * 
 *      reply:  
 *          
 *      460015471018438
 *          
 *      
 *      OK
 * 
 *      result:
 *          imsi=460015471018438
 *
 * INPUTS:
 *      ReplyContent:               reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void
_LW_ShowInfoParseCimi(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    size_t imsiLen = 0;

    if (ReplyContent == NULL)
    {
        LW_LOGI("cimi reply invalid\n");
        goto CommonReturn;
    }

    imsiLen = LW_GetStringValAfterNthComma(ReplyContent, LW_ATCMD_CIMI_IMSI_INDEX, WwanManagerInfo->ShowInfo.Imsi);
    if (imsiLen == 0)
    {
        LW_LOGI("get imsi failed\n");
    }

CommonReturn:
    return;
}

/*******************************************************************************
 * NAME:  _LW_ShowInfoParseAti
 *
 * DESCRIPTION:
 *      Parse reply content to get param, eg:
 * 
 *      reply:
 *          Quectel
 *          EC20F
 *          Revision: EC20CEHDLGR06A09M1G
 *          
 *          OK
 * 
 *      result:
 *          moduleModel=EC20
 *
 * INPUTS:
 *      ReplyContent:               reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void
_LW_ShowInfoParseAti(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    if (strstr(ReplyContent, LW_ATCMD_REPLY_EC20))
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_EC20;
    }
    else if (strstr(ReplyContent, LW_ATCMD_REPLY_EM05))
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_EM05;
    }
    else if (strstr(ReplyContent, LW_ATCMD_REPLY_EC25))
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_EC25;
    }
    else if (strstr(ReplyContent, LW_ATCMD_REPLY_EG25))
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_EG25;
    }
    else
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_NONE;
        LW_LOGI("ati reply invalid\n");
        goto CommonReturn;
    }

CommonReturn:
    return;
}

/*******************************************************************************
 * NAME:  _LW_ShowInfoParseCops
 *
 * DESCRIPTION:
 *      Parse reply content to get param, eg:
 *      
 *      reply:
 *
 *          +COPS: 0,2,"46011",7
 *
 *          OK
 * 
 *      result:
 *          mcc=460
 *          mnc=11
 * 
 * INPUTS:
 *      ReplyContent:               reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void
_LW_ShowInfoParseCops(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    size_t len = 0;
    char *pStart = NULL;
    char mccmnc[LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN] = {0};

    pStart = strstr(ReplyContent, "+COPS");
    if (pStart == NULL)
    {
        LW_LOGI("cops reply invalid\n");
        goto CommonReturn;
    }

    /* such as "46001" or "316010" */
    len = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_COPS_MCC_MNC_INDEX, mccmnc);
    if (len == 0)
    {
        LW_LOGI("get mcc mnc failed\n");
        goto CommonReturn;
    }

    LW_SafeStrCopy(WwanManagerInfo->ShowInfo.Mcc, LW_ATCMD_COPS_MCC_OR_MNC_MAX_LEN, &mccmnc[LW_ATCMD_COPS_MCC_INDEX]);
    LW_SafeStrCopy(WwanManagerInfo->ShowInfo.Mnc, LW_ATCMD_COPS_MCC_OR_MNC_MAX_LEN, &mccmnc[LW_ATCMD_COPS_MNC_INDEX]);

    if (WwanManagerInfo->ShowInfo.Mnc[2] == '\"')
    {
        WwanManagerInfo->ShowInfo.Mnc[2] = 0;
    }

CommonReturn:
    return;
}

/*******************************************************************************
 * NAME:  _LW_ShowInfoParseQengServingCell
 *
 * DESCRIPTION:
 *      Parse reply content to get param, eg:
 * 
 *      reply:
 *          
 *      +QENG: "servingcell","NOCONN","LTE","FDD",460,01,E48ED01,321,100,1,5,5,1016,-92,-8,-64,15,35
 *      
 *      OK
 * 
 *      result:
 *          ci = E48ED01
 *          tac = 1016
 *          rsrp = -92
 *          rsrq = -8
 *          sinr = 15
 *
 * INPUTS:
 *      ReplyContent:               reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void
_LW_ShowInfoParseQengServingCell(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    size_t ciLen = 0;
    size_t lacLen = 0;
    char ci[LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN] = {0};
    char lac[LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN] = {0};
    int rsrp = 0;
    int rsrq = 0;
    int sinr = 0;
    char *pStart = NULL;

    pStart = strstr(ReplyContent, "+QENG");
    if (pStart == NULL)
    {
        LW_LOGI("zsrvrsp reply invalid\n");
        goto CommonReturn;
    }

    if (strstr(ReplyContent, LW_ATCMD_QENG_SERVING_CELL_LTE) == NULL)
    {
        LW_LOGI("Service cell invalid\n");
        goto CommonReturn;
    }
    
    LW_LOGI("LTE service cell\n");
    WwanManagerInfo->ShowInfo.NetworkType = LW_WWAN_NETWORK_LTE;

    lacLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_QENG_SERVING_CELL_TAC_INDEX, lac);
    if (lacLen == 0)
    {
        LW_LOGI("get lac failed\n");
    }
    else
    {
        WwanManagerInfo->ShowInfo.Lac = strtol(lac , NULL, LW_PARAM_NUM_FORMAT_HEX);
    }

    ciLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_QENG_SERVING_CELL_CI_INDEX, ci);
    if (ciLen == 0)
    {
        LW_LOGI("get ci failed\n");
    }
    else
    {
        WwanManagerInfo->ShowInfo.Ci = (uint64_t)strtoll(ci , NULL, LW_PARAM_NUM_FORMAT_HEX);
    }

    if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_QENG_SERVING_CELL_RSRP_INDEX, &rsrp) < LW_SUCCESS)
    {
        LW_LOGI("get rsrp failed\n");
    }
    else
    {
        if (rsrp < 0)
        {
            LW_LOGD("get rsrp %ddBm\n", rsrp);
            WwanManagerInfo->ShowInfo.Rsrp = LW_SHOW_INFO_RSRP_TO_PARAM(rsrp);
        }
    }

    if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_QENG_SERVING_CELL_RSRQ_INDEX, &rsrq) < LW_SUCCESS)
    {
        LW_LOGI("get rsrq failed\n");
    }
    else
    {
        if (rsrq < 0)
        {
            LW_LOGD("get rsrq %ddB\n", rsrq);
            WwanManagerInfo->ShowInfo.Rsrq = LW_SHOW_INFO_RSRQ_TO_PARAM(rsrq);
        }
    }

    if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_QENG_SERVING_CELL_SINR_INDEX, &sinr) < LW_SUCCESS)
    {
        LW_LOGI("get sinr failed\n");
    }
    else
    {
        if (sinr >= -20 && sinr <= 30)
        {
            LW_LOGD("get sinr %ddB\n", sinr);
            WwanManagerInfo->ShowInfo.Sinr = LW_SHOW_INFO_SINR_TO_PARAM(sinr);
        }
    }

CommonReturn:
    return;
}

#endif /* LW_ECM_FEATURE_SHOW_REPORT */

static LW_ERR_T
_LW_GetCallInitAtCmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_UP_CMD AtCmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;

    switch (AtCmdIndex)
    {
        case LW_ATCMD_CALL_INIT_ATE0:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ATE0);
            break;
        }
        case LW_ATCMD_CALL_INIT_CGDCONT:
        {
            LW_LOGI("Set Apn %s\n", LW_GetApn());
            len = LW_SNPrintf(ATcmd, ATcmdLen, "%s%s%s", LW_ATCMD_CGDCONT_PREFIX, LW_GetApn(), LW_ATCMD_CGDCONT_SUFFIX);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GetCallUpAtCmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_UP_CMD AtCmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;

    switch (AtCmdIndex)
    {
        case LW_ATCMD_CALL_UP_ATE0:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ATE0);
            break;
        }
        case LW_ATCMD_CALL_UP_ATI:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ATI);
            break;
        }
        case LW_ATCMD_CALL_UP_CPIN:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CPIN);
            break;
        }
        case LW_ATCMD_CALL_UP_CGDCONT_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CGDCONT_STATUS);
            break;
        }
        case LW_ATCMD_CALL_UP_CGREG_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CGREG_STATUS);
            break;
        }
        case LW_ATCMD_CALL_UP_COPS_FORMAT_ADAPT:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_COPS_FORMAT_ADAPT);
            break;
        }
        case LW_ATCMD_CALL_UP_COPS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_COPS);
            break;
        }
        case LW_ATCMD_CALL_UP_QCRMCALL_DOWN:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_QCRMCALL_DOWN);
            break;
        }
        case LW_ATCMD_CALL_UP_QCRMCALL_UP:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_QCRMCALL_UP);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GetCallDownAtCmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_DOWN_CMD AtCmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;

    switch (AtCmdIndex)
    {
        case LW_ATCMD_CALL_DOWN_QCRMCALL_DOWN:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_QCRMCALL_DOWN);
            break;
        }
        case LW_ATCMD_CALL_DOWN_QCRMCALL_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_QCRMCALL_STATUS);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GetCallStatusAtCmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_STATUS_CMD AtCmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;
    switch (AtCmdIndex)
    {
        case LW_ATCMD_CALL_STATUS_CGREG:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CGREG_STATUS);
            break;
        }
        case LW_ATCMD_CALL_STATUS_COPS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_COPS);
            break;
        }
        case LW_ATCMD_CALL_STATUS_ATI:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ATI);
            break;
        }
        case LW_ATCMD_CALL_STATUS_CIMI:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CIMI);
            break;
        }
        case LW_ATCMD_CALL_STATUS_QENG_SERVING_CELL:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_QENG_SERVING_CELL);
            break;
        }
        case LW_ATCMD_CALL_STATUS_QCRMCALL_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_QCRMCALL_STATUS);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }
    
CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_QueGetATcmdFunc(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_TYPE ATcmdType,
    uint32_t ATcmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;

    switch (ATcmdType)
    {
        case LW_ATCMD_CALL_INIT:
        {
            ret = _LW_GetCallInitAtCmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        case LW_ATCMD_CALL_UP:
        {
            ret = _LW_GetCallUpAtCmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        case LW_ATCMD_CALL_DOWN:
        {
            ret = _LW_GetCallDownAtCmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        case LW_ATCMD_CALL_STATUS:
        {
            ret = _LW_GetCallStatusAtCmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

CommonReturn:
    return ret;
}

static BOOL
_LW_IsValidReply(
    const char * ATreply,
    LW_ATCMD_TYPE ATcmdType, 
    uint32_t *ATcmdIndex
    )
{
    BOOL isValidReply = FALSE;

    if (strstr(ATreply, LW_ATCMD_REPLY_OK))
    {
        isValidReply = TRUE;
    }

    switch (ATcmdType)
    {
        case LW_ATCMD_CALL_UP:
        {
            if (*ATcmdIndex == LW_ATCMD_CALL_UP_CPIN)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_READY) == NULL)
                {
                    isValidReply = FALSE;
                }
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_UP_CGREG_STATUS)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_CGREG_STATUS) == NULL)
                {
                    isValidReply = FALSE;
                }
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_UP_QCRMCALL_DOWN)
            {
                /* ignore reply */
                LW_LOGI("Ignore AT zecmcall down reply\n");
                isValidReply = TRUE;
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_UP_QCRMCALL_UP)
            {
                /* ignore reply */
                LW_LOGI("Ignore AT zecmcall up reply\n");
                isValidReply = TRUE;
            }

            break;
        }
        case LW_ATCMD_CALL_DOWN:
        {
            /* ignore reply */
            LW_LOGI("Ignore call down reply\n");
            isValidReply = TRUE;
            break;
        }
        case LW_ATCMD_CALL_STATUS:
        {
            /* ignore reply */
            isValidReply = TRUE;
            break;
        }
        case LW_ATCMD_CALL_MESSAGES:
        {
            /* ignore reply */
            isValidReply = TRUE;
            break;
        }
        default:
        {
            break;
        }
    }

    return isValidReply;
}

static BOOL
_LW_QueATreplyHandlerFunc(
    const char * ATreply,
    LW_ATCMD_TYPE ATcmdType,
    uint32_t *ATcmdIndex
    )
{
    BOOL isHandled = FALSE;

    if (!_LW_IsValidReply(ATreply, ATcmdType, ATcmdIndex))
    {
        goto CommonReturn;
    }

    isHandled = TRUE;

    switch (ATcmdType)
    {
        case LW_ATCMD_CALL_INIT:
        {
            *ATcmdIndex = *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_INIT_MAX)
            {
                LW_LOGI("Initializing successful! to call up\n");

                /* from call up to call status */
                LW_ATCallUp();
            }
            break;
        }
        case LW_ATCMD_CALL_UP:
        {
            if (*ATcmdIndex == LW_ATCMD_CALL_UP_QCRMCALL_UP)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_QCRMCALL_UP) == NULL)
                {
                    LW_SetDialState(FALSE);
                }
                else
                {
                    LW_SetDialState(TRUE);
                }
            }

            *ATcmdIndex = *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_UP_MAX)
            {
                if (LW_GetDialState())
                {
                    LW_WWANDhcpup();
                    LW_LOGI("Dialing successful! to call status\n");
                }
                else
                {
                    LW_LOGI("Dialing exception! to call status\n"); 
                }

                /* from call up to call status */
                LW_ATCallStatus();
            }
            break;
        }
        case LW_ATCMD_CALL_DOWN:
        {
            *ATcmdIndex = *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_DOWN_MAX)
            {
                LW_WWANDhcpdown();
                LW_LOGI("Dhcp stopped\n");

                LW_EventStop();
            }
            break;
        }
        case LW_ATCMD_CALL_STATUS:
        {
            if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_QCRMCALL_STATUS)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_QCRMCALL_UP) == NULL)
                {
                    LW_SetDialState(FALSE);
                }
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_CGREG)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_CGREG_STATUS) == NULL)
                {
                    LW_SetDialState(FALSE);
                }
            }
#ifdef LW_ECM_FEATURE_SHOW_REPORT
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_COPS)
            {
                _LW_ShowInfoParseCops(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_CIMI)
            {
                _LW_ShowInfoParseCimi(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_ATI)
            {
                _LW_ShowInfoParseAti(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_QENG_SERVING_CELL)
            {
                _LW_ShowInfoParseQengServingCell(ATreply, LW_GetShowInfoConf());
            }
#endif /* LW_ECM_FEATURE_SHOW_REPORT */


            *ATcmdIndex = *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_MAX)
            {
#ifdef LW_ECM_FEATURE_SHOW_REPORT
                if (!LW_GetDialState())
                {
                    LW_GetShowInfoConf()->ShowInfo.DialState = 0;
                }
                else
                {
                    LW_GetShowInfoConf()->ShowInfo.DialState = 1;
                }
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

                if (!LW_GetDialState())
                {
                    LW_LOGI("Dialing exception! to redial\n");
                    LW_ATCallUp();
                    goto CommonReturn;
                }

                LW_LOGI("Dialing normally! to call status again\n");
                LW_ATCallStatus();
            }

            break;
        }
        case LW_ATCMD_CALL_MESSAGES:
        {
            (void)LW_SendToClientSuccess(ATreply);
            break;
        }
        default:
        {
            LW_LOGI("ATcmdType invalid\n");
            break;
        }
    }

CommonReturn:
    return isHandled;
}

static void _LW_QueUdevInfoRegistFunc(LW_UDEV_INFO *UdevInfo)
{
    UdevInfo->MonitorCnt = 1;

    UdevInfo->MonitorInfo = malloc(sizeof(LW_UDEV_MONITOR_INFO) * UdevInfo->MonitorCnt);
    if (UdevInfo->MonitorInfo == NULL)
    {
        UdevInfo->MonitorCnt = 0;
        LW_LOGI("malloc failed\n");
        goto CommonReturn;
    }

    memset(UdevInfo->MonitorInfo, 0, sizeof(LW_UDEV_MONITOR_INFO) * UdevInfo->MonitorCnt);

    UdevInfo->MonitorInfo[0].Mode = LW_MODULE_MODEL_MODE_NORMAL;
    LW_SafeStrCopy(UdevInfo->MonitorInfo[0].DeviceAction, LW_UDEV_DEVICE_ACTION_STR_MAX, "add");
    LW_SafeStrCopy(UdevInfo->MonitorInfo[0].IdVendor, LW_VID_PID_LENGTH_MAX, LW_EC20_ID_VENDOR);
    LW_SafeStrCopy(UdevInfo->MonitorInfo[0].IdProduct, LW_VID_PID_LENGTH_MAX, LW_EC20_ID_PRODUCT);

CommonReturn:
    return;
}

static LW_ERR_T  _LW_QueUdevMonitorFunc(LW_MODULE_MODEL_MODE Mode)
{
    LW_ERR_T ret = LW_SUCCESS;

    switch (Mode)
    {
        case LW_MODULE_MODEL_MODE_NORMAL:
        {
            memset(LW_GetCrashInfoConf(), 0, sizeof(LW_GetCrashInfoConf()->CrashInfo));
            LW_GetCrashInfoConf()->InfoType = LW_WWAN_MANAGER_INFO_CRASH;
            LW_GetCrashInfoConf()->WwanModule = LW_WWAN_MODULE_MODEL_NONE;

#ifdef LW_ECM_FEATURE_SHOW_REPORT
            if (LW_GetShowInfoConf()->WwanModule != LW_WWAN_MODULE_MODEL_NONE)
            {
                LW_GetCrashInfoConf()->WwanModule = LW_GetShowInfoConf()->WwanModule;
            }
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

            LW_GetCrashInfoConf()->CrashInfo.TimeStamp = time(NULL);
            LW_GetCrashInfoConf()->CrashInfo.CrashFileFlag = 0;

#ifdef LW_ECM_FEATURE_CRASH_ALERT
            ret = LW_SendMsgToAgent(LW_GetCrashInfoConf());
            if (ret < LW_SUCCESS)
            {
                goto CommonReturn;
            }
#endif /* LW_ECM_FEATURE_CRASH_ALERT */

            if (LW_CheckIntfLoaded() == FALSE)
            {
                ret = -LW_ENXIO;
                goto CommonReturn;
            }

            ret = LW_RedialByUdevMonitor(
                                        TRUE, 
                                        &_LW_QueGetATcmdFunc, 
                                        &_LW_QueATreplyHandlerFunc, 
                                        &_LW_QueUdevInfoRegistFunc,
                                        &_LW_QueUdevMonitorFunc
                                        );
            if (ret < LW_SUCCESS)
            {
                LW_LOGI("Redial failed, exit...\n");
                goto CommonReturn;
            }
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            break;
        }
    }

CommonReturn:
    return ret;
}

static int _LW_QueInit()
{
    int ret = 0;

    LW_RegistSignal();

    if (LW_EventInit(
                    FALSE, 
                    &_LW_QueGetATcmdFunc, 
                    &_LW_QueATreplyHandlerFunc, 
                    &_LW_QueUdevInfoRegistFunc, 
                    &_LW_QueUdevMonitorFunc
                    ) < LW_SUCCESS)
    {
        ret = -1;
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static int _LW_QueProcessing(int DialType)
{
    return LW_EventHandleDispatch(DialType);
}

static void _LW_QueExit()
{
    LW_LOGI("Processing stopped\n");
}

LW_DIAL_DRIVER g_DialDriverEC20 = 
{
    .Name = "EG25/EC25/EM05/EC20",
    .IDVendor = "2c7c",
    .IDProduct = "0125",
    .TtyUSBPath = "/dev/ttyUSB2",
    .Init = _LW_QueInit,
    .Exit = _LW_QueExit,
    .Processing = _LW_QueProcessing,
};

LW_DIAL_DRIVER* LW_GetDriverEC20()
{
    return &g_DialDriverEC20;
}
