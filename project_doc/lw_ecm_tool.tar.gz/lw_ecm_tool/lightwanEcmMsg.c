#include <stdlib.h>
#include "lightwanEcmMsg.h"
#include "lightwanSerialConfig.h"
#include "lightwanSafeStr.h"

#define LW_SIGNAL_STRENGTH_EXCELLENT    "Excellent"
#define LW_SIGNAL_STRENGTH_GOOD         "Good"
#define LW_SIGNAL_STRENGTH_AVERAGE      "Average"
#define LW_SIGNAL_STRENGTH_FAIR         "Fair"
#define LW_SIGNAL_STRENGTH_POOR         "Poor"
#define LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN  10

#define LW_WWAN_MANAGER_INFO_JSON_STR_MAX    512
#define LW_WWAN_MANAGER_INFO_JSON_STR_CRASH_INFO \
"cpeagent wwanmodule \
\"{\\\"WwanManagerInfo\\\": {\\\"InfoType\\\": \\\"%d\\\", \\\"WwanModule\\\": \\\"%d\\\", \
\\\"CrashInfo\\\": {\\\"TimeStamp\\\": \\\"%lu\\\", \\\"CrashFileFlag\\\":\\\"%d\\\", \
\\\"CrashFileName\\\": \\\"%s\\\"}}}\""

#define LW_WWAN_MANAGER_INFO_JSON_STR_SHOW_INFO \
"cpeagent wwanmodule \
\"{\\\"WwanManagerInfo\\\": {\\\"InfoType\\\": \\\"%d\\\", \\\"WwanModule\\\": \\\"%d\\\", \
\\\"ShowInfo\\\": {\\\"DialState\\\": \\\"%u\\\", \\\"NetworkType\\\":\\\"%u\\\", \
\\\"Lac\\\": \\\"%u\\\", \\\"Ci\\\":\\\"%"PRIu64"\\\", \\\"Rsrp\\\": \\\"%u\\\", \
\\\"Sinr\\\":\\\"%u\\\", \\\"Mcc\\\": \\\"%s\\\", \\\"Mnc\\\": \\\"%s\\\", \
\\\"Imsi\\\": \\\"%s\\\"}}}\""

static struct event * g_ShowInfoEvent = NULL;
static LW_WWAN_MANAGER_INFO g_ShowInfo;
static LW_WWAN_MANAGER_INFO g_CrashInfo;

static void 
_LW_SignalStrengthRsrp(
    int Rsrp, 
    char * Strength
    )
{
    if (Rsrp > -85)
    {
        LW_SNPrintf(Strength, LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN, "%s", LW_SIGNAL_STRENGTH_EXCELLENT);
    }
    else if (Rsrp > -95)
    {
        LW_SNPrintf(Strength, LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN, "%s", LW_SIGNAL_STRENGTH_GOOD);
    }
    else if (Rsrp > -105)
    {
        LW_SNPrintf(Strength, LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN, "%s", LW_SIGNAL_STRENGTH_AVERAGE);
    }
    else if (Rsrp > -115)
    {
        LW_SNPrintf(Strength, LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN, "%s", LW_SIGNAL_STRENGTH_FAIR);
    }
    else
    {
        LW_SNPrintf(Strength, LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN, "%s", LW_SIGNAL_STRENGTH_POOR);
    }
    return;
}

static void 
_LW_SignalStrengthSinr(
    int Sinr, 
    char * Strength
    )
{
    if (Sinr > 25)
    {
        LW_SNPrintf(Strength, LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN, "%s", LW_SIGNAL_STRENGTH_EXCELLENT);
    }
    else if (Sinr > 16)
    {
        LW_SNPrintf(Strength, LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN, "%s", LW_SIGNAL_STRENGTH_GOOD);
    }
    else if (Sinr > 11)
    {
        LW_SNPrintf(Strength, LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN, "%s", LW_SIGNAL_STRENGTH_AVERAGE);
    }
    else if (Sinr > 3)
    {
        LW_SNPrintf(Strength, LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN, "%s", LW_SIGNAL_STRENGTH_FAIR);
    }
    else
    {
        LW_SNPrintf(Strength, LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN, "%s", LW_SIGNAL_STRENGTH_POOR);
    }
    return;
}

LW_ERR_T
LW_SendMsgToAgent(
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    char cmdLine[LW_WWAN_MANAGER_INFO_JSON_STR_MAX] = { 0 };
    int rsrp = 0;
    double rsrq = 0;
    double sinr = 0;
    char rsrpStrength[LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN] = {0};
    char sinrStrength[LW_SIGNAL_STRENGTH_CONTENT_MAX_LEN] = {0};

    switch(WwanManagerInfo->InfoType)
    {
        case LW_WWAN_MANAGER_INFO_CRASH:
        {
            snprintf(cmdLine, LW_WWAN_MANAGER_INFO_JSON_STR_MAX, LW_WWAN_MANAGER_INFO_JSON_STR_CRASH_INFO, 
                WwanManagerInfo->InfoType,
                WwanManagerInfo->WwanModule,
                WwanManagerInfo->CrashInfo.TimeStamp,
                WwanManagerInfo->CrashInfo.CrashFileFlag,
                WwanManagerInfo->CrashInfo.CrashFileName);

            LW_LOGI("Send WWAN module crash information, InfoType:%u WwanModule:%u TimeStamp:%lu CrashFileFlag:%u  CrashFileName:%s",
                WwanManagerInfo->InfoType,
                WwanManagerInfo->WwanModule,
                WwanManagerInfo->CrashInfo.TimeStamp,
                WwanManagerInfo->CrashInfo.CrashFileFlag,
                WwanManagerInfo->CrashInfo.CrashFileName);
            break;
        }
        case LW_WWAN_MANAGER_INFO_SHOW:
        {
            snprintf(cmdLine, LW_WWAN_MANAGER_INFO_JSON_STR_MAX, LW_WWAN_MANAGER_INFO_JSON_STR_SHOW_INFO, 
                WwanManagerInfo->InfoType,
                WwanManagerInfo->WwanModule,
                WwanManagerInfo->ShowInfo.DialState,
                WwanManagerInfo->ShowInfo.NetworkType,
                WwanManagerInfo->ShowInfo.Lac,
                WwanManagerInfo->ShowInfo.Ci,
                WwanManagerInfo->ShowInfo.Rsrp,
                WwanManagerInfo->ShowInfo.Sinr,
                WwanManagerInfo->ShowInfo.Mcc,
                WwanManagerInfo->ShowInfo.Mnc,
                WwanManagerInfo->ShowInfo.Imsi);

            LW_LOGI("Send WWAN module show information, InfoType:%u WwanModule:%u DialState:%u NetworkType:%u Lac:%u Ci:%"PRIu64" Rsrp:%u Sinr:%u Mcc:%s Mnc:%s Imsi:%s",
                WwanManagerInfo->InfoType,
                WwanManagerInfo->WwanModule,
                WwanManagerInfo->ShowInfo.DialState,
                WwanManagerInfo->ShowInfo.NetworkType,
                WwanManagerInfo->ShowInfo.Lac,
                WwanManagerInfo->ShowInfo.Ci,
                WwanManagerInfo->ShowInfo.Rsrp,
                WwanManagerInfo->ShowInfo.Sinr,
                WwanManagerInfo->ShowInfo.Mcc,
                WwanManagerInfo->ShowInfo.Mnc,
                WwanManagerInfo->ShowInfo.Imsi);

            if (WwanManagerInfo->ShowInfo.Rsrp != 0)
            {
                rsrp = LW_SHOW_INFO_PARAM_TO_RSRP(WwanManagerInfo->ShowInfo.Rsrp);
                _LW_SignalStrengthRsrp(rsrp, rsrpStrength);
                LW_LOGI("Signal strength info rsrp:%ddBm <%s>\n", rsrp, rsrpStrength);
            }
            if (WwanManagerInfo->ShowInfo.Sinr != 0)
            {
                sinr = LW_SHOW_INFO_PARAM_TO_SINR(WwanManagerInfo->ShowInfo.Sinr);
                _LW_SignalStrengthSinr(sinr, sinrStrength);
                LW_LOGI("Signal strength info sinr:%.1fdB <%s>\n", sinr, sinrStrength);
            }
            if (WwanManagerInfo->ShowInfo.Rsrq != 0)
            {
                rsrq = LW_SHOW_INFO_PARAM_TO_RSRQ(WwanManagerInfo->ShowInfo.Rsrq);
                LW_LOGI("Signal strength info rsrq:%.1fdB\n", rsrq);
            }
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            LW_LOGI("unknown type(%u)\n", WwanManagerInfo->InfoType);
            goto CommonReturn;
        }
    }

    LW_LOGI("cmdLine:%s\n", cmdLine);
    ret = system(cmdLine);
    if (ret < 0)
    {
        LW_LOGI("system cpeagent cmdline failed, ret %d", ret);
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

LW_WWAN_MANAGER_INFO * LW_GetShowInfoConf()
{
    return &g_ShowInfo;
}

LW_WWAN_MANAGER_INFO * LW_GetCrashInfoConf()
{
    return &g_CrashInfo;
}

struct event * LW_GetShowInfoEvent()
{
    return g_ShowInfoEvent;
}

void LW_ShowInfoEventAdd()
{
    struct timeval tv;

    tv.tv_sec = LW_SHOW_INFO_REPORT_INTERVAL;
    tv.tv_usec = 0;

    event_add(g_ShowInfoEvent, &tv);

    memset(LW_GetShowInfoConf(), 0, sizeof(LW_WWAN_MANAGER_INFO));
    LW_GetShowInfoConf()->InfoType = LW_WWAN_MANAGER_INFO_SHOW;
    LW_GetShowInfoConf()->WwanModule = LW_WWAN_MODULE_MODEL_NONE;  /* default */

    LW_LOGI("Begin to report show info, interval %u seconds\n", LW_SHOW_INFO_REPORT_INTERVAL);
}

void
LW_ShowInfoEvent(
    int SockCtl,
    short EventTrigger,
    void* Arg
    )
{
    if (LW_SendMsgToAgent(&g_ShowInfo) < LW_SUCCESS)
    {
        LW_LOGI("Send show information to agent failed\n");
    }

    memset(&g_ShowInfo.ShowInfo, 0, sizeof(g_ShowInfo.ShowInfo));
    g_ShowInfo.WwanModule = LW_WWAN_MODULE_MODEL_NONE;  /* default */
}

LW_ERR_T
LW_ShowInfoEventInit(
    struct event_base * EventBase
    )
{
    LW_ERR_T ret = LW_SUCCESS;

    g_ShowInfoEvent = event_new(EventBase, -1, EV_PERSIST, LW_ShowInfoEvent, NULL);
    if (g_ShowInfoEvent == NULL)
    {
        ret = -ENOMEM;
        LW_LOGI("new information report event failed\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

void LW_ShowInfoEventFree()
{
    if (g_ShowInfoEvent)
    {
        event_free(g_ShowInfoEvent);
        g_ShowInfoEvent = NULL;
    }
}

/*******************************************************************************
 * NAME:    LW_GetIntValAfterNthComma
 *
 * DESCRIPTION:
 *      Parse AT cmd reply content to get an integer value, include the first digit or an int value after nth ',';  
 *
 *      Example 1:
 *          AtContent: "1,4,460,11,18A1,1940D11,994,21,105,50,20,66,66,24"
 *          N: 2
 *          output IntVal: 460
 *
 *      Example 2:
 *          AtContent: "\"-125\",\"-12\",-3"
 *          N: 0
 *          output IntVal: -125
 *
 * INPUTS:
 *      AtContent:      [input] at cmd reply content
 *      N:              [input] the nth ','
 *      IntVal:         [output] return val of int type
 *
 * RETURN:
 *      SUCCESS:     LW_SUCCESS
 *      FAILED:      < LW_SUCCESS
 * 
 */
LW_ERR_T
LW_GetIntValAfterNthComma(
    const char *AtContent,
    int N,
    int * IntVal
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    int commaCnt = 0;
    size_t len = 0;
    size_t index = 0;

    if (AtContent == NULL)
    {
        ret = -LW_EINVAL;
        goto CommonReturn;
    }

    if (N > 0 && strstr(AtContent, ",") == NULL)
    {
        ret = -LW_EINVAL;
        goto CommonReturn;
    }

    len = strlen(AtContent);

    while(index < len)
    {
        if (N == 0)
        {
            if (AtContent[index] >= '0' && AtContent[index] <= '9')
            {
                if (index > 0 && AtContent[index - 1] == '-')
                {
                    index = index - 1;
                }
                *IntVal = atoi(&AtContent[index]);
                goto CommonReturn;
            }
        }
        else
        {
            if (AtContent[index] == ',')
            {
                commaCnt ++;
                if (commaCnt == N)
                {
                    index = index + 1;
                    while(index < len)
                    {
                        if (AtContent[index] >= '0' && AtContent[index] <= '9')
                        {
                            if (index > 0 && AtContent[index - 1] == '-')
                            {
                                index = index - 1;
                            }
                            *IntVal = atoi(&AtContent[index]);
                            goto CommonReturn;
                        }

                        index ++;
                    }
                }
            }
        }

        index ++;
    }

    ret = -LW_EINVAL;

CommonReturn:
    return ret;
}
/*******************************************************************************
 * NAME:    LW_GetStringValAfterNthComma
 *
 * DESCRIPTION:
 *      Parse AT cmd reply content to return String, include the first digit or an string value after nth ',';
 * 
 *      Example 1:
 *          AtContent: "1,4,460,11,18A1,1940D11,994,21,105,50,20,66,66,24"
 *          N = 5, 
 *          StringVal: 1940D11
 * 
 *      Example 2:
 *          AtContent: "1,4,460,00,18A1,1940D11,994,21,105,50,20,66,66,24"
 *          N = 4, 
 *          StringVal: 00
 *          
 * 
 * INPUTS:
 *      AtContent:      [input] at cmd reply content
 *      N:              [input] the nth ','
 *      StringVal:      [output] the string val
 * 
 * RETURN:
 *      Returns the size of string value, or 0 when not found
 * 
 */
size_t
LW_GetStringValAfterNthComma(
    const char *AtContent,
    int N,
    char * StringVal
    )
{
    size_t len = 0;
    size_t indexStart = 0;
    size_t indexEnd = 0;
    int commaCnt = 0;
    size_t lenRet = 0;

    if (AtContent == NULL)
    {
        goto CommonReturn;
    }

    if (N > 0 && strstr(AtContent, ",") == NULL)
    {
        goto CommonReturn;
    }

    len = strlen(AtContent);

    while(indexStart < len)
    {        
        if (N == 0)
        {
            if (AtContent[indexStart] >= '0' && AtContent[indexStart] <= '9')
            {
                indexEnd = indexStart + 1;
                while(indexEnd < len)
                {
                    if (AtContent[indexEnd] < '0' || AtContent[indexEnd] > '9')
                    {
                        lenRet = indexEnd - indexStart;
                        LW_SafeStrCopy(StringVal, lenRet + 1, &AtContent[indexStart]);
                        goto CommonReturn;
                    }
                    indexEnd ++;
                }

                goto CommonReturn;
            }
        }
        else
        {
            if (AtContent[indexStart] == ',')
            {
                commaCnt ++;
                if (commaCnt == N)
                {
                    indexEnd = indexStart + 1;

                    while(indexEnd < len)
                    {
                        if (AtContent[indexEnd] == ',')
                        {
                            lenRet = indexEnd - indexStart;
                            if (lenRet > 1) /* exclude ",," */
                            {
                                LW_SafeStrCopy(StringVal, lenRet, &AtContent[indexStart + 1]);
                            }
                            goto CommonReturn;
                        }
                        indexEnd ++;
                    }
                    goto CommonReturn;
                }
            }
        }

        indexStart ++;
    }

CommonReturn:
    return lenRet;
}