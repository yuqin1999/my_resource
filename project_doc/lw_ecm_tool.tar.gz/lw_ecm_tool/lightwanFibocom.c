#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <pthread.h>
#include <sys/socket.h>
#include <event.h>
#include <signal.h>
#include <time.h>
#include <dirent.h>

#include "lightwanSafeStr.h"
#include "lightwanSerialConfig.h"
#include "lightwanEvent.h"
#include "lightwanDhcp.h"
#include "lightwanEcmMsg.h"
#include "lightwanUdev.h"
#include "lightwanEcmManager.h"

/* FM150 information */
#define LW_FM150_ID_VENDOR                              "2cb7"
#define LW_FM150_ID_PRODUCT                             "0104"
#define LW_FM150_ID_VENDOR_DUMP                         "05c6"
#define LW_FM150_ID_PRODUCT_DUMP                        "900e"

/* AT CMD */
#define LW_ATCMD_SUFFIX                                 "\r\n"
#define LW_ATCMD_ATE0                                   "ATE0\r\n"
#define LW_ATCMD_ATI                                    "ATI\r\n"
#define LW_ATCMD_DUMPEN                                 "AT+DUMPEN=1\r\n"
#define LW_ATCMD_CPIN                                   "AT+CPIN?\r\n"
#define LW_ATCMD_CAVIMS                                 "AT+CAVIMS=0\r\n"
#define LW_ATCMD_GTACT_NR_LTE                           "AT+GTACT=17,6\r\n"
#define LW_ATCMD_COPS_FORMAT_ADAPT                      "AT+COPS=3,2\r\n"
#define LW_ATCMD_COPS                                   "AT+COPS?\r\n"
#define LW_ATCMD_CGDCONT_PREFIX                         "AT+CGDCONT=1,\"IP\",\""
#define LW_ATCMD_CGDCONT_SUFFIX                         "\"\r\n"
#define LW_ATCMD_QCRMCALL_DOWN                          "AT$QCRMCALL=0,1,1\r\n"
#define LW_ATCMD_QCRMCALL_UP                            "AT$QCRMCALL=1,1,1\r\n"
#define LW_ATCMD_QCRMCALL_STATUS                        "AT$QCRMCALL?\r\n"
#define LW_ATCMD_GTCCINFO                               "AT+GTCCINFO?\r\n"
#define LW_ATCMD_CIMI                                   "AT+CIMI?\r\n"
#define LW_ATCMD_CGDCONT_STATUS                         "AT+CGDCONT?\r\n"
#define LW_ATCMD_CESQ                                   "AT+CESQ\r\n"
#define LW_ATCMD_CGREG_STATUS                           "AT+CGREG?\r\n"

/* AT cmd reply */
#define LW_ATCMD_REPLY_READY                            "READY"
#define LW_ATCMD_REPLY_QCRMCALL_UP                      "1,V4"
#define LW_ATCMD_REPLY_CGREG_STATUS                     "0,1"
#define LW_ATCMD_REPLY_CGREG_ROAMING_STATUS             "0,5"

/* device checking function*/
#define LW_DISK_FREE_SPACE_3072M                        3072  /* 3G */
#define LW_DISK_FREE_SPACE_300M                         300
#define LW_DISK_FREE_SPACE_150M                         150

typedef enum _LW_ATCMD_CALL_INIT_CMD
{
    LW_ATCMD_CALL_INIT_NONE,

    LW_ATCMD_CALL_INIT_ATE0,
    LW_ATCMD_CALL_INIT_GTACT_NR_LTE,
    LW_ATCMD_CALL_INIT_DUMPEN,
    LW_ATCMD_CALL_INIT_CGDCONT,

    LW_ATCMD_CALL_INIT_MAX,
} LW_ATCMD_CALL_INIT_CMD;

typedef enum _LW_ATCMD_CALL_UP_CMD
{
    LW_ATCMD_CALL_UP_NONE,

    LW_ATCMD_CALL_UP_ATE0,
    LW_ATCMD_CALL_UP_ATI,
    LW_ATCMD_CALL_UP_CPIN,
    LW_ATCMD_CALL_UP_CAVIMS,
    LW_ATCMD_CALL_UP_CGDCONT_STATUS,
    LW_ATCMD_CALL_UP_CGREG_STATUS,
    LW_ATCMD_CALL_UP_COPS_FORMAT_ADAPT,
    LW_ATCMD_CALL_UP_COPS,
    LW_ATCMD_CALL_UP_QCRMCALL_DOWN,
    LW_ATCMD_CALL_UP_QCRMCALL_UP,
    LW_ATCMD_CALL_UP_QCRMCALL_STATUS,

    LW_ATCMD_CALL_UP_MAX,
} LW_ATCMD_CALL_UP_CMD;

typedef enum _LW_ATCMD_CALL_DOWN_CMD
{
    LW_ATCMD_CALL_DOWN_NONE,

    LW_ATCMD_CALL_DOWN_ATE0,
    LW_ATCMD_CALL_DOWN_QCRMCALL_DOWN,
    LW_ATCMD_CALL_DOWN_QCRMCALL_STATUS,

    LW_ATCMD_CALL_DOWN_MAX,
} LW_ATCMD_CALL_DOWN_CMD;

typedef enum _LW_ATCMD_CALL_STATUS_CMD
{
    LW_ATCMD_CALL_STATUS_NONE,

    LW_ATCMD_CALL_STATUS_CGREG,
    LW_ATCMD_CALL_STATUS_COPS,
    LW_ATCMD_CALL_STATUS_CESQ,
    LW_ATCMD_CALL_STATUS_CIMI,
    LW_ATCMD_CALL_STATUS_ATI,
    LW_ATCMD_CALL_STATUS_GTCCINFO,
    LW_ATCMD_CALL_STATUS_QCRMCALL,

    LW_ATCMD_CALL_STATUS_MAX,
} LW_ATCMD_CALL_STATUS_CMD;

#ifdef LW_ECM_FEATURE_SHOW_REPORT

/* index starts from 0 */
#define LW_SERVICE_CELL_NR      "NR service cell"
#define LW_ATCMD_GTCCINFO_NR_TAC_INDEX              4
#define LW_ATCMD_GTCCINFO_NR_CI_INDEX               5
#define LW_ATCMD_GTCCINFO_NR_SINR_INDEX             10
#define LW_ATCMD_GTCCINFO_NR_RSRQ_INDEX             11
#define LW_ATCMD_GTCCINFO_NR_RSRP_INDEX             12

#define LW_SERVICE_CELL_LTE     "LTE service cell"
#define LW_ATCMD_GTCCINFO_LTE_TAC_INDEX             4
#define LW_ATCMD_GTCCINFO_LTE_CI_INDEX              5
#define LW_ATCMD_GTCCINFO_LTE_RSRQ_INDEX            11
#define LW_ATCMD_GTCCINFO_LTE_RSRP_INDEX            12

#define LW_SERVICE_CELL_LTE_NR  "LTE-NR EN-DC service cell"
#define LW_ATCMD_GTCCINFO_LTE_NR_TAC_INDEX          4
#define LW_ATCMD_GTCCINFO_LTE_NR_CI_INDEX           5
#define LW_ATCMD_GTCCINFO_LTE_NR_SINR_INDEX         23
#define LW_ATCMD_GTCCINFO_LTE_NR_RSRQ_INDEX         24
#define LW_ATCMD_GTCCINFO_LTE_NR_RSRP_INDEX         25

#define LW_ATCMD_CIMI_IMSI_INDEX                    0

#define LW_ATCMD_COPS_MCC_MNC_INDEX                 2
#define LW_ATCMD_COPS_MCC_INDEX                     1
#define LW_ATCMD_COPS_MNC_INDEX                     4
#define LW_ATCMD_COPS_MCC_OR_MNC_MAX_LEN            4  /* include null-terminator */
/*******************************************************************************
 * NAME:  _LW_ShowInfoParseAti
 *
 * DESCRIPTION:
 *      Parse "ati" reply content returned ci, eg:
 *      reply:
 *          Manufacturer: Fibocom Wireless Inc.                                                    
 *          Model: FM150-AE
 *          Revision: 89602.1000.00.04.07.33
 *          SVN: 01
 *          IMEI: 865697040127109
 *          +GCAP: +CGSM
 *          
 *          OK
 *          
 *      result:
 *          imei=865697040127109
 *          moduleVersion=89602.1000.00.04.07.33
 * 
 *
 * INPUTS:
 *      ReplyContent:               "ati" reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void 
_LW_ShowInfoParseAti(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    if (strstr(ReplyContent, LW_ATCMD_REPLY_FM150_AE))
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_FM150;
    }
    else if (strstr(ReplyContent, LW_ATCMD_REPLY_FM160_CN))
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_FM160_CN;
    }
    else if (strstr(ReplyContent, LW_ATCMD_REPLY_FM160_EAU))
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_FM160_EAU;
    }
    else if (strstr(ReplyContent, LW_ATCMD_REPLY_FM160_JK))
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_FM160_JK;
    }
    else if (strstr(ReplyContent, LW_ATCMD_REPLY_FM160_NA))
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_FM160_NA;
    }
    else
    {
        WwanManagerInfo->WwanModule = LW_WWAN_MODULE_MODEL_NONE;
        LW_LOGI("ati reply invalid\n");
        goto CommonReturn;
    }

CommonReturn:
    return;
}

/*******************************************************************************
 * NAME:  _LW_ShowInfoParseCops
 *
 * DESCRIPTION:
 *      Parse reply content to get param, eg:
 *      
 *      reply:
 *
 *          +COPS: 0,2,"46011",7
 *
 *          OK
 * 
 *      result:
 *          mcc=460
 *          mnc=11
 * 
 * INPUTS:
 *      ReplyContent:               reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void
_LW_ShowInfoParseCops(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    size_t len = 0;
    char *pStart = NULL;
    char mccmnc[LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN] = {0};

    pStart = strstr(ReplyContent, "+COPS");
    if (pStart == NULL)
    {
        LW_LOGI("cops reply invalid\n");
        goto CommonReturn;
    }

    /* such as "46001" or "316010" */
    len = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_COPS_MCC_MNC_INDEX, mccmnc);
    if (len == 0)
    {
        LW_LOGI("get mcc mnc failed\n");
        goto CommonReturn;
    }

    LW_SafeStrCopy(WwanManagerInfo->ShowInfo.Mcc, LW_ATCMD_COPS_MCC_OR_MNC_MAX_LEN, &mccmnc[LW_ATCMD_COPS_MCC_INDEX]);
    LW_SafeStrCopy(WwanManagerInfo->ShowInfo.Mnc, LW_ATCMD_COPS_MCC_OR_MNC_MAX_LEN, &mccmnc[LW_ATCMD_COPS_MNC_INDEX]);

    if (WwanManagerInfo->ShowInfo.Mnc[2] == '\"')
    {
        WwanManagerInfo->ShowInfo.Mnc[2] = 0;
    }

CommonReturn:
    return;
}

/*******************************************************************************
 * NAME:  _LW_ShowInfoParseGtccinfo
 *
 * DESCRIPTION:
 *      Parse "at+gtccinfo?" reply content, returned 1 network type, 2 rsrp, 3 sinr, 4 ci, 5 lac(or tac)
 * 
 *  eg: 
 *      1 LTE
 *          reply:
 *              +GTCCINFO:
 *              LTE service cell:
 *              1,4,460,11,18A1,1940D11,994,21,105,50,20,66,66,24
 *
 *          result: 
 *              network type is LTE; rsrp=66; ci=1940D11; tac=18A1; sinr is not support
 * 
 *      2 NR
 *          reply:
 *              +GTCCINFO:
 *              NR service cell:
 *              network type is NR; 1,9,460,00,12F001,BOF3ED06F,7B49E,2C5,5041,100,83,84,84,59
 *
 *          result:
 *              network type belong to NR; rsrp=84; tac=12F001; ci=BOF3ED06F; sinr=83;
 *
 *      3 LTE-NR
 *          reply:
 *              +GTCCINFO:
 *              LTE-NR EN-DC service cell:
 *              1,4,460,00,57A9,65E2585,514,12B,103,100,8,58,58,20
 *              1,9,460,00, , , 7B49E,3,5041,100,79,57,57,65
 * 
 *          result:
 *              network type belong to NR; rsrp=84; tac=57A9; ci=65E2585; sinr=83
 *
 * INPUTS:
 *      ReplyContent:               "at+gtccinfo?" reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void 
_LW_ShowInfoParseGtccinfo(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    char *pStart = NULL;
    size_t ciLen = 0;
    size_t lacLen = 0;
    char ci[LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN] = {0};
    char lac[LW_WWAN_MANAGER_SHOW_INFO_PARAM_MAX_LEN] = {0};
    int rsrp = 0;
    int rsrq = 0;
    int sinr = 0;

    pStart = strstr(ReplyContent, "+GTCCINFO");
    if (pStart == NULL)
    {
        LW_LOGI("gtccinfo reply invalid\n");
        goto CommonReturn;
    }
    if (strstr(ReplyContent, LW_SERVICE_CELL_NR))
    {
        LW_LOGI("%s\n", LW_SERVICE_CELL_NR);
        WwanManagerInfo->ShowInfo.NetworkType = LW_WWAN_NETWORK_NR;

        lacLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_NR_TAC_INDEX, lac);
        if (lacLen == 0)
        {
            LW_LOGI("get lac failed\n");
        }
        else
        {
            WwanManagerInfo->ShowInfo.Lac = strtol(lac , NULL, LW_PARAM_NUM_FORMAT_HEX);
        }

        ciLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_NR_CI_INDEX, ci);
        if (ciLen == 0)
        {
            LW_LOGI("get ci failed\n");
        }
        else
        {
            WwanManagerInfo->ShowInfo.Ci = (uint64_t)strtoll(ci , NULL, LW_PARAM_NUM_FORMAT_HEX);
        }

        if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_NR_RSRP_INDEX, &rsrp) < LW_SUCCESS)
        {
            LW_LOGI("get rsrp failed");
        }
        else
        {
            if (rsrp != 0 && rsrp != 255)
            {
                rsrp = rsrp - 156;

                LW_LOGD("get rsrp %ddBm\n", rsrp);

                if (rsrp < 0)
                {
                    WwanManagerInfo->ShowInfo.Rsrp = LW_SHOW_INFO_RSRP_TO_PARAM(rsrp);
                }
            }
        }

        if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_NR_RSRQ_INDEX, &rsrq) < LW_SUCCESS)
        {
            LW_LOGI("get rsrq failed\n");
        }
        else
        {
            if (rsrq != 0 && rsrq != 255)
            {
                LW_LOGD("get rsrq %.1fdB\n", (double)rsrq / 2 - 43);
                WwanManagerInfo->ShowInfo.Rsrq = LW_SHOW_INFO_RSRQ_TO_PARAM((double)rsrq / 2 - 43);
            }
        }

        if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_NR_SINR_INDEX, &sinr) < LW_SUCCESS)
        {
            LW_LOGI("get sinr failed\n");
        }
        else
        {
            if (sinr != 0 && sinr != 255)
            {
                LW_LOGD("get sinr %.1fdB\n", (double)sinr / 2 - 23);
                WwanManagerInfo->ShowInfo.Sinr = LW_SHOW_INFO_SINR_TO_PARAM((double)sinr / 2 - 23);
            }
        }
    }
    else if (strstr(ReplyContent, LW_SERVICE_CELL_LTE))
    {
        LW_LOGI("%s\n", LW_SERVICE_CELL_LTE);
        WwanManagerInfo->ShowInfo.NetworkType = LW_WWAN_NETWORK_LTE;

        /* sinr is not support */

        lacLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_LTE_TAC_INDEX, lac);
        if (lacLen == 0)
        {
            LW_LOGI("get lac failed\n");
        }
        else
        {
            WwanManagerInfo->ShowInfo.Lac = strtol(lac , NULL, LW_PARAM_NUM_FORMAT_HEX);
        }

        ciLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_LTE_CI_INDEX, ci);
        if (ciLen == 0)
        {
            LW_LOGI("get ci failed\n");
        }
        else
        {
            WwanManagerInfo->ShowInfo.Ci = (uint64_t)strtoll(ci , NULL, LW_PARAM_NUM_FORMAT_HEX);
        }

        if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_LTE_RSRP_INDEX, &rsrp) < LW_SUCCESS)
        {
            LW_LOGI("get rsrp failed\n");
        }
        else
        {        
            if (rsrp != 0 && rsrp != 255)
            {
                rsrp = rsrp - 140;
                LW_LOGD("get rsrp %ddBm\n", rsrp);

                if (rsrp < 0)
                {
                    WwanManagerInfo->ShowInfo.Rsrp = LW_SHOW_INFO_RSRP_TO_PARAM(rsrp);
                }
            }
        }

        if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_LTE_RSRQ_INDEX, &rsrq) < LW_SUCCESS)
        {
            LW_LOGI("get rsrq failed\n");
        }
        else
        {
            if (rsrq != 0 && rsrq != 255)
            {
                LW_LOGD("get rsrq %.1fdB\n", (double)rsrq / 2 - 19.5);
                WwanManagerInfo->ShowInfo.Rsrq = LW_SHOW_INFO_RSRQ_TO_PARAM((double)rsrq / 2 - 19.5);
            }
        }
    }
    else if (strstr(ReplyContent, LW_SERVICE_CELL_LTE_NR))
    {
        LW_LOGI("%s\n", LW_SERVICE_CELL_LTE_NR);
        WwanManagerInfo->ShowInfo.NetworkType = LW_WWAN_NETWORK_NR;

        lacLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_LTE_NR_TAC_INDEX, lac);
        if (lacLen == 0)
        {
            LW_LOGI("get lac failed\n");
        }
        else
        {
            WwanManagerInfo->ShowInfo.Lac = strtol(lac , NULL, LW_PARAM_NUM_FORMAT_HEX);
        }

        ciLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_LTE_NR_CI_INDEX, ci);
        if (ciLen == 0)
        {
            LW_LOGI("get ci failed\n");
        }
        else
        {
            WwanManagerInfo->ShowInfo.Ci = (uint64_t)strtoll(ci , NULL, LW_PARAM_NUM_FORMAT_HEX);
        }

        if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_LTE_NR_RSRP_INDEX, &rsrp) < LW_SUCCESS)
        {
            LW_LOGI("get rsrp failed\n");
        }
        else
        {
            if (rsrp != 0 && rsrp != 255)
            {
                rsrp = rsrp - 156;
                LW_LOGD("get rsrp %ddBm\n", rsrp);

                if (rsrp < 0)
                {
                    WwanManagerInfo->ShowInfo.Rsrp = LW_SHOW_INFO_RSRP_TO_PARAM(rsrp);
                }
            }
        }

        if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_LTE_NR_RSRQ_INDEX, &rsrq) < LW_SUCCESS)
        {
            LW_LOGI("get rsrq failed\n");
        }
        else
        {
            if (rsrq != 0 && rsrq != 255)
            {
                LW_LOGD("get rsrq %.1fdBm\n", (double)rsrq / 2 - 43);
                WwanManagerInfo->ShowInfo.Rsrq = LW_SHOW_INFO_RSRQ_TO_PARAM((double)rsrq / 2 - 43);
            }
        }

        if (LW_GetIntValAfterNthComma(pStart, LW_ATCMD_GTCCINFO_LTE_NR_SINR_INDEX, &sinr) < LW_SUCCESS)
        {
            LW_LOGI("get sinr failed\n");
        }
        else
        {
            if (sinr != 0 && sinr != 255)
            {
                LW_LOGD("get sinr %.1fdB\n", (double)sinr / 2 - 23);
                WwanManagerInfo->ShowInfo.Sinr = LW_SHOW_INFO_SINR_TO_PARAM((double)sinr / 2 - 23);
            }
        }
    }
    else
    {
        LW_LOGI("Service cell invalid\n");
        goto CommonReturn;
    }

CommonReturn:
    return;
}

/*******************************************************************************
 * NAME:  _LW_ShowInfoParseCimi
 *
 * DESCRIPTION:
 *      Parse "at+cimi?" reply content returned ci, eg:
 *      reply:
 *          +CIMI: 460019059048947
 *      
 *      result:
 *          imsi=460019059048947
 *
 * INPUTS:
 *      ReplyContent:               "at+cimi?" reply content
 *      WwanManagerInfo:            Show information config
 * 
 * RETURN:
 *      NONE.
 */
static void 
_LW_ShowInfoParseCimi(
    const char * ReplyContent,
    LW_WWAN_MANAGER_INFO * WwanManagerInfo
    )
{
    char *pStart = NULL;
    size_t imsiLen = 0;

    pStart = strstr(ReplyContent, "+CIMI");
    if (pStart == NULL)
    {
        LW_LOGI("cimi reply invalid\n");
        goto CommonReturn;
    }

    imsiLen = LW_GetStringValAfterNthComma(pStart, LW_ATCMD_CIMI_IMSI_INDEX, WwanManagerInfo->ShowInfo.Imsi);
    if (imsiLen == 0)
    {
        LW_LOGI("get imsi failed\n");
    }

CommonReturn:
    return;
}

#endif /* LW_ECM_FEATURE_SHOW_REPORT */

static LW_ERR_T
_LW_GetCallInitATcmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_UP_CMD ATcmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;

    switch (ATcmdIndex)
    {
        case LW_ATCMD_CALL_INIT_ATE0:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ATE0);
            break;
        }
        case LW_ATCMD_CALL_INIT_GTACT_NR_LTE:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_GTACT_NR_LTE);
            break;
        }
        case LW_ATCMD_CALL_INIT_DUMPEN:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_DUMPEN);
            break;
        }
        case LW_ATCMD_CALL_INIT_CGDCONT:
        {
            LW_LOGI("Set Apn %s\n", LW_GetApn());
            len = LW_SNPrintf(ATcmd, ATcmdLen, "%s%s%s", LW_ATCMD_CGDCONT_PREFIX, LW_GetApn(), LW_ATCMD_CGDCONT_SUFFIX);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GetCallUpATcmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_UP_CMD ATcmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;

    switch (ATcmdIndex)
    {
        case LW_ATCMD_CALL_UP_ATE0:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ATE0);
            break;
        }
        case LW_ATCMD_CALL_UP_ATI:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ATI);
            break;
        }
        case LW_ATCMD_CALL_UP_CPIN:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CPIN);
            break;
        }
        case LW_ATCMD_CALL_UP_CAVIMS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CAVIMS);
            break;
        }
        case LW_ATCMD_CALL_UP_CGDCONT_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CGDCONT_STATUS);
            break;
        }
        case LW_ATCMD_CALL_UP_CGREG_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CGREG_STATUS);
            break;
        }
        case LW_ATCMD_CALL_UP_COPS_FORMAT_ADAPT:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_COPS_FORMAT_ADAPT);
            break;
        }
        case LW_ATCMD_CALL_UP_COPS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_COPS);
            break;
        }
        case LW_ATCMD_CALL_UP_QCRMCALL_DOWN:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_QCRMCALL_DOWN);
            break;
        }
        case LW_ATCMD_CALL_UP_QCRMCALL_UP:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_QCRMCALL_UP);
            break;
        }
        case LW_ATCMD_CALL_UP_QCRMCALL_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_QCRMCALL_STATUS);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GetCallDownATcmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_DOWN_CMD ATcmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;

    switch (ATcmdIndex)
    {
        case LW_ATCMD_CALL_DOWN_ATE0:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ATE0);
            break;
        }
        case LW_ATCMD_CALL_DOWN_QCRMCALL_DOWN:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_QCRMCALL_DOWN);
            break;
        }
        case LW_ATCMD_CALL_DOWN_QCRMCALL_STATUS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_QCRMCALL_STATUS);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_GetCallStatusATcmdByIndex(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_CALL_STATUS_CMD ATcmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;
    switch (ATcmdIndex)
    {
        case LW_ATCMD_CALL_STATUS_CGREG:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CGREG_STATUS);
            break;
        }
        case LW_ATCMD_CALL_STATUS_COPS:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_COPS);
            break;
        }
        case LW_ATCMD_CALL_STATUS_CESQ:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CESQ);
            break;
        }
        case LW_ATCMD_CALL_STATUS_GTCCINFO:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_GTCCINFO);
            break;
        }
        case LW_ATCMD_CALL_STATUS_QCRMCALL:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_QCRMCALL_STATUS);
            break;
        }
        case LW_ATCMD_CALL_STATUS_CIMI:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_CIMI);
            break;
        }
        case LW_ATCMD_CALL_STATUS_ATI:
        {
            len = LW_SafeStrCopy(ATcmd, ATcmdLen, LW_ATCMD_ATI);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

    if (len >= ATcmdLen)
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("AT cmd is overflow\n");
        goto CommonReturn;
    }
    
CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_FibGetATcmdFunc(
    char  *ATcmd,
    size_t ATcmdLen,
    LW_ATCMD_TYPE ATcmdType,
    uint32_t ATcmdIndex
    )
{
    LW_ERR_T ret = LW_SUCCESS;

    switch (ATcmdType)
    {
        case LW_ATCMD_CALL_INIT:
        {
            ret = _LW_GetCallInitATcmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        case LW_ATCMD_CALL_UP:
        {
            ret = _LW_GetCallUpATcmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        case LW_ATCMD_CALL_DOWN:
        {
            ret = _LW_GetCallDownATcmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        case LW_ATCMD_CALL_STATUS:
        {
            ret = _LW_GetCallStatusATcmdByIndex(ATcmd, ATcmdLen, ATcmdIndex);
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            goto CommonReturn;
        }
    }

CommonReturn:
    return ret;
}

static void
_LW_DumpLogClean()
{
    DIR * dir = NULL;
    struct dirent * ptr = NULL;
    char matchFile1[LW_FILE_NAME_MAX_LEN] = {0};
    char matchFile2[LW_FILE_NAME_MAX_LEN] = {0};
    char fileName[LW_FILE_NAME_MAX_LEN] = {0};
    unsigned long long freeSize = 0;
    int fileFlag = 0;  /* 0:rm current file; 1: replace file1; 2:replace file2 */

    freeSize = LW_GetPathDiskFree("/var/log/");

    dir = opendir("/var/log/");
    if (dir == NULL)
    {
        LW_LOGI("open /var/log/ failed\n");
        goto CommonReturn;
    }

    while ((ptr = readdir(dir)) != NULL)
    {
        if (strstr(ptr->d_name, "dump_log_"))
        {
            if (LW_FILE_NAME_MAX_LEN < (strlen(ptr->d_name) + 1))
            {
                LW_LOGI("File name is too long %s\n", ptr->d_name);
                continue;
            }

            fileFlag = 0;
            /* step1: compare file creation time */
            if (freeSize >= LW_DISK_FREE_SPACE_3072M) /* range (3072,], keep 2 log files */
            {
                if ((LW_SafeStrCmp(ptr->d_name, matchFile1, sizeof(matchFile1)) < 0) && 
                    (LW_SafeStrCmp(ptr->d_name, matchFile2, sizeof(matchFile2)) < 0))
                {
                    fileFlag = 0;
                }
                else if (LW_SafeStrCmp(ptr->d_name, matchFile1, sizeof(matchFile1)) < 0)
                {
                    fileFlag = 2;
                }
                else if (LW_SafeStrCmp(ptr->d_name, matchFile2, sizeof(matchFile2)) < 0)
                {
                    fileFlag = 1;
                }
                else
                {
                    if ((LW_SafeStrCmp(matchFile2, matchFile1, sizeof(matchFile2)) < 0))
                    {
                        fileFlag = 2;
                    }
                    else
                    {
                        fileFlag = 1;
                    }
                }
            }
            else if (freeSize >= LW_DISK_FREE_SPACE_300M)  /* range (300, 3072], keep 1 log file */
            {
                if (LW_SafeStrCmp(ptr->d_name, matchFile1, sizeof(matchFile1)) < 0)
                {
                    fileFlag = 0;
                }
                else
                {
                    fileFlag = 1;
                }
            }
            else /* range [0, 300], clean all log files*/
            {
                fileFlag = 0;
            }

            /* step2: remove old file, and reserve new file */
            if (fileFlag == 0)
            {
                LW_SNPrintf(fileName, sizeof(fileName), "/var/log/%s", ptr->d_name);
                LW_LOGI("clean %s\n", fileName);
                if (LW_RemovemFileOrDir(fileName) < 0) 
                {
                    LW_LOGI("clean %s failed\n", fileName);
                }
            }
            else if (fileFlag == 1)
            {
                if (matchFile1[0] != '\0')
                {
                    LW_SNPrintf(fileName, sizeof(fileName), "/var/log/%s", matchFile1);
                    LW_LOGI("clean %s\n", fileName);
                    if (LW_RemovemFileOrDir(fileName) < 0) 
                    {
                        LW_LOGI("clean %s failed\n", fileName);
                    }
                }
                LW_SafeStrCopy(matchFile1, sizeof(matchFile1), ptr->d_name);
            }
            else if (fileFlag == 2)
            {
                if (matchFile2[0] != '\0')
                {
                    LW_SNPrintf(fileName, sizeof(fileName), "/var/log/%s", matchFile2);
                    LW_LOGI("clean %s\n", fileName);
                    if (LW_RemovemFileOrDir(fileName) < 0) 
                    {
                        LW_LOGI("clean %s failed\n", fileName);
                    }
                }
                LW_SafeStrCopy(matchFile2, sizeof(matchFile2), ptr->d_name);
            }
        }
    }

CommonReturn:
    if (dir)
    {
        closedir(dir);
    }
    return;
}

static LW_ERR_T
_LW_DumpLogCompress(
    const char* FileName
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    ssize_t len = 0;
    char cmd[LW_ATCMD_MAX_LEN] = {0};

    len = LW_SNPrintf(cmd, sizeof(cmd), "tar -czf %s.tar.gz %s --remove-files", FileName, FileName);
    if (len >= sizeof(cmd))
    {
        ret = -LW_EOVERFLOW;
        goto CommonReturn;
    }

    ret = system(cmd);
    if (ret < 0)
    {
        LW_LOGI("Compress dump_log failed ret = %d\n", ret);
        goto CommonReturn;
    }

    LW_LOGI("Compress dump_log to %s.tar.gz successfully\n", FileName);

CommonReturn:
    return ret;
}

static LW_ERR_T
_LW_DumpLogCollect(
    char * LogPath,
    size_t LogPathLen
    )
{
    LW_ERR_T ret = LW_SUCCESS;
    int fd = -1;
    ssize_t len = 0;
    char cmd[LW_ATCMD_MAX_LEN] = {0};
    time_t curTime = 0; /* seconds */

    (void)_LW_DumpLogClean();

    if ((LW_GetPathDiskFree("/var/log/") < LW_DISK_FREE_SPACE_150M))
    {
        ret = -LW_EOVERFLOW;
        LW_LOGI("Out of disk space or disk error.\n");
        goto CommonReturn;
    }

    fd = open("/sys/bus/usb-serial/drivers/option1/new_id", O_WRONLY | O_CLOEXEC);
    if (fd < 0)
    {
        ret = -LW_EEXIST;
        LW_LOGI("open file failed\n");
        goto CommonReturn;
    }

    len = write(fd, "05c6 900e\n", sizeof("05c6 900e\n"));
    if (len < 0)
    {
        ret = -LW_EIO;
        LW_LOGI("write failed\n");
        goto CommonReturn;
    }

    LW_LOGI("Start collecting dump log\n");
    curTime = time(NULL);
    len = LW_SNPrintf(cmd, sizeof(cmd), "/bin/appex/fibo_dump_collect_tool -f /var/log/dump_log_%u", (uint32_t)curTime);
    if (len >= sizeof(cmd))
    {
        ret = -LW_EOVERFLOW;
        goto CommonReturn;
    }
    ret = system(cmd);
    if (ret < 0)
    {
        LW_LOGI("Collecting dump log failed ret = %d\n", ret);
        goto CommonReturn;
    }
    LW_LOGI("Finish collecting dump log\n");
    
    len = LW_SNPrintf(LogPath, LogPathLen, "/var/log/dump_log_%u", (uint32_t)curTime);
    if (len >= LogPathLen)
    {
        ret = -LW_EOVERFLOW;
        goto CommonReturn;
    }

    if ((LW_GetPathDiskFree("/var/log/") < LW_DISK_FREE_SPACE_150M))
    {
        LW_LOGI("Disk free space too less, not to compress %s\n", LogPath);
        ret = LW_SUCCESS;
        goto CommonReturn;
    }

    ret = _LW_DumpLogCompress(LogPath);
    if (ret < LW_SUCCESS)
    {
        LW_LOGI("Compress dump_log to %s.tar.gz failed\n", LogPath);
        goto CommonReturn;
    }

    len = LW_SNPrintf(LogPath, LogPathLen, "/var/log/dump_log_%u.tar.gz", (uint32_t)curTime);
    if (len >= sizeof(cmd))
    {
        ret = -LW_EOVERFLOW;
        goto CommonReturn;
    }

CommonReturn:
    if (fd != -1)
    {
        close(fd);
    }

    return ret;
}

static BOOL
_LW_IsValidReply(
    const char * ATreply,
    LW_ATCMD_TYPE ATcmdType, 
    uint32_t *ATcmdIndex
    )
{
    BOOL isValidReply = FALSE;

    if (strstr(ATreply, LW_ATCMD_REPLY_OK))
    {
        isValidReply = TRUE;
    }

    switch (ATcmdType)
    {
        case LW_ATCMD_CALL_UP:
        {
            if (*ATcmdIndex == LW_ATCMD_CALL_UP_CPIN)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_READY) == NULL)
                {
                    isValidReply = FALSE;
                }
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_UP_CGREG_STATUS)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_CGREG_STATUS) == NULL && strstr(ATreply, LW_ATCMD_REPLY_CGREG_ROAMING_STATUS) == NULL)
                {
                    isValidReply = FALSE;
                }
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_UP_QCRMCALL_DOWN)
            {
                /* ignore reply */
                LW_LOGI("Ignore AT qcrmcall down reply\n");
                isValidReply = TRUE;
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_UP_QCRMCALL_UP)
            {
                /* ignore reply maybe NO CARRIER */
                LW_LOGI("Ignore AT qcrmcall up reply\n");
                isValidReply = TRUE;
            }

            break;
        }
        case LW_ATCMD_CALL_DOWN:
        {
            /* ignore reply */
            LW_LOGI("Ignore call down reply\n");
            isValidReply = TRUE;
            break;
        }
        case LW_ATCMD_CALL_STATUS:
        {
            /* ignore reply */
            isValidReply = TRUE;
            break;
        }
        case LW_ATCMD_CALL_MESSAGES:
        {
            /* ignore reply */
            isValidReply = TRUE;
            break;
        }
        default:
        {
            break;
        }
    }

    return isValidReply;
}

static BOOL
_LW_FibATreplyHandlerFunc(
    const char * ATreply,
    LW_ATCMD_TYPE ATcmdType, 
    uint32_t *ATcmdIndex
    )
{
    BOOL isHandled = FALSE;

    if (!_LW_IsValidReply(ATreply, ATcmdType, ATcmdIndex))
    {
        goto CommonReturn;
    }

    isHandled = TRUE;

    switch (ATcmdType)
    {
        case LW_ATCMD_CALL_INIT:
        {
            *ATcmdIndex =  *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_INIT_MAX)
            {
                LW_LOGI("Initializing successful! to call up\n");

                /* from call up to call status */
                LW_ATCallUp();
            }
            break;
        }
        case LW_ATCMD_CALL_UP:
        {
            if (*ATcmdIndex == LW_ATCMD_CALL_UP_QCRMCALL_STATUS)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_QCRMCALL_UP) == NULL)
                {
                    LW_SetDialState(FALSE);
                }
                else
                {
                    LW_SetDialState(TRUE);
                }
            }

            *ATcmdIndex =  *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_UP_MAX)
            {
                if (LW_GetDialState())
                {
                    LW_WWANDhcpup();
                    LW_LOGI("Dialing successful! to call status\n");
                }
                else
                {
                    LW_LOGI("Dialing exception! to call status\n"); 
                }

                /* from call up to call status */
                LW_ATCallStatus();
            }
            break;
        }
        case LW_ATCMD_CALL_DOWN:
        {
           *ATcmdIndex =  *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_DOWN_MAX)
            {
                LW_WWANDhcpdown();
                LW_LOGI("Dhcp stopped\n");

                LW_EventStop();
            }
            break;
        }
        case LW_ATCMD_CALL_STATUS:
        {
            if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_QCRMCALL)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_QCRMCALL_UP) == NULL)
                {
                    LW_SetDialState(FALSE);
                }
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_CGREG)
            {
                if (strstr(ATreply, LW_ATCMD_REPLY_CGREG_STATUS) == NULL && strstr(ATreply, LW_ATCMD_REPLY_CGREG_ROAMING_STATUS) == NULL)
                {
                    LW_SetDialState(FALSE);
                }
            }
#ifdef LW_ECM_FEATURE_SHOW_REPORT
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_COPS)
            {
                _LW_ShowInfoParseCops(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_GTCCINFO)
            {
                _LW_ShowInfoParseGtccinfo(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_CIMI)
            {
                _LW_ShowInfoParseCimi(ATreply, LW_GetShowInfoConf());
            }
            else if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_ATI)
            {
                _LW_ShowInfoParseAti(ATreply, LW_GetShowInfoConf());
            }
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

           *ATcmdIndex =  *ATcmdIndex + 1;

            if (*ATcmdIndex == LW_ATCMD_CALL_STATUS_MAX)
            {
                
#ifdef LW_ECM_FEATURE_SHOW_REPORT
                if (!LW_GetDialState())
                {
                    LW_GetShowInfoConf()->ShowInfo.DialState = 0;
                }
                else
                {
                    LW_GetShowInfoConf()->ShowInfo.DialState = 1;
                }
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

                if (!LW_GetDialState())
                {
                    LW_LOGI("Dialing exception! to redial\n");
                    LW_ATCallUp();
                    goto CommonReturn;
                }

                LW_LOGI("Dialing normally! to call status again\n");
                LW_ATCallStatus();
            }

            break;
        }
        case LW_ATCMD_CALL_MESSAGES:
        {
            (void)LW_SendToClientSuccess(ATreply);
            break;
        }
        default:
        {
            LW_LOGI("ATcmdType invalid\n");
            break;
        }
    }

CommonReturn:
    return isHandled;
}


static void _LW_FibUdevInfoRegistFunc(LW_UDEV_INFO *UdevInfo)
{
    UdevInfo->MonitorCnt = 2;

    UdevInfo->MonitorInfo = malloc(sizeof(LW_UDEV_MONITOR_INFO) * UdevInfo->MonitorCnt);
    if (UdevInfo->MonitorInfo == NULL)
    {
        UdevInfo->MonitorCnt = 0;
        LW_LOGI("malloc failed\n");
        goto CommonReturn;
    }

    memset(UdevInfo->MonitorInfo, 0, sizeof(LW_UDEV_MONITOR_INFO) * UdevInfo->MonitorCnt);

    UdevInfo->MonitorInfo[0].Mode = LW_MODULE_MODEL_MODE_NORMAL;
    LW_SafeStrCopy(UdevInfo->MonitorInfo[0].DeviceAction, LW_UDEV_DEVICE_ACTION_STR_MAX, "add");
    LW_SafeStrCopy(UdevInfo->MonitorInfo[0].IdVendor, LW_VID_PID_LENGTH_MAX, LW_FM150_ID_VENDOR);
    LW_SafeStrCopy(UdevInfo->MonitorInfo[0].IdProduct, LW_VID_PID_LENGTH_MAX, LW_FM150_ID_PRODUCT);

    UdevInfo->MonitorInfo[1].Mode = LW_MODULE_MODEL_MODE_DUMP;
    LW_SafeStrCopy(UdevInfo->MonitorInfo[1].DeviceAction, LW_UDEV_DEVICE_ACTION_STR_MAX, "add");
    LW_SafeStrCopy(UdevInfo->MonitorInfo[1].IdVendor, LW_VID_PID_LENGTH_MAX, LW_FM150_ID_VENDOR_DUMP);
    LW_SafeStrCopy(UdevInfo->MonitorInfo[1].IdProduct, LW_VID_PID_LENGTH_MAX, LW_FM150_ID_PRODUCT_DUMP);

CommonReturn:
    return;
}

static LW_ERR_T  _LW_FibUdevMonitorFunc(LW_MODULE_MODEL_MODE Mode)
{
    LW_ERR_T ret = LW_SUCCESS;
    size_t len = 0;
    char logPath[LW_FILE_NAME_MAX_LEN] = {0};

    switch (Mode)
    {
        case LW_MODULE_MODEL_MODE_NORMAL:
        {
            if (LW_CheckIntfLoaded() == FALSE)
            {
                ret = -LW_ENXIO;
                goto CommonReturn;
            }

            ret = LW_RedialByUdevMonitor(
                                        TRUE, 
                                        &_LW_FibGetATcmdFunc, 
                                        &_LW_FibATreplyHandlerFunc, 
                                        &_LW_FibUdevInfoRegistFunc,
                                        &_LW_FibUdevMonitorFunc
                                        );
            if (ret < LW_SUCCESS)
            {
                LW_LOGI("Redial failed, exit...\n");
                goto CommonReturn;
            }
            break;
        }
        case LW_MODULE_MODEL_MODE_DUMP:
        {
            memset(LW_GetCrashInfoConf(), 0, sizeof(LW_GetCrashInfoConf()->CrashInfo));
            LW_GetCrashInfoConf()->InfoType = LW_WWAN_MANAGER_INFO_CRASH;
            LW_GetCrashInfoConf()->WwanModule = LW_WWAN_MODULE_MODEL_NONE;

#ifdef LW_ECM_FEATURE_SHOW_REPORT
            if (LW_GetShowInfoConf()->WwanModule != LW_WWAN_MODULE_MODEL_NONE)
            {
                LW_GetCrashInfoConf()->WwanModule = LW_GetShowInfoConf()->WwanModule;
            }
#endif /* LW_ECM_FEATURE_SHOW_REPORT */

            LW_GetCrashInfoConf()->CrashInfo.TimeStamp = time(NULL);
            LW_GetCrashInfoConf()->CrashInfo.CrashFileFlag = 1;

            if (_LW_DumpLogCollect(logPath, sizeof(logPath)) < LW_SUCCESS)
            {
                LW_GetCrashInfoConf()->CrashInfo.CrashFileFlag = 2;
                LW_LOGI("collecting dump log exception, ret = %d\n", ret);
                LW_EventStop();
            }

            len = LW_SafeStrCopy(
                                LW_GetCrashInfoConf()->CrashInfo.CrashFileName, 
                                sizeof(LW_GetCrashInfoConf()->CrashInfo.CrashFileName), 
                                logPath
                                );
            if (len >= sizeof(LW_GetCrashInfoConf()->CrashInfo.CrashFileName))
            {
                ret = -LW_EOVERFLOW;
                LW_LOGI("string is overflow\n");
                goto CommonReturn;
            }

#ifdef LW_ECM_FEATURE_CRASH_ALERT
            ret = LW_SendMsgToAgent(LW_GetCrashInfoConf());
            if (ret < LW_SUCCESS)
            {
                goto CommonReturn;
            }
#endif /* LW_ECM_FEATURE_CRASH_ALERT */
            break;
        }
        default:
        {
            ret = -LW_EINVAL;
            break;
        }
    }

CommonReturn:
    return ret;
}

static int _LW_FibInit()
{
    int ret = 0;

    LW_RegistSignal();

    if (LW_EventInit(
                    FALSE, 
                    &_LW_FibGetATcmdFunc, 
                    &_LW_FibATreplyHandlerFunc, 
                    &_LW_FibUdevInfoRegistFunc, 
                    &_LW_FibUdevMonitorFunc
                    ) < LW_SUCCESS)
    {
        ret = -1;
        goto CommonReturn;
    }

CommonReturn:
    return ret;
}

static int _LW_FibProcessing(int DialType)
{
    return LW_EventHandleDispatch(DialType);
}

static void _LW_FibExit()
{
    LW_LOGI("Processing stopped\n");
}

LW_DIAL_DRIVER g_DialDriverFM150 = 
{
    .Name = "FM150-AE/FM160-CN/FM160-EAU/FM160-JK/FM160-NA",
    .IDVendor = "2cb7",
    .IDProduct = "0104",
    .TtyUSBPath = "/dev/ttyUSB2",
    .Init = _LW_FibInit,
    .Exit = _LW_FibExit,
    .Processing = _LW_FibProcessing,
};

LW_DIAL_DRIVER* LW_GetDriverFM150()
{
    return &g_DialDriverFM150;
}
