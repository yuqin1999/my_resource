#!/bin/bash
set -x
WORK_PATH=$(cd $(dirname $0); pwd)

PLATFORM=$1
if [ -z $1 ]; then
    PLATFORM=2508
fi

export PATH=$PATH:$WORK_PATH
ZIP_TOOL_7Z_PLATFORM=${WORK_PATH}/7z.${PLATFORM}
ZIP_TOOL_7Z=${WORK_PATH}/7z
UPDATE_TOOL=${WORK_PATH}/upgrade_tool_v1.3.0.${PLATFORM}
UPDATE_PACKAGE=${WORK_PATH}/$(ls ${WORK_PATH} | grep ".7z")
UPDATE_PACKAGE_MD5_FILE=${UPDATE_PACKAGE%.*}.md5
UPDATE_PACKAGE_DIR=${UPDATE_PACKAGE%.*}
UPDATE_RESULT=${WORK_PATH}/update_result.txt
#=================================env
echo $(md5sum ${UPDATE_PACKAGE} | awk '{ print $1 }') > ${UPDATE_PACKAGE_MD5_FILE}
cp ${ZIP_TOOL_7Z_PLATFORM} ${ZIP_TOOL_7Z}

#=================================update
${UPDATE_TOOL} -f ${UPDATE_PACKAGE}
echo "update result:$(cat ${UPDATE_RESULT})"
#=================================clean
rm -rf ${UPDATE_RESULT}
rm -rf ${ZIP_TOOL_7Z}
rm -rf ${UPDATE_PACKAGE_MD5_FILE}
rm -rf ${UPDATE_PACKAGE_DIR}