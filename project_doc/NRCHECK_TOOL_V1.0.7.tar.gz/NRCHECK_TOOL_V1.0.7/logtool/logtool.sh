#!/bin/bash
set -x

PLATFORM=$1
CATCH_TIME=$2
DIAL_FLAG=$3

#PLATFORM= ${2508 2506 2509}
if [ -z "$PLATFORM" ] || [ "$PLATFORM" -ne 2506 -a "$PLATFORM" -ne 2508 -a "$PLATFORM" -ne 2509 ]; then
    echo "PLATFORM invalid"
    exit 1
fi
echo "PLATFORM:${PLATFORM}"

if [ -z "$CATCH_TIME" ]; then
    echo "CATCH_TIME invalid"
    exit 1 
fi
echo "CATCH_TIME:${CATCH_TIME}"

if [ -z "$DIAL_FLAG" ] || [ "$DIAL_FLAG" -ne 0 -a "$DIAL_FLAG" -ne 1 ]; then
    echo "DIAL_FLAG invalid"
    exit 1
fi
echo "DIAL_FLAG:${DIAL_FLAG}"

if [ "$DIAL_FLAG" -eq 0 ]; then
    kill -9  $(ps aux  |grep ECM_DEMO | grep -v grep | awk -F ' ' '{print $2}')
fi
kill -9  $(ps aux  |grep cat | grep -v grep | awk -F ' ' '{print $2}')
kill -9  $(ps aux  |grep minicom | grep -v grep | awk -F ' ' '{print $2}')
kill -9  $(ps aux  |grep logtool.${PLATFORM} | grep -v grep | awk -F ' ' '{print $2}')

rm -rf *.qdb
rm -rf fibolog_* 
rm -rf log_files*

./logtool.${PLATFORM} > /dev/null &

#==================================================
#       AT cmd start
#==================================================
#sleep 2
#../at.${PLATFORM} ati

#sleep 2
#../at.${MODEL} at+cops?

#sleep 2
#../at.${MODEL} at+gtusbmode?
#==================================================
#       AT cmd end
#==================================================

sleep ${CATCH_TIME}
kill -9  $(ps aux  |grep logtool.${PLATFORM} | grep -v grep | awk -F ' ' '{print $2}')

LOG_FILE=$(ls |grep fibolog_)
if [ -z "$LOG_FILE" ]; then
    tar czf log_files_$(date "+%Y_%m_%d_%s").tar.gz log_files/ *.qdb
    rm -rf log_files/
else
    tar czf fibolog_$(date "+%Y_%m_%d_%s").tar.gz ${LOG_FILE} *.qdb
    rm -rf ${LOG_FILE}
fi
    rm -rf *.qdb

echo "collect log finish!"