#!/bin/bash
# Version: v1.0.3 2023/5/23
#=======================================================================================================================
# Configurable parameters
#=======================================================================================================================
Ping_Switch=0                           # ping function switch
Overall_Apn="cmnet"                     # APN config
Target_Server="114.114.114.114"         # target server ip addr

NR_Out_Switch=0                         # out 5g band function switch
Check_Time=600                          # the longest time to stay outside the 5G band.

NR_Crash_Switch=1                       # nr crash switch
At_Mobile="12345678901"                 # phone number, need to join the ding group
LW_Device="LW2508"
webhook="https://oapi.dingtalk.com/robot/send?access_token=db5cd0cec88b16c2f674cd468cd55285dad84c3cadd543af01c86c2480bf29b3"
#webhook="https://oapi.dingtalk.com/robot/send?access_token=be740abec2ab78f96a6384b0e38d506b88c496fed629ab3679d8e25ecd71737e" #debug webhook

#=======================================================================================================================
# Main parameters
#=======================================================================================================================
site_name=`cat /etc/motd | sed '/^$/d'` # CPE site information
dump_tool=""
at_tool=""
dump_log_name="/var/log/dump_log"

#=======================================================================================================================
# Reset parameters
#=======================================================================================================================
# ping check packets count
Ping_Count=5
# Specify the network port to send the ping command
Source_outlet="ppp15"
# when consecutive ping failed ${Consecutive_Ping_Fail_Times_Max} times, will reset module
Consecutive_Ping_Fail_Times_Max=3       
# when reset module & ping failed ${Consecutive_Reset_Fail_Times_Max} times, will reboot machine
Consecutive_Reset_Fail_Times_Max=3      
# set 1 to reboot module when reset module is useless. set 0 will continueously reset module instead of reboot machine
Reboot_or_Not=1
# When the module is restarted or reset for a certain number of times, restart the system
Reboot_for_Ping_or_Reset_Count=0
# Parameter below is Untouchable !
Consecutive_ping_Fail_Times=0
Consecutive_Reset_Fail_Times=0

#=======================================================================================================================
# Reset NRCHECK_1 feature parameters
#=======================================================================================================================
# Set to 1, which means the system is restarted because it has stayed in non 5G frequency band for a long time
Reboot_for_Networks=0
# The device is online by default at 5G. When switching to 4G for a long time, restart the device                
Networks_NR="NR"                       
flags=1

#=======================================================================================================================
# Crash parameters
#=======================================================================================================================

webhook_ret="{\"errcode\":0,\"errmsg\":\"ok\"}"
# Crash alert time and return information
restart_ecm_msg_success_time_now=""
restart_ecm_msg_failed_time_now=""
restart_ecm_msg_disable_time_now=""
restart_ecm_msg_exc_time_now=""
restart_ecm_msg_success="restart ECM_DEMO success."
restart_ecm_msg_failed="restart ECM_DEMO failed!"
restart_ecm_msg_disable="no need to restart ECM_DEMO."
restart_ecm_msg_exc="4g/5g Interface exception!"
dump_log_collect_msg_success_time_now=""
dump_log_collect_msg_failed_time_now=""
dump_log_collect_msg_exc_time_now=""
dump_log_collect_msg_exc2_time_now=""
dump_log_collect_msg_success="Dump log collection succeeded, you can find it in /var/log/dump_log_xxx.tar.gz, begin restart ECM_DEMO."
dump_log_collect_msg_failed="please check device status, Dump log collection failed!"
dump_log_collect_msg_exc="please check device status, module restore exception!"
dump_log_collect_msg_exc2="Configure /sys/bus/usb-serial/drivers/option1/new_id failed!"
check_device_msg_crash_time_now=""
check_device_msg_exc_time_now=""
check_device_msg_crash="please check device status, module crash occurs!"
check_device_msg_exc="please check device status, module cannot enter dump mode!"

#=======================================================================================================================
# return parameters
#=======================================================================================================================
ret_success=0
ret_found_crash=1
ret_fail_others=7

#=======================================================================================================================
# Ending parameters
#=======================================================================================================================

SLog()
{
    logger -t NRCHECK[$$] "$@"
    #echo "$@"
}

check_module()
{
    if [ ${NR_Crash_Switch} -eq 0 ]; then
        return
    fi

    check_vpid=`lsusb |grep "2cb7:0104" | awk '{print $6}'`
    if [ -z "$check_vpid" ]; then
        SLog "Please check device model, is not FM150-AE/FM160-CN/FM160-EAU"
        exit $ret_fail_others
    fi
}

Set_dump_mode()
{
    if [ -e /dev/ttyUSB1 ]; then
        ./${at_tool} -d /dev/ttyUSB1 "AT+DUMPEN=1"
        sleep 1
    else
        SLog "Module error, no ttyUSB1 found"
        exit $ret_fail_others
    fi
}

send_message()
{
    sleep 3
    while :
    do
        ret=`curl  $webhook -H 'Content-Type: application/json' -d "
        {
            'msgtype': 'text',
            'text': {
                'content': '${1}告警:\n${site_name}\n时间:${3}\n${2}\n'
            },
            'at': {
                'atMobiles':[
                    '${At_Mobile}'
                ],
                'isAtAll': false
            }
        }" -s`
        if [ "$ret" = "$webhook_ret" ]; then
            #SLog "Debug alert success"
            SLog "Dingding alert time:${3}\n${2}\n"
            break
        else
            #SLog "Debug return value invalid"
            sleep 60
        fi
    done
}

send_message_list()
{
    #check_device_msg
    if [ -n "$check_device_msg_crash_time_now" ]; then
        send_message "模块crash" "$check_device_msg_crash" "$check_device_msg_crash_time_now"
        check_device_msg_crash_time_now=""
    fi

    if [ -n "$check_device_msg_exc_time_now" ]; then
        send_message "模块crash" "$check_device_msg_exc" "$check_device_msg_exc_time_now"
        check_device_msg_exc_time_now=""
        exit
    fi

    #dump_log_collect_msg
    if [ -n "$dump_log_collect_msg_success_time_now" ]; then
        send_message "模块crash" "$dump_log_collect_msg_success" "$dump_log_collect_msg_success_time_now"
        dump_log_collect_msg_success_time_now=""
    fi
    
    if [ -n "$dump_log_collect_msg_failed_time_now" ]; then
        send_message "模块crash" "$dump_log_collect_msg_failed" "$dump_log_collect_msg_failed_time_now"
        dump_log_collect_msg_failed_time_now=""
        exit
    fi

    if [ -n "$dump_log_collect_msg_exc_time_now" ]; then
        send_message "模块crash" "$dump_log_collect_msg_exc" "$dump_log_collect_msg_exc_time_now"
        dump_log_collect_msg_exc_time_now=""
        exit
    fi

    if [ -n "$dump_log_collect_msg_exc2_time_now" ]; then
        send_message "模块crash" "$dump_log_collect_msg_exc2" "$dump_log_collect_msg_exc2_time_now"
        dump_log_collect_msg_exc2_time_now=""
        exit
    fi
    
    #restart_ecm_msg
    if [ -n "$restart_ecm_msg_success_time_now" ]; then
        send_message "模块crash" "$restart_ecm_msg_success" "$restart_ecm_msg_success_time_now"
        restart_ecm_msg_success_time_now=""
    fi

    if [ -n "$restart_ecm_msg_disable_time_now" ]; then
        send_message "模块crash" "$restart_ecm_msg_disable" "$restart_ecm_msg_disable_time_now"
        restart_ecm_msg_disable_time_now=""
    fi

    if [ -n "$restart_ecm_msg_failed_time_now" ]; then
        send_message "模块crash" "$restart_ecm_msg_failed" "$restart_ecm_msg_failed_time_now"
        restart_ecm_msg_failed_time_now=""
        exit
    fi

    if [ -n "$restart_ecm_msg_exc_time_now" ]; then
        send_message "模块crash" "$restart_ecm_msg_exc" "$restart_ecm_msg_exc_time_now"
        restart_ecm_msg_exc_time_now=""
        exit
    fi
}

restart_ecm()
{
    SLog "to check interface"
    for i in {1..30}
    do
        #waiting interface restored
        sleep 2
        ifconfig ppp15 up
        if [ $? -eq 0 ]; then
            SLog "up interface success"
            break
        elif [ $? -eq 30 ]; then
            SLog "up interface failed"
            restart_ecm_msg_exc_time_now=$(date "+%Y-%m-%d %H:%M:%S")
            return
        fi
    done

    lteEnable=`cat /etc/cpeagent/interfaces.conf |grep ppp15 -A 20 |grep lteEnable | cut -d ":" -f 2 | sed 's/"//g' | sed 's/,//g' | sed 's/ //g'`
    if [ "$lteEnable" = "true" ]; then
        carrier=`cat /etc/cpeagent/interfaces.conf |grep ppp15 -A 20 |grep carrier | cut -d ":" -f 2 | sed 's/"//g' | sed 's/,//g' | sed 's/ //g'`
        if [ "$carrier" = "cmcc" ]; then
            apn="cmnet"
        elif [ "$carrier" = "cucc" ]; then
            apn="3gnet"
        elif [ "$carrier" = "ctcc" ]; then
            apn="ctnet"
        elif [ "$carrier" = "manual" ]; then
            apn=`cat /etc/cpeagent/interfaces.conf |grep ppp15 -A 20 |grep apn | cut -d ":" -f 2 | sed 's/"//g' | sed 's/,//g' | sed 's/ //g'`
        elif [ -z "$carrier" ]; then
            apn=""
        else
            SLog "CPE cpeagent.conf exception"
            restart_ecm_msg_failed_time_now=$(date "+%Y-%m-%d %H:%M:%S")
            return
        fi

        #Waiting for module stability
        sleep 20

        if [ -n "$apn" ]; then
            Set_dump_mode
            ECM_DEMO -t up -a "$apn"
            restart_ecm_msg_success_time_now=$(date "+%Y-%m-%d %H:%M:%S")
        else
            Set_dump_mode
            ECM_DEMO -t up
            restart_ecm_msg_success_time_now=$(date "+%Y-%m-%d %H:%M:%S")
        fi
        SLog "Restart ECM_DEMO success"

    else
        SLog "No need to restart ECM_DEMO"
        restart_ecm_msg_disable_time_now=$(date "+%Y-%m-%d %H:%M:%S")
    fi

    #wait dialing
    sleep 20
}

dump_log_collect()
{
    echo -e "05c6 900e" > /sys/bus/usb-serial/drivers/option1/new_id
    if [ $? -eq 0 ]; then
        dump_log_name="${dump_log_name}_$(date +%s)"
        SLog "Start collecting ${dump_log_name}"
        ./${dump_tool} -f ${dump_log_name} >> /var/log/messages
        if [ $? -eq 0 ]; then
            SLog "Finish collecting ${dump_log_name}"

            tar -czf ${dump_log_name}.tar.gz ${dump_log_name} --remove-files
            dump_log_name="${dump_log_name}.tar.gz"
            SLog "Compression ${dump_log_name} completed"

            dump_log_collect_msg_success_time_now=$(date "+%Y-%m-%d %H:%M:%S")
            dump_log_collect_msg_success="Dump log collection succeeded, you can find it in ${dump_log_name}, begin restart ECM_DEMO."
            for i in {1..30}
            do
                sleep 2
                #check module restored
                vpid=`lsusb |grep "2cb7:0104" | awk '{print $6}'`
                if [ -n "$vpid" ]; then
                    SLog "wating 30s, Module recovery form crash"
                    sleep 30
                    restart_ecm
                    break
                elif [ $i -eq 30 ]; then
                    SLog "Module error, not recovery from crash for 60 seconds"
                    dump_log_collect_msg_exc_time_now=$(date "+%Y-%m-%d %H:%M:%S")
                fi
            done
        else
            SLog "Dump log collection failed"
            dump_log_collect_msg_failed_time_now=$(date "+%Y-%m-%d %H:%M:%S")
        fi
    else
        SLog "Configure dump mode new id failed"
        dump_log_collect_msg_exc2_time_now=$(date "+%Y-%m-%d %H:%M:%S")
    fi
}

check_module_crash()
{
    #check usb device by lsusb
    vpid=`lsusb | grep "2cb7:0104" | awk '{print $6}'`
    if [ -z "$vpid" ]; then
        #crash occurs
        SLog "Module crash, to collect dump log"
        check_device_msg_crash_time_now=$(date "+%Y-%m-%d %H:%M:%S")
        for i in {1..30}
        do
            #waiting restored
            sleep 2
            dump_vpid=`lsusb | grep "05c6:900e" | awk '{print $6}'`
            if [ -n "$dump_vpid" ]; then
                SLog "Module enters dump mode"
                check_device_msg_exc_time_now=""
                dump_log_collect
                break
            elif [ $i -eq 30 ]; then
                SLog "Module error, not in dump mode for 60 seconds"
                check_device_msg_exc_time_now=$(date "+%Y-%m-%d %H:%M:%S")
            fi
        done

        return $ret_found_crash;
    fi
}

check_NR_connection()
{
    output=""
    ret=""
    if [ ${Ping_Switch} -eq 1 ]; then
        output=$(ping -I ${Source_outlet} ${Target_Server} -c ${Ping_Count} -W 2 | grep "received")
        ret=$(echo ${output} | grep "${Ping_Count} received")
    fi

    if [ -z "${ret}" ]; then
        if [ ${NR_Crash_Switch} -eq 1 ]; then
            check_module_crash
        fi

        if [ $? -eq $ret_found_crash ]; then
            Consecutive_ping_Fail_Times=0
            Consecutive_Reset_Fail_Times=0
            return $ret_found_crash
        else
            if [ ${Ping_Switch} -eq 0 ]; then
                return
            fi
            let Consecutive_ping_Fail_Times=Consecutive_ping_Fail_Times+1
            SLog "ping ${Target_Server} failed ret: $output"
            SLog "Current Failed times: ${Consecutive_ping_Fail_Times}"
        fi
    else
        Consecutive_ping_Fail_Times=0
        Consecutive_Reset_Fail_Times=0
    fi
}

Reset_Module()
{
    Consecutive_ping_Fail_Times=0
    if [ -e /dev/ttyUSB2 ]; then
        let Consecutive_Reset_Fail_Times=Consecutive_Reset_Fail_Times+1
        SLog "Enter Reset module, ${Consecutive_Reset_Fail_Times}"
        killall ECM_DEMO
        ifconfig ppp15 up
        ip addr flush dev ppp15
        ./${at_tool} -d /dev/ttyUSB2 "at+cfun=0"
        sleep 1
        ./${at_tool} -d /dev/ttyUSB2 "at+cfun=1"
        sleep 1
        if [[ -z "$Overall_Apn" ]]
        then
            ECM_DEMO -t up
        else
            ECM_DEMO -t up -a "$Overall_Apn"
        fi
        i=0
        while (true) 
        do
            ipresult=$(ip addr show dev ppp15 | grep -v inet6 | grep inet)
            if [ ! -z "${ipresult}" ];then
                SLog "Reset module Success: ${ipresult}"
                break
            else
                let i=i+1
                sleep 1
                ecmpid=$(ps aux | grep ECM_DEMO | grep -v grep) 
                if [ -z "${ecmpid}" ];then
                    if [[ -z "$Overall_Apn" ]]
                    then
                        ECM_DEMO -t up
                    else
                        ECM_DEMO -t up -a "$Overall_Apn"
                    fi
                fi
                if [ $i -eq 60 ];then
                    Consecutive_ping_Fail_Times=0
                    Consecutive_Reset_Fail_Times=0
                    SLog "Check ppp15 ip failed, back to check server "
                    break
                fi
            fi
        done
    else
        SLog "Module error, no ttyUSB2 found"

    fi
}

Reboot_Module()
{
    SLog "Enter Reboot Module, Current ping count ${Consecutive_ping_Fail_Times}, Reset Count ${Consecutive_Reset_Fail_Times}"
    Consecutive_ping_Fail_Times=0
    Consecutive_Reset_Fail_Times=0
    if [ ${Reboot_or_Not} -eq 0 ]; then
        SLog "No Reboot module"
        return
    fi

    if [ -e /dev/ttyUSB2 ]; then
        killall ECM_DEMO
        ./${at_tool} -d /dev/ttyUSB2 "at+cfun=15"
        sleep 2
        cat /proc/net/dev | grep ppp15
        if [ $? -eq 0 ];then
            SLog "Reset Failed!"
            return
        fi

        i=0
        while (true)
        do
            cat /proc/net/dev | grep ppp15 
            if [ $? -eq 0 ];then
                sleep 5
                ifconfig ppp15 up
                if [[ -z "$Overall_Apn" ]]
                then
                    ECM_DEMO -t up
                else
                    ECM_DEMO -t up -a "$Overall_Apn"
                fi
                break
            else
                let i=i+1
                sleep 2
                if [ $i -eq 60 ];then
                    Consecutive_ping_Fail_Times=0
                    Consecutive_Reset_Fail_Times=0
                    SLog "Check ppp15 dev failed, back to check server "
                    break
                fi
            fi
        done
        i=0
        while (true) 
        do
            ipresult=$(ip addr show dev ppp15 | grep -v inet6 | grep inet)
            if [ ! -z "${ipresult}" ];then
                SLog "Reset module Success: ${ipresult}"
                break
            else
                let i=i+1
                sleep 1
                ecmpid=$(ps aux | grep ECM_DEMO | grep -v grep) 
                if [ -z "${ecmpid}" ];then
                    if [[ -z "$Overall_Apn" ]]
                    then
                        ECM_DEMO -t up
                    else
                        ECM_DEMO -t up -a "$Overall_Apn"
                    fi
                fi
                if [ $i -eq 60 ];then
                    Consecutive_ping_Fail_Times=0
                    Consecutive_Reset_Fail_Times=0
                    SLog "Check ppp15 ip failed, back to check server "
                    break
                fi
            fi
        done
    else
        SLog "Module error, no ttyUSB2 found"

    fi
    
}

Reboot_machine()
{    
    SLog "Reboot system!!!"
    reboot    
}

check_NR_switch()
{
    nm="AT+GTCCINFO?"
    if [ ! -e /dev/ttyUSB1 ]; then
        SLog "Module error, no ttyUSB1 found"
        return
    fi

    network_mode=`./${at_tool} -d /dev/ttyUSB1 $nm | grep "service cell" | awk '{print $1}'`
    if [ -z "${network_mode}" ]
    then
        SLog "The module returns an AT command return value"
        continue
    fi        
    
    if [ $network_mode = $Networks_NR ]
    then
        return
    else
        SLog "Currently not in the 5G band, start to detect the signal"
        for ((i=1; i<=${Check_Time}; i++))
        do
            network_mode=`./${at_tool} -d /dev/ttyUSB1 $nm | grep "service cell" | awk '{print $1}'`
            if [ ! -e /dev/ttyUSB1 ]; then
                flags=0
                SLog "Module error, no ttyUSB1 found, maybe crash"
                break
            fi

            if [ $network_mode = $Networks_NR ]; then
                flags=0
                break
            fi

            val1=`expr $i % 60`
            val2=`expr $i / 60`
            if [ ${val1} -eq 0 ]
            then
                SLog "Not in the 5G band for ${val2} minute"
            fi
            sleep 1
        done

        if [ $flags -eq 1 ]
        then
            SLog "Not in the 5G band for ${Check_Time} second, reboot the system"
            Reboot_for_Networks=1
        fi
    fi
}

set_main_param()
{
    if [ "$LW_Device" = "LW2508" ]; then
        dump_tool="fibo_dump_collect_tool.2508"
        at_tool="at.2508"
    elif [ "$LW_Device" = "LW2509" ]; then
        dump_tool="fibo_dump_collect_tool.2509"
        at_tool="at.2509"
    else
        SLog "LW_Device param invalid"
        exit $ret_fail_others
    fi
}

print_main_param()
{
    dd_url="Test alarm group"
    if [ "$webhook" = "https://oapi.dingtalk.com/robot/send?access_token=db5cd0cec88b16c2f674cd468cd55285dad84c3cadd543af01c86c2480bf29b3" ]; then
        dd_url="On-line alarm group"
    fi

    SLog "LW_Device:${LW_Device} At_Mobile:${At_Mobile} Source_outlet:${Source_outlet} Overall_Apn:${Overall_Apn} Target_Server:${Target_Server} Group:${dd_url} NR_Crash_Switch:${NR_Crash_Switch} NR_Out_Switch:${NR_Out_Switch} Ping_Switch:${Ping_Switch}"
}

if [ ${NR_Crash_Switch} -eq 0 ]; then
    check_module
fi

set_main_param
print_main_param

if [ ${NR_Crash_Switch} -eq 0 ]; then
    Set_dump_mode
fi

while (true) 
do
    sleep 3

    if [ ${NR_Out_Switch} -eq 1 ]; then
        check_NR_switch
        if [[ ${Reboot_for_Networks} -eq 1 ]]
        then
            Reboot_machine
            continue
        fi
    fi

    if [ ${Ping_Switch} -eq 1 ]; then
        if [[ ${Reboot_for_Ping_or_Reset_Count} -eq 5 ]]; then
            Reboot_machine
            continue
        fi
    fi
    
    check_NR_connection

    if [ $? -eq $ret_found_crash ]; then
        send_message_list
    else
        if [ ${NR_Out_Switch} -eq 0 ]; then
            continue
        fi

        if [ ${Consecutive_Reset_Fail_Times} -eq ${Consecutive_Reset_Fail_Times_Max} ]; then
            let Reboot_for_Ping_or_Reset_Count=Reboot_for_Ping_or_Reset_Count+1  
            Reboot_Module    
            continue
        fi

        if [ ${Consecutive_ping_Fail_Times} -eq ${Consecutive_Ping_Fail_Times_Max} ]; then
            let Reboot_for_Ping_or_Reset_Count=Reboot_for_Ping_or_Reset_Count+1 
            Reset_Module
            continue
        fi
    fi
done