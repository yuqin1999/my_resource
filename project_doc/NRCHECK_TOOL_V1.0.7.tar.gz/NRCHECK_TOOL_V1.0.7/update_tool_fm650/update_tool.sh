#!/bin/bash
set -x

SCRIPT_NAME_PID="${0}[$$]:"
WORK_PATH=$(cd $(dirname $0); pwd)
UPDATE_TOOL=${WORK_PATH}/upgrade_tool_v1.1.4.0.2506
UPDATE_PACKAGE=${WORK_PATH}/$(ls ${WORK_PATH} | grep ".pac")
TIME_OUT=120

logger "${SCRIPT_NAME_PID}Module update start"
#=================================update
${UPDATE_TOOL} -f ${UPDATE_PACKAGE}
#=================================clean

if [ $? -eq 0 ]; then
  logger "${SCRIPT_NAME_PID}Module update success!"
else
  logger "${SCRIPT_NAME_PID}Module update failure!"
  exit 1
fi

# set low-power leval
for ((elapsed_time=0; elapsed_time<${TIME_OUT}; elapsed_time+=5)); do
    # Check if /dev/ttyUSB* files exist
    if ls /dev/ttyUSB* 1> /dev/null 2>&1; then
        logger "${SCRIPT_NAME_PID}/dev/ttyUSB* files exist - Continue!"
        sleep 15    #Waiting for stability

        ../at.2506 -d /dev/ttyUSB1 AT+GTSET=\"SIMPHASE\",0,0
        logger "${SCRIPT_NAME_PID}AT write: AT+GTSET=SIMPHASE,0,0"
        sleep 2

        ../at.2506 -d /dev/ttyUSB1 AT+CFUN=1,1
        logger "${SCRIPT_NAME_PID}AT write: AT+CFUN=1,1"
        logger "${SCRIPT_NAME_PID}Exit with success status"
        exit 0  # Exit with success status
    else
        logger "${SCRIPT_NAME_PID}/dev/ttyUSB* files do not exist - Retrying in 5 seconds..."
        sleep 5  # Sleep for 5 seconds
    fi
done

# If the loop reaches here, it means the timeout has occurred
logger "${SCRIPT_NAME_PID}Timeout reached. /dev/ttyUSB* files not found after ${TIME_OUT} seconds."
exit 1  # Exit with failure status